<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH."wp-load.php");
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');

$input = file_get_contents("php://input");

$event = json_decode($input);

$charge = vp_getoption("charge_back");

$admine = get_bloginfo('admin_email');

$headers = array('Content-Type: text/html; charset=UTF-8');

/*
if(isset($event->event) && $event->event == "charge.success" && isset($event->data->amount)){
$email =  $event->data->customer->email;
$amount = $event->data->amount;
$total_amount = $amount/100;

$userid = get_user_by( 'email', $email )->ID;

$user_name =  get_user_by( 'email', $email )->user_login;

$ini = vp_getuser($userid, 'vp_bal', true);


if(vp_getoption("charge_method") == "fixed"){
$minus = $total_amount - $charge;
}
else{
$remove = ($total_amount *  $charge) / 100;
$minus = $total_amount - $remove ;
}



$toti = $ini + $minus;

vp_updateuser($userid, 'vp_bal', $toti);

$now = vp_getuser($userid, 'vp_bal', true);
echo "TYPE - PAYSTACK<br>";
echo "USERNAME - $user_name<br>";
echo "USER ID - $userid<br>";
echo "INITIAL BALANCE - $ini<br>";
echo "CURRENT BALANCE - $now<br>";

global $wpdb;
$name = get_userdata($userid)->user_login;
$description = 'Credited By You [Online]';
$fund_amount= $minus;
$before_amount = $ini;
$now_amount = $toti;
$user_id = $userid;
$the_time = current_time('mysql', 1);

$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $name,
'description'=> $description,
'fund_amount' => $fund_amount,
'before_amount' => $before_amount,
'now_amount' => $now_amount,
'user_id' => $user_id,
'status' => "approved",
'the_time' => current_time('mysql', 1)
));

$content = "
<!DOCTYPE html>
<html>
<body>
<h3>New Transaction Logged!</h3><br/>
<table>
<thead>
<tr>
<th>Details</th>
<th>Data</th>
</tr>
</thead>
<tbody>
<tr>
<td>Name</td>
<td>$user_name</td>
</tr>
<tr>
<td>Email</td>
<td>$email</td>
</tr>
<tr>
<td>Previous Balane</td>
<td>$ini</td>
</tr>
<tr>
<td>Funded</td>
<td>$minus</td>
</tr>
</tbody>
<tfoot>
<tr>
<td>Current Balance</td>
<td>$toti</td>
</tr>
</tfoot>
</table>

</body>
</html>


";

wp_mail($admine, "$user_name Wallet Funding [PAYSTACK]", $content, $headers);
wp_mail($email, "$user_name Wallet Funding [PAYSTACK]", $content, $headers);

http_response_code("HTTP 200 OK");
}

*/

if(isset($event->event) && $event->event == "charge.completed"){
$email =  $event->data->customer->email;
$amount = $event->data->amount;
$total_amount = $amount;
$userid = get_user_by( 'email', $email )->ID;

$user_name =  get_user_by( 'email', $email )->user_login;

$ini = vp_getuser($userid, 'vp_bal', true);


if(vp_getoption("charge_method") == "fixed"){
$minus = $total_amount - $charge;
}
else{
$remove = ($total_amount *  $charge) / 100;
$minus = $total_amount - $remove ;
}



$toti = $ini + $minus;

vp_updateuser($userid, 'vp_bal', $toti);

$now = vp_getuser($userid, 'vp_bal', true);
/*
echo "TYPE - PAYSTACK<br>";
echo "USERNAME - $user_name<br>";
echo "USER ID - $userid<br>";
echo "INITIAL BALANCE - $ini<br>";
echo "CURRENT BALANCE - $now<br>";
*/

global $wpdb;
$name = get_userdata($userid)->user_login;
$description = 'Credited By You [Online]';
$fund_amount= $minus;
$before_amount = $ini;
$now_amount = $toti;
$user_id = $userid;
$the_time = current_time('mysql', 1);

$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $name,
'type'=> 'wallet',
'description'=> $description,
'fund_amount' => $fund_amount,
'before_amount' => $before_amount,
'now_amount' => $now_amount,
'user_id' => $user_id,
'status' => "approved",
'the_time' => current_time('mysql', 1)
));

$content = "
<!DOCTYPE html>
<html>
<body>
<h3>New Transaction Logged!</h3><br/>
<table>
<thead>
<tr>
<th>Details</th>
<th>Data</th>
</tr>
</thead>
<tbody>
<tr>
<td>Name</td>
<td>$user_name</td>
</tr>
<tr>
<td>Email</td>
<td>$email</td>
</tr>
<tr>
<td>Previous Balane</td>
<td>$ini</td>
</tr>
<tr>
<td>Funded</td>
<td>$minus</td>
</tr>
</tbody>
<tfoot>
<tr>
<td>Current Balance</td>
<td>$toti</td>
</tr>
</tfoot>
</table>

</body>
</html>


";

wp_mail($admine, "$user_name Wallet Funding [FLUTTERWAVE]", $content, $headers);
wp_mail($email, "$user_name Wallet Funding [FLUTTERWAVE]", $content, $headers);
http_response_code("HTTP 200 OK");
}



if(isset($event->eventType) && $event->eventType == "SUCCESSFUL_TRANSACTION" ){
$email =  $event->eventData->customer->email;
$amount = $event->eventData->amountPaid;
$total_amount = $amount;
$userid = get_user_by( 'email', $email )->ID;

$user_name =  get_user_by( 'email', $email )->user_login;

$ini = vp_getuser($userid, 'vp_bal', true);


if(vp_getoption("charge_method") == "fixed"){
$minus = $total_amount - $charge;
}
else{
$remove = ($total_amount *  $charge) / 100;
$minus = $total_amount - $remove ;
}



$toti = $ini + $minus;

vp_updateuser($userid, 'vp_bal', $toti);

$now = vp_getuser($userid, 'vp_bal', true);
/*
echo "TYPE - PAYSTACK<br>";
echo "USERNAME - $user_name<br>";
echo "USER ID - $userid<br>";
echo "INITIAL BALANCE - $ini<br>";
echo "CURRENT BALANCE - $now<br>";
*/

global $wpdb;
$name = get_userdata($userid)->user_login;
$description = 'Credited By You [Online]';
$fund_amount= $minus;
$before_amount = $ini;
$now_amount = $toti;
$user_id = $userid;
$the_time = current_time('mysql', 1);

$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $name,
'type'=> 'wallet',
'description'=> $description,
'fund_amount' => $fund_amount,
'before_amount' => $before_amount,
'now_amount' => $now_amount,
'user_id' => $user_id,
'status' => "approved",
'the_time' => current_time('mysql', 1)
));

$content = "
<!DOCTYPE html>
<html>
<body>
<h3>New Transaction Logged!</h3><br/>
<table>
<thead>
<tr>
<th>Details</th>
<th>Data</th>
</tr>
</thead>
<tbody>
<tr>
<td>Name</td>
<td>$user_name</td>
</tr>
<tr>
<td>Email</td>
<td>$email</td>
</tr>
<tr>
<td>Previous Balane</td>
<td>$ini</td>
</tr>
<tr>
<td>Funded</td>
<td>$minus</td>
</tr>
</tbody>
<tfoot>
<tr>
<td>Current Balance</td>
<td>$toti</td>
</tr>
</tfoot>
</table>

</body>
</html>


";

wp_mail($admine, "$user_name Wallet Funding [MONNIFY]", $content, $headers);
wp_mail($email, "$user_name Wallet Funding [MONNIFY]", $content, $headers);
http_response_code("HTTP 200 OK");
}
else{
	http_response_code("HTTP 200 OK");
}


?>