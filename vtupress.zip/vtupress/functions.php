<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH."wp-load.php");
include_once(ABSPATH.'wp-admin/includes/plugin.php');
///BEGINNING OF UPDATE AND ADD

$path = WP_PLUGIN_DIR.'/vtupress/functions.php';
if(!function_exists("vp_updateuser") || is_plugin_active("vtupress/vtupress.php")){
function vp_updateuser($id,$meta,$value){
	$update_meta = get_user_meta($id,"vp_user_data",true);
	if(empty($update_meta)){
add_user_meta($id,"vp_user_data",'{"default":"yes"}');
	}
$array = json_decode($update_meta,true);

$array[$meta] = $value;

update_user_meta($id,"vp_user_data",json_encode($array));
return "true";

}

function vp_updateoption($meta,$value){
	
add_option("vp_options",'{"default":"yes"}');
$array = json_decode(get_option("vp_options"),true);

$array[$meta] = $value;

update_option("vp_options",json_encode($array));
return "true";
}

///END OF UPDATE AND ADD

///BEGINNING OF GET
function vp_getoption($meta){
$value = get_option($meta);
$val = get_option("vp_options");
if($meta != "siteurl" && $meta != "blogname" && $meta != "home" && $meta != "admin_email" && $meta != "blogdescription"){
if($value !== false && $meta != "vp_options"){
	
	vp_updateoption($meta,$value);
	delete_option($meta);
$array = json_decode($val,true);

if(isset($array[$meta])){
return $array[$meta];
}
else{
return "false";
}
}
else{
	if($val !== false){
		$array = json_decode($val,true);
		if(isset($array[$meta])){
return $array[$meta];
}
else{
return "false";
}
	}
	else{
	return "false";	
	}
}

}
else{
	return $value;
}

}

function vp_getuser($id,$meta,$single = true){
	$getdata = get_user_meta($id,"vp_user_data",true);
	$get_meta = get_user_meta($id,$meta,true);
	//check if user meta exist explicitly on wp_usermeta
if($meta != "vp_user_data" && (!empty($get_meta) || $get_meta == "0") ){//if exist
	$value = $get_meta;//get value
	vp_updateuser($id,$meta,$value);//add it to the vp_user_data of the user ID
	delete_user_meta($id,$meta);//Delete The user meta from being explicit on wp_usermeta
	
$array = json_decode($getdata,true); //Now Get The vp_user_data and convert to an array

if(isset($array[$meta])){// If meta array key exist, return the value
return $array[$meta];
}
else{//else return false
return "false";
}
}
else{
	if(!empty($getdata)){ //check if user already has private vp_user_data
		$array = json_decode($getdata,true);//convert to array
		if(isset($array[$meta])){//check if meta exist
return $array[$meta];//return value
}
else{ //else return false
return "false";
}
	}
	else{
	return "false";	
	} //if no vp_user_data return false
}
}

function vp_option_array($array,$meta){
if(!empty($array[$meta])){
	return $array[$meta];
}
else{
	vp_getoption($meta);
}
}


function vp_user_array($array,$id,$meta,$single = true){
if(!empty($array[$meta])){
	return $array[$meta];
}
else{
	vp_getuser($id,$meta,$single);
}
}
///END OF GET
function vp_deleteuser($id){
	delete_user_meta($id,"vp_user_data");
	return "true";
}

function vp_adduser($id,$meta,$value){
	$ths = get_user_meta($id,"vp_user_data",true);
if(empty($ths)){
add_user_meta($id,"vp_user_data",'{"default":"yes"}');
	}

$array = json_decode($ths,true);
if(isset($array[$meta])){
	return "false";
}
else{
	$array[$meta] = $value;

update_user_meta($id,"vp_user_data",json_encode($array));
return "true";
}

}

function vp_addoption($meta,$value){
$array = json_decode(get_option("vp_options"),true);
if(isset($array[$meta])){
	return "false";
}
else{
	$array[$meta] = $value;

update_option("vp_options",json_encode($array));
return "true";
}

}

}


function pagination_before($name,$altname="",$dbname,$var="none",$where=""){
	  
 global $post, $wpdb, ${$var};


$limit = isset($_REQUEST["".$altname.$name."-limit-records"]) ? $_REQUEST["".$altname.$name."-limit-records"] : 10;
$page = isset($_GET[''.$altname.$name.'-page']) ? $_GET[''.$altname.$name.'-page'] : 1;
$start = ($page - 1) * $limit;


    $table_name = $wpdb->prefix.$dbname;
	${$var} = $wpdb->get_results("SELECT * FROM  $table_name $where ORDER BY ID DESC LIMIT $start, $limit");
	
    #${$var} = $wpdb->get_results($wpdb->prepare("SELECT * FROM  $table_name $where ORDER BY %s DESC LIMIT $start, $limit", 'ID'));
	#SELECT * FROM `wpzl_sairtime` ORDER BY ID DESC LIMIT 10
	$num = $wpdb->get_var("SELECT count(id) AS id FROM $table_name $where");
	$pages = ceil( $num  / $limit );
	

	
	$Previous = $page - 1;
	$Next = $page + 1;
	echo '
	<div class="container well">
		<div class="row mt-3 md-2">
			<div class=" col-md-10">
				<nav aria-label="Page navigation">
					<ul class="pagination">
				    <li class="mx-2">
				      <a href="?page=vtu-settings&'.$altname.$name.'-page='.$Previous.'&'.$altname.$name.'-limit-records='.$limit.'#'.$name.'" aria-label="Previous">
				        <span aria-hidden="true">&laquo; Previous</span>
				      </a>
				    </li>
					';
				     for($i = 1; $i<= $pages; $i++){
						 if(isset($_GET["".$altname.$name."-page"]) && $_GET["".$altname.$name."-page"] == $i){
							 $color = "text-danger";
						 }else{
							 $color = "text-primary";
						 }
						 echo'
				    	<li class="border border-primary px-2"><a class="'.$color.'" href="?page=vtu-settings&'.$altname.$name.'-page='. $i.'&'.$altname.$name.'-limit-records='.$limit.'#'.$name.'">'. $i .'</a></li>
						';
}

echo'
				    <li class="mx-2">
				      <a href="?page=vtu-settings&'.$altname.$name.'-page='. $Next.'&'.$altname.$name.'-limit-records='.$limit.'#'.$name.'" aria-label="Next">
				        <span aria-hidden="true">Next &raquo;</span>
				      </a>
				    </li>
				  </ul>
				</nav>
			</div>
			<div class="text-center col-md-2">
				<form >
				<div class="input-group">
				<span class="input-group-text">Limit</span>
						<select class="" name="'.$altname.$name.'-limit-records" id="'.$altname.$name.'-limit-records">
						';
						
							foreach([10,20,30,40,50,60,70,80,90,100,150,200,250,300,350,400,450,500,700,1000,2000] as $limit){
								 if( isset($_GET["".$altname.$name."-limit-records"]) && $_GET["".$altname.$name."-limit-records"] == $limit){
								 $echo = "selected";
								 }
								 else{
									 $echo = "opt";
								 }
								echo'
								<option '. $echo.' value="'. $limit.'">'. $limit.'</option>
								';
							}
							echo'
						</select>
						</div>
				</form>
			</div>
		</div>
		<div>
';
	
}



function pagination_after($name,$altname="",$dbname ="none"){


	
echo '
</div>

</div>
<script type="text/javascript">
	$(document).ready(function(){
		$("select#'.$altname.$name.'-limit-records").change(function(){
			var val = $("select#'.$altname.$name.'-limit-records").val();
			window.location = "?page=vtu-settings&'.$altname.$name.'-page=1&'.$altname.$name.'-limit-records="+val+"#'.$name.'";
		});
	});
</script>

';


}



function pagination_before_front($url="", $name,$altname="",$dbname,$var="none",$where=""){
	  
 global $post, $wpdb, ${$var};


$limit = isset($_REQUEST["".$altname.$name."-limit-records"]) ? $_REQUEST["".$altname.$name."-limit-records"] : 10;
$page = isset($_GET[''.$altname.$name.'-page']) ? $_GET[''.$altname.$name.'-page'] : 1;
$start = ($page - 1) * $limit;


    $table_name = $wpdb->prefix.$dbname;
	${$var} = $wpdb->get_results("SELECT * FROM  $table_name $where ORDER BY ID DESC LIMIT $start, $limit");
	
    #${$var} = $wpdb->get_results($wpdb->prepare("SELECT * FROM  $table_name $where ORDER BY %s DESC LIMIT $start, $limit", 'ID'));
	#SELECT * FROM `wpzl_sairtime` ORDER BY ID DESC LIMIT 10
	$num = $wpdb->get_var("SELECT count(id) AS id FROM $table_name $where");
	$pages = ceil( $num  / $limit );
	

	
	$Previous = $page - 1;
	$Next = $page + 1;
	echo '
	<div class="container well">
		<div class="row mt-3 md-2">
			<div class=" col-md-10">
				<nav aria-label="Page navigation">
					<ul class="pagination">
				    <li class="mx-2">
				      <a href="'.$url.'&'.$altname.$name.'-page='.$Previous.'&'.$altname.$name.'-limit-records='.$limit.'#'.$name.'" aria-label="Previous">
				        <span aria-hidden="true">&laquo; Previous</span>
				      </a>
				    </li>
					';
				     for($i = 1; $i<= $pages; $i++){
						 if(isset($_GET["".$altname.$name."-page"]) && $_GET["".$altname.$name."-page"] == $i){
							 $color = "text-danger";
						 }else{
							 $color = "text-primary";
						 }
						 echo'
				    	<li class="border border-primary px-2"><a class="'.$color.'" href="'.$url.'&'.$altname.$name.'-page='. $i.'&'.$altname.$name.'-limit-records='.$limit.'#'.$name.'">'. $i .'</a></li>
						';
}

echo'
				    <li class="mx-2">
				      <a href="'.$url.'&'.$altname.$name.'-page='. $Next.'&'.$altname.$name.'-limit-records='.$limit.'#'.$name.'" aria-label="Next">
				        <span aria-hidden="true">Next &raquo;</span>
				      </a>
				    </li>
				  </ul>
				</nav>
			</div>
			<div class="text-center col-md-2">
				<form >
				<div class="input-group">
				<span class="input-group-text">Limit</span>
						<select class="" name="'.$altname.$name.'-limit-records" id="'.$altname.$name.'-limit-records">
						';
						
							foreach([10,20,30,40,50,60,70,80,90,100,150,200,250,300,350,400,450,500,700,1000,2000] as $limit){
								 if( isset($_GET["".$altname.$name."-limit-records"]) && $_GET["".$altname.$name."-limit-records"] == $limit){
								 $echo = "selected";
								 }
								 else{
									 $echo = "opt";
								 }
								echo'
								<option '. $echo.' value="'. $limit.'">'. $limit.'</option>
								';
							}
							echo'
						</select>
						</div>
				</form>
			</div>
		</div>
		<div>
';
	
}


function pagination_after_front($url="",$name,$altname="",$dbname ="none"){


	
echo '
</div>

</div>
<script type="text/javascript">
	$(document).ready(function(){
		$("select#'.$altname.$name.'-limit-records").change(function(){
			var val = $("select#'.$altname.$name.'-limit-records").val();
			window.location = "'.$url.'&'.$altname.$name.'-page=1&'.$altname.$name.'-limit-records="+val+"#'.$name.'";
		});
	});
</script>

';


}



function vtupress_js_css_user(){
	
	echo'
	<script src="'.esc_url(plugins_url("vtupress/js/bootstrap.min.js")).'"></script>
	<script src="'.esc_url(plugins_url("vtupress/js/jquery.js")).'"></script>
	<script src="'.esc_url(plugins_url("vtupress/js/sweet.js")).'"></script>
	<script src="'.esc_url(plugins_url("vtupress/js/pdf.js")).'"></script>
	<script src="'.esc_url(plugins_url("vtupress/js/print.js")).'"></script>
	<link rel="stylesheet" href="'.esc_url(plugins_url("vtupress/css/bootstrap.min.css")).'">
	<link rel="stylesheet" href="'.esc_url(plugins_url("vtupress/css/font-awesome.min.css")).'">
	<link rel="stylesheet" href="'.esc_url(plugins_url("vtupress/css/print.css")).'">
	<link rel="stylesheet" href="'.esc_url(plugins_url("vtupress/css/all.min.css")).'">
	
	';
}

add_action( 'wp_enqueue_scripts', 'vtupress_js_css_user' );

function vtupress_js_css_user_plain(){

echo'
<script src="'.esc_url(plugins_url("vtupress/js/bootstrap.min.js?v=1")).'"></script>
<script src="'.esc_url(plugins_url("vtupress/js/jquery.js?v=1")).'"></script>
<script src="'.esc_url(plugins_url("vtupress/js/sweet.js?v=1")).'"></script>
<script src="'.esc_url(plugins_url("vtupress/js/pdf.js?v=1")).'"></script>
<script src="'.esc_url(plugins_url("vtupress/js/print.js?v=1")).'"></script>
<link rel="stylesheet" href="'.esc_url(plugins_url("vtupress/css/all.min.css?v=1")).'">
<link rel="stylesheet" href="'.esc_url(plugins_url("vtupress/css/print.css?v=1")).'">
';


}

function vtupress_js_css_user_plain_admin(){


echo'
<script src="'.esc_url(plugins_url("vtupress/js/jquery.js?v=1")).'"></script>
<script src="'.esc_url(plugins_url("vtupress/js/bootstrap.min.js?v=1")).'"></script>
<script src="'.esc_url(plugins_url("vtupress/js/sweet.js?v=1")).'"></script>
<script src="'.esc_url(plugins_url("vtupress/js/pdf.js?v=1")).'"></script>
<script src="'.esc_url(plugins_url("vtupress/js/print.js?v=1")).'"></script>
<link rel="stylesheet" href="'.esc_url(plugins_url("vtupress/css/bootstrap.min.css?v=1")).'">
<link rel="stylesheet" href="'.esc_url(plugins_url("vtupress/css/font-awesome.min.css?v=1")).'">
<link rel="stylesheet" href="'.esc_url(plugins_url("vtupress/css/all.min.css?v=1")).'">
<link rel="stylesheet" href="'.esc_url(plugins_url("vtupress/css/print.css?v=1")).'">
';


}

function vtupress_user_details(){
$id = get_current_user_id(); 
$array["name"] = get_userdata($id)->user_login;
$array["email"] = get_userdata($id)->user_email;


$option_array = json_decode(get_option("vp_options"),true);
$user_array = json_decode(get_user_meta($id,"vp_user_data",true),true);

$array["phone"] = vp_user_array($user_array,$id,"vp_phone",true);
$array["pin"] = vp_user_array($user_array,$id,"vp_pin",true);

$array["option_array"] = $option_array;
$array["user_array"] = $user_array;

$array["kyc_status"] = vp_user_array($user_array,$id,'vp_kyc_status',true);
$array["kyc_end"] = vp_user_array($user_array,$id,'vp_kyc_end',true);
$array["kyc_total"] = vp_user_array($user_array,$id,'vp_kyc_total',true);

global $wpdb;
$table_name = $wpdb->prefix."vp_kyc_settings";
$array["kyc_data"] = $wpdb->get_results("SELECT * FROM $table_name WHERE id = 1");


$array["admin_whatsapp"] = vp_option_array($option_array,"vp_whatsapp");



$array["bal"] = vp_user_array($user_array,$id, "vp_bal", true);
$array["myplan"] = vp_user_array($user_array,$id, 'vr_plan', true);
$dplan = $array["myplan"];

global $wpdb;
$table_name = $wpdb->prefix."vp_levels";
$array["level"] = $wpdb->get_results("SELECT * FROM $table_name WHERE name = '$dplan'");
$array["levels"] = $wpdb->get_results("SELECT * FROM $table_name");


$array["mess"] = vp_option_array($option_array,"vpwalm");


$array["vtudiscounts"] = max(array(floatval(vp_option_array($option_array,"vtu_mad")),floatval(vp_option_array($option_array,"vtu_gad")),floatval(vp_option_array($option_array,"vtu_9ad")),floatval(vp_option_array($option_array,"vtu_aad"))));
$array["sharediscounts"] = max(array(floatval(vp_option_array($option_array,"share_mad")),floatval(vp_option_array($option_array,"share_gad")),floatval(vp_option_array($option_array,"share_9ad")),floatval(vp_option_array($option_array,"share_aad"))));
$array["awufdiscounts"] = max(array(floatval(vp_option_array($option_array,"awuf_mad")),floatval(vp_option_array($option_array,"awuf_gad")),floatval(vp_option_array($option_array,"awuf_9ad")),floatval(vp_option_array($option_array,"awuf_aad"))));

$vtudiscounts = $array["vtudiscounts"];
$sharediscounts = $array["sharediscounts"];
$awufdiscounts = $array["awufdiscounts"];
$array["airtimediscount"] = max(array($vtudiscounts,$sharediscounts,$awufdiscounts ));


$array["smediscounts"] = max(array(floatval(vp_option_array($option_array,"sme_mdd")),floatval(vp_option_array($option_array,"sme_gdd")),floatval(vp_option_array($option_array,"sme_9dd")),floatval(vp_option_array($option_array,"sme_ddd"))));
$array["directdiscounts"] = max(array(floatval(vp_option_array($option_array,"direct_mdd")),floatval(vp_option_array($option_array,"direct_gdd")),floatval(vp_option_array($option_array,"direct_9dd")),floatval(vp_option_array($option_array,"direct_ddd"))));
$array["corporatediscounts"] = max(array(floatval(vp_option_array($option_array,"corporate_mdd")),floatval(vp_option_array($option_array,"corporate_gdd")),floatval(vp_option_array($option_array,"corporate_9dd")),floatval(vp_option_array($option_array,"corporate_ddd"))));

$smediscounts = $array["smediscounts"];
$directdiscounts = $array["directdiscounts"];
$corporatediscounts = $array["corporatediscounts"];
$array["datadiscount"] = max(array($smediscounts,$directdiscounts,$corporatediscounts ));


if(is_plugin_active("vpmlm/vpmlm.php") && vp_option_array($option_array,'mlm') == "yes"){
$array["total_inref3_id"] = 	vp_user_array($user_array,$id, "vp_tot_in_ref3_id", true);
$array["cur_suc_trans_amt"] = vp_user_array($user_array,$id, "vp_tot_trans_amt",true);
$array["ref"] = vp_user_array($user_array,$id, "vp_ref", true);
$array["refbo"] = vp_option_array($option_array,"refbo");
$array["total_refered"] = vp_user_array($user_array,$id, "vp_tot_ref",true);
$array["total_inrefered"] = vp_user_array($user_array,$id, "vp_tot_in_ref",true);
$array["total_inrefered3"] = vp_user_array($user_array,$id, "vp_tot_in_ref3",true);
$array["total_dir_earn"] = vp_user_array($user_array,$id, "vp_tot_ref_earn",true);
$array["total_indir_earn"] = vp_user_array($user_array,$id, "vp_tot_in_ref_earn",true);
$array["total_indir_earn3"] = vp_user_array($user_array,$id, "vp_tot_in_ref_earn3",true);
$array["total_trans_bonus"] = vp_user_array($user_array,$id, "vp_tot_trans_bonus",true);
$array["total_dirtrans_bonus"] = vp_user_array($user_array,$id, "vp_tot_dir_trans",true);
$array["total_indirtrans_bonus"] = vp_user_array($user_array,$id, "vp_tot_indir_trans",true);
$array["total_indirtrans_bonus3"] = vp_user_array($user_array,$id, "vp_tot_indir_trans3",true);
$array["total_trans_attempt"] = vp_user_array($user_array,$id, "vp_tot_trans",true);
$array["total_suc_trans"] = vp_user_array($user_array,$id, "vp_tot_suc_trans",true);
$array["total_trans_bonus"] = vp_user_array($user_array,$id, "vp_tot_trans_bonus",true);
$array["total_withdraws"] = vp_user_array($user_array,$id, "vp_tot_withdraws",true);

$total_dir_earn = $array["total_dir_earn"];
$total_indir_earn = $array["total_indir_earn"];
$total_indir_earn3 = $array["total_indir_earn3"];
$total_trans_bonus = $array["total_trans_bonus"];
$total_dirtrans_bonus = $array["total_dirtrans_bonus"];
$total_indirtrans_bonus = $array["total_indirtrans_bonus"];
$total_indirtrans_bonus3 = $array["total_indirtrans_bonus3"];

$array["total_bal_with"] = intval($total_dir_earn) + intval($total_indir_earn) + intval($total_indir_earn3) + intval($total_trans_bonus) + intval($total_dirtrans_bonus) + intval($total_indirtrans_bonus) + intval($total_indirtrans_bonus3);


$array["minwithle"] = vp_option_array($option_array,"vp_min_withdrawal");
$array["ref_by"] = vp_user_array($user_array,$id, "vp_who_ref",true);
$array["cheepa"] = 0;
}

$bank_mode = vp_user_array($user_array,$id,"account_mode",true);					
$array["bank_mode"] = $bank_mode;
if($bank_mode == "live"){
$array["bank_ref"] = vp_user_array($user_array,$id,"bank_reference",true);
$array["account_name"] = vp_user_array($user_array,$id,"account_name",true);
$array["account_number"] = vp_user_array($user_array,$id,"account_number",true);
$array["bank_name"] = vp_user_array($user_array,$id,"bank_name",true);

}
else{
$array["bank_ref"] = "NULL";
$array["account_name"] = "NULL";
$array["account_number"] = "NULL";
$array["bank_name"] = "NULL";

}



$array["template_url"] = plugins_url("vtupress/template");
			
return $array;
}






vp_addoption("vp_whatsapp_group","link");

vp_addoption("vp_template","default");

$vp_temp = vp_getoption("vp_template");

if($vp_temp != "default" && $vp_temp != "classic"){
	$vp_temp = "default";
}
else{
	$vp_temp = vp_getoption("vp_template");
}



define('vtupress_template',$vp_temp);


function vp_kyc_update(){
	$id = get_current_user_id();

$option_array = json_decode(get_option("vp_options"),true);
$user_array = json_decode(get_user_meta($id,"vp_user_data",true),true);
$kyc_status = vp_user_array($user_array,$id,'vp_kyc_status',true);
$kyc_end = vp_user_array($user_array,$id,'vp_kyc_end',true);
$kyc_total = vp_user_array($user_array,$id,'vp_kyc_total',true);

global $wpdb;
$table_name = $wpdb->prefix."vp_kyc_settings";
$kyc_data = $wpdb->get_results("SELECT * FROM $table_name WHERE id = 1");

if(strtolower($kyc_status) != "verified" && strtolower($kyc_data[0]->enable) == "yes"){
$datenow = date("Y-m-d"); #date('Y-m-d',strtotime($date." +3 days"));
$next_end_date = $kyc_end;
		if($datenow < $next_end_date || $next_end_date == "0" || empty($next_end_date)){ //check if current date is less than next or if next is zero
		
			if($next_end_date == "0" || empty($next_end_date)){
				//echo "set next_end_date to datenow + limit";
				
				if(strtolower($kyc_data[0]->duration) == "day"){
				vp_updateuser($id,"vp_kyc_end",date('Y-m-d',strtotime($datenow." +1 days")));
				vp_updateuser($id,'vp_kyc_total',"0");
				}
				elseif(strtolower($kyc_data[0]->duration) == "month"){
				vp_updateuser($id,"vp_kyc_end",date('Y-m-d',strtotime($datenow." +1 month")));
				vp_updateuser($id,'vp_kyc_total',"0");
				}
			}
		}
			elseif($datenow >= $next_end_date){
			if(strtolower($kyc_data[0]->duration) == "day"){
				vp_updateuser($id,"vp_kyc_end",date('Y-m-d',strtotime($datenow." +1 days")));
				vp_updateuser($id,'vp_kyc_total',"0");
				}
				elseif(strtolower($kyc_data[0]->duration) == "month"){
				vp_updateuser($id,"vp_kyc_end",date('Y-m-d',strtotime($datenow." +1 month")));
				vp_updateuser($id,'vp_kyc_total',"0");
				}
			//echo "Permit Transaction";
		}

$kyc_status = vp_user_array($user_array,$id,'vp_kyc_status',true);
$kyc_end = vp_user_array($user_array,$id,'vp_kyc_end',true);
$kyc_total = vp_user_array($user_array,$id,'vp_kyc_total',true);
if(empty($kyc_total)){
	$used  = 0;
}
else{
	$used = $kyc_total;
}

$allowed = ucfirst($kyc_data[0]->duration);
if($allowed == "Total"){
	
	$tot = "Total";
}
else{
	$tot = "One $allowed";
}

$limit = $kyc_data[0]->kyc_limit;
echo"
<div class='row my-3'>
<div class='col font-bold text-white bg bg-danger p-3 rounded shadow'>
You have consumed ₦$used out of ₦$limit in $tot 
<br>
<small>Please verify your account <b><a style='text-decoration:none;' class='text-white' href='?vend=kyc'>{ Here }</a></b></small>
</div>
</div>

";

}


}

?>