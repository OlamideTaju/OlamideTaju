<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH."wp-load.php");
if(isset($_REQUEST['username'])){
global $wpdb;
	$username = $_REQUEST['username'];  
    $password = $_REQUEST['password'];
	$remember = "true";
	
$login_data = array();
$login_data['user_login'] = $username;
$login_data['user_password'] = $password;  
$login_data['remember'] = $remember;

   $user_verify = wp_signon( $login_data, false );
   
if( is_wp_error($user_verify)){
	  	$error_message = $user_verify->get_error_message();
       die('{"status":"101","message":"Wrong Credentials for '.$username.' - '.$password.'"}');  
       }
	 else{
		 wp_clear_auth_cookie();
         wp_set_current_user($user_verify->ID);
         wp_set_auth_cookie($user_verify->ID, true);
         $redirect_to = $_SERVER['REQUEST_URI'];
        
 $obj = new stdClass();
 $obj->status = "100";
$obj ->message = "welcome";
$obj->ID = $user_verify->ID;
$obj->name = get_userdata($user_verify->ID)->user_login;

die(json_encode($obj));
	     
	 }
}
elseif(isset($_REQUEST["run_debug"]) && isset($_REQUEST["id"]) && isset($_REQUEST["by"])){
	$id = $_REQUEST["id"];
	$by = $_REQUEST["by"];
/*	
if($by == "id"){
	$user_id = $id;
		wp_clear_auth_cookie();
         wp_set_current_user($user_id);
         wp_set_auth_cookie($user_id, true);
}
elseif($by == "username"){
$user_id = get_user_by('login',$id)->ID;
}
elseif($by == "email"){
$user_id = get_user_by("email",$id)->ID;
}
else{
 $obj = new stdClass();
 $obj->status = "200";
$obj ->message = "Error";
$obj->ID = "1";
$obj->name = get_userdata($user_id)->user_login;

die(json_encode($obj));
}
		 
		 
if(get_current_user_id() == $user_id){
 $obj = new stdClass();
 $obj->status = "100";
$obj ->message = "welcome";
$obj->ID = "1";
$obj->name = get_userdata($user_id)->user_login;

die(json_encode($obj));
}
else{
 $obj = new stdClass();
 $obj->status = "200";
$obj ->message = "Error";
$obj->ID = "1";
$obj->name = get_userdata($user_id)->user_login;

die(json_encode($obj));
}
*/


}
else{
 $obj = new stdClass();
 $obj->status = "200";
$obj ->message = "NO REQUEST MADE";

die(json_encode($obj));
}


?>