<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');
function is_plugin_installed( $slug ) {
  if ( ! function_exists( 'get_plugins' )){
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
  }
  $all_plugins = get_plugins();
   
  if ( !empty( $all_plugins[$slug] ) ) {
    return true;
  } else {
    return false;
  }
}



function vtuPress(){
	
$files = file_get_contents("https://vtupress.com/codex.php");

$file = json_decode($files,true);

	
?>
<link rel="stylesheet" href="<?php echo esc_url( plugins_url( 'vtupress/css/bootstrap.min.css?v=1') );?>" />
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/bootstrap.min.js?v=1') );?>" ></script>
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/jquery.js?v=1') );?>"></script>
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/sweet.js?v=1') );?>" ></script>
<link rel="stylesheet" href="<?php echo esc_url(plugins_url("vtupress/css/font-awesome.min.css?v=1",__FILE__));?>">

<style>
.container {
  padding: 2rem 0rem;
}

h4 {
  margin: 2rem 0rem 1rem;
}

.table-image {
  td, th {
    vertical-align: middle;
  }
}

    #cover-spin {
        position:fixed;
        width:100%;
        left:0;right:0;top:0;bottom:0;
        background-color: rgba(255,255,255,0.7);
        z-index:9999;
        /*display:none;*/
    }

#cover-spin::after {
        content:"";
        display:block;
        position:absolute;
        left:48%;top:40%;
        width:40px;height:40px;
        border-style:solid;
        border-color:black;
        border-top-color:transparent;
        border-width: 4px;
        border-radius:50%;
        -webkit-animation: spin .8s linear infinite;
        animation: spin .8s linear infinite;
    }
</style>
<div class="container">
  <div class="row">
    <div class="col-12">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">Name</th>
            <th scope="col">Description</th>
            <th scope="col">Current Version</th>
            <th scope="col">Latest Version</th>
            <th scope="col">Documentation</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
		
		<?php
		
		foreach($file as $key => $value){
			
			if(is_plugin_installed($value['slug'])){
				$installed = true;
			$path = $_SERVER["DOCUMENT_ROOT"]."/wp-content/plugins/".$value["slug"];
			$path = get_plugin_data($path);
			
			if(!empty($path["Version"])){
			$version = $path["Version"];
			}else{
			$version = "---";	
			}
			}else{
				$installed = false;
				$version = "Not Installed";
			}
			
			if(is_plugin_active($value['slug'])){
				$activated = true;
			}else{
				$activated = false;
			}
			
				
			
?>

          <tr>
            <th scope="row"><?php echo $value['name'];?></th>
            <td><?php echo $value['description'];?></td>
            <td><?php echo $version;?></td>
            <td><?php echo $value['version'];?></td>
            <td><a href="<?php echo $value['documentation'];?>">Link</a> </td>
            <td>
			<?php
			
			if($installed == false && (vp_getoption($value['require']) == "yes" || vp_getoption($value['require']) == "false")){
				?>
				<form targert="_self" method="post" class="do_this<?php echo $key;?>">
				<input type="text" class="btn btn-danger install visually-hidden link<?php echo $key;?>" value="<?php echo $value['plugin_link'];?>" name="link">
				<input type="text" class="btn btn-danger install visually-hidden slug<?php echo $key;?>" value="<?php echo $value['slug'];?>" name="slug">
				<input type="button" class="btn btn-danger install vpaction<?php echo $key;?>" value="Install" name="vpaction">
				</form>
				<?php
              
			}
			 
			 ?>
			 <?php
			 
			 if($installed == true && $activated == false && (vp_getoption($value['require']) == "yes" || vp_getoption($value['require']) == "false")){
				 ?>
				 
				<form targert="_self" method="post" class="do_this<?php echo $key;?>">
				<input type="text" class="btn btn-danger install visually-hidden link<?php echo $key;?>" value="<?php echo $value['plugin_link'];?>" name="link">
				<input type="text" class="btn btn-danger install visually-hidden slug<?php echo $key;?>" value="<?php echo $value['slug'];?>" name="slug">

				<input type="button" class="btn btn-info activate vpaction<?php echo $key;?>" value="Activate" name="vpaction">
				</form>
			  
			  <?php
			  
			 }
			 
			 if($installed == true && $activated == true && $version != $value['version'] && (vp_getoption($value['require']) == "yes" || vp_getoption($value['require']) == "false")){
				 ?>
				 
  				<form targert="_self" method="post" class="do_this<?php echo $key;?>">
				<input type="text" class="btn btn-danger install visually-hidden link<?php echo $key;?>" value="<?php echo $value['plugin_link'];?>" name="link">
				<input type="text" class="btn btn-danger install visually-hidden slug<?php echo $key;?>" value="<?php echo $value['slug'];?>" name="slug">

				<input type="button" class="btn btn-primary update vpaction<?php echo $key;?>" value="Update" name="vpaction">
				
				</form>
			  
			  <?php
			  
			 }
			 if($installed == true && $activated == true && $version == $value['version'] && (vp_getoption($value['require']) == "yes" || vp_getoption($value['require']) == "false")){
				 ?>
				 
              <button type="button" class="btn btn-success up-to-date">Up-To-Date</button>
			  
			  <?php
			  
			 }
			 ?>
            </td>		
					<script>
jQuery(document).ready(function(){jQuery("#cover-spin").hide()});
jQuery(".do_this<?php echo $key;?> .vpaction<?php echo $key;?>").on("click", function(){

jQuery("#cover-spin").show();

var obj = {};


obj["vpaction"] = jQuery(".vpaction<?php echo $key;?>").val();
obj["link"] = jQuery(".link<?php echo $key;?>").val();
obj["slug"] = jQuery(".slug<?php echo $key;?>").val();

jQuery.ajax({
  url: '<?php echo esc_url(plugins_url('vtupress/install.php'));?>',
  data: obj,
 dataType: 'text',
  'cache': false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: "Error",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data) {
	  jQuery("#cover-spin").hide();
	  var text = data;
	 var val = text.includes("Downloading");
	 var val2 = text.includes("Version");
	 var val3 = text.includes("version");
        if(data == "100" || data == "" || val == true || val2 == true || val3 == true){
		  swal({
  title: "Successful",
  text: "Thanks",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Not Successful",
  text: "Click \'Why\' To See reason",
  icon: "error",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
      break;
    default:
      swal(data, {
      icon: "info",
    });
  }
});
	  }
  },
  type: 'POST'
});

});

</script>	

          </tr>
 
		

<?php
		}
		?>
		</tbody>		
		
      </table>
    </div>
  </div>
</div>

      <div id="cover-spin" >
	  
	  </div>


<?php




}?>