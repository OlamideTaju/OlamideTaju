<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH ."wp-load.php");
include_once(ABSPATH.'wp-content/plugins/vtupress/functions.php');



if(isset($_REQUEST['gateway'])){
$psec = vp_getoption('psec');
$gateway = $_REQUEST['gateway'];

if(vp_getoption("charge_method") == "fixed"){
$amount = intval($_REQUEST["amount"]) - intval(vp_getoption("charge_back"));
}
else{
$remove = (intval($_REQUEST["amount"]) *  intval(vp_getoption("charge_back"))) / 100;
$amount = intval($_REQUEST["amount"]) - $remove;
}

switch($gateway){
	
	
	case"paystack":
	if(isset($_REQUEST["status"]) && $_REQUEST["status"] == "successful"){
$ref = $_REQUEST["reference"];
$curl = curl_init();
  
  curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.paystack.co/transaction/verify/".$ref,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => array(
      "Authorization: Bearer ".$psec,
      "Cache-Control: no-cache"
    ),
  ));
  
  $response = curl_exec($curl);
  $err = curl_error($curl);
  curl_close($curl);
  
  if ($err) {
  //  echo "cURL Error #:" . ;
	die($err);
  }
  else{

$userid = get_current_user_id();
$ini = vp_getuser($userid, 'vp_bal', true);
$tot = $ini+$amount;
vp_updateuser($userid, 'vp_bal', $tot);



global $wpdb;
$name = get_userdata($userid)->user_login;
$email = get_userdata($userid)->user_email;
$description = 'Credited By You [Online]';
$fund_amount = $amount;
$before_amount = $ini;
$now_amount = $tot;
$user_id = $userid;
$the_time = current_time('mysql', 1);

$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $name,
'type'=> 'wallet',
'description'=> $description,
'fund_amount' => $fund_amount,
'before_amount' => $before_amount,
'now_amount' => $now_amount,
'user_id' => $user_id,
'status' => "approved",
'the_time' => current_time('mysql', 1)
));

//wp_mail($admine, "$user_name Wallet Funding [PATSTACK - N-WEB]", $content, $headers);
//wp_mail($email, "$user_name Wallet Funding [PAYSTACK - N-WEB]", $content, $headers);

die("100");



  }
  
}
  
  break;
  
}



}

?>