<?php

if(isset($_GET["vend"]) && $_GET["vend"]=="wallet"){
			?>
<script>
jQuery("body").ready(function(){
		jQuery("#airtimehist").show();
		jQuery("#datahist").hide();
		jQuery("#cablehist").hide();
		jQuery("#billhist").hide();
});
</script>
<?php
			global $wpdb;
$table_name = $wpdb->prefix."flutterwave";
$num = 1;
$results = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE ID = %d", $num));
$k = $results->public_key;
$sec = $results->secret_key;
$user_email = get_userdata($id)->user_email;

if($bank_mode == "live"){
?>
<div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingZero">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseZero" aria-expanded="false" aria-controls="flush-collapseZero">
       Automated Funding
      </button>
    </h2>
    <div id="flush-collapseZero" class="accordion-collapse collapse" aria-labelledby="flush-headingZero" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">
			
				<style>
/* Shoutout to Maite Rosalie for the gold svg gradient which can be seen here below. */

/* https://codepen.io/maiterosalie/pen/ppRRLV?q=gold+gradient&limit=all&type=type-pens */

.Wrap {
  display: flex;
  justify-content: center;
  align-items: center;
   background: #f4f6f9;
  font-family: 'Roboto', sans-serif;
  font-weight: 400;
}

.Wrap .Base {
  background: #ccc;
  height: 100%;
  width: 100%;
  border-radius: 15px;
}

.Wrap .Inner-wrap {
  background-color: #0c0014;
background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100%25' height='100%25' viewBox='0 0 1600 800'%3E%3Cg %3E%3Cpolygon fill='%230d1838' points='1600%2C160 0%2C460 0%2C350 1600%2C50'/%3E%3Cpolygon fill='%230e315d' points='1600%2C260 0%2C560 0%2C450 1600%2C150'/%3E%3Cpolygon fill='%230f4981' points='1600%2C360 0%2C660 0%2C550 1600%2C250'/%3E%3Cpolygon fill='%231062a6' points='1600%2C460 0%2C760 0%2C650 1600%2C350'/%3E%3Cpolygon fill='%23117aca' points='1600%2C800 0%2C800 0%2C750 1600%2C450'/%3E%3C/g%3E%3C/svg%3E");
  background-size: auto 147%;
  background-position: center;
  position: relative;
  height: 100%;
  width: 100%;
  border-radius: 13px;
  padding: 20px 40px;
  box-sizing: border-box;
  color: #fff;
}

.Wrap p {
  margin: 0;
  font-size: 2em;
}

/* Controls top right logo */

.Wrap .Logo {
  position: absolute;
  height: 80px;
  width: 80px;
  right: 0;
  top: 0;
  padding: inherit;
  fill: #117aca;
}

/* Controls chip icon */

.Wrap .Chip {
  height: 40px;
  margin: 20px 0 25px 0;
}

.Wrap .gold path{
  fill: url(#gold-gradient);
}

.Wrap svg {
  display: block;
}

/* Controls name size */

.Wrap .Logo-name {
  transform: scale(.5);
  margin-left: -75px;
}

.Wrap .Card-number p {
  text-align: center;
}

.Wrap .Card-number {
  margin-top: -25px;
  display: flex;
  justify-content: center;
  color: rgba(255, 255, 255, 0.9);
}

.Wrap ul {
  padding: 0;
}

.Wrap ul li {
  list-style: none;
  float: left;
  margin: 0px 10px;
  font-size: 2.2em;
}

.Wrap #first-li {
  margin-left: 0;
}

.Wrap #last-li {
  margin-right: 0;
}

.Wrap .Expire {
  font-size: .75em;
  text-align: center;
}

.Wrap .Expire h4 {
  font-weight: 400;
  color: #aaa;
  margin: 0;
/*   word-spacing: 9999999px; */
  text-transform: uppercase;
}

.Expire p {
  font-size: 1.55em;
  color: rgba(255, 255, 255, 0.9);
}

.Wrap .Name h3 {
  position: relative;
  bottom: 0;
  text-align:center;
  text-transform: uppercase;
  font-weight: 400;
  font-size: 1.35em;
  color: rgba(255, 255, 255, 0.85);
}

.Wrap .Visa {
  width: 115px;
  position: relative;
  right: 0;
}

</style>
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">

<div class="Wrap mb-2 cdebit-card">
  <div class="Base">
    <div class="Inner-wrap">

      
<!--       Header SVG -->
      
      
      <h1 class="Logo-name"><?php echo $bank_name;?></h1>

      
      
<!--       Logo SVG -->
      
        
      
      
      
<!-- Card Chip SVG -->
      
      <svg class="Chip" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 387.8 380.3" style="enable-background:new 0 0 387.8 380.3;" xml:space="preserve">
<style type="text/css">
	.st0{fill:url(#gold-gradient);stroke:#000000;stroke-width:10;stroke-miterlimit:10;}
</style>
<defs>
<linearGradient id="gold-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#c79750"></stop>
      <stop offset="20%" stop-color="#e6b964"></stop>
      <stop offset="50%" stop-color=" #f8e889"></stop>
      <stop offset="80%" stop-color=" #deb15f"></stop>
      <stop offset="100%" stop-color=" #dfb461"></stop>
    </linearGradient>
</defs>
<g id="XMLID_4_">
	<path id="XMLID_1_" class="st0" d="M308.8,375.3H79.1C38.2,375.3,5,342.1,5,301.2V79.1C5,38.2,38.2,5,79.1,5h229.7
		c40.9,0,74.1,33.2,74.1,74.1v222.2C382.8,342.1,349.7,375.3,308.8,375.3z"></path>
	<line id="XMLID_2_" class="st0" x1="109.9" y1="5.1" x2="109.9" y2="375.1"></line>
	<line id="XMLID_3_" class="st0" x1="4.9" y1="95.1" x2="109.9" y2="95.1"></line>
	<line id="XMLID_7_" class="st0" x1="4.9" y1="185.1" x2="109.9" y2="185.1"></line>
	<line id="XMLID_8_" class="st0" x1="1.9" y1="275.1" x2="106.9" y2="275.1"></line>
	<line id="XMLID_9_" class="st0" x1="276.9" y1="275.1" x2="381.9" y2="275.1"></line>
	<line id="XMLID_10_" class="st0" x1="274.9" y1="185.1" x2="379.9" y2="185.1"></line>
	<line id="XMLID_11_" class="st0" x1="277.9" y1="95.1" x2="382.9" y2="95.1"></line>
	<g id="XMLID_6_">
		<g id="XMLID_14_">
			<g id="XMLID_32_">
				<path id="XMLID_33_" d="M277.4,90.1h-1c-2.5,0-4.5,2-4.5,4.5v272c0,2.5,2,4.5,4.5,4.5h1c2.5,0,4.5-2,4.5-4.5v-272
					C281.9,92.1,279.9,90.1,277.4,90.1z"></path>
			</g>
		</g>
	</g>
</g>
</svg>
      <div class="Card-number">
        <ul>
          <li id="first-li"><?php echo $account_number;?></li>
        </ul>
      </div>
      
      
      
      <div class="Name">
        <h3><?php echo $account_name;?></h3>
      </div>
      
<!--       Visa Logo SVG -->
      
       <h4 class="Visa visually-hidden"><?php echo $bank_mode."_".$bank_ref;?></h4>
        
    </div>
  </div>
</div>

	
	

	 
		</div>
    </div>
  </div>
 <?php
}

if(vp_getoption("allow_card_method") == "yes"){
?>

  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        Card Payment & Payment Gateway
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">
<?php
echo'
	 		<style>
		  .side-wallet-w{background-color: white !important;
    padding: 20px !important;
    text-align: center !important;
    border-radius: 10px !important;
	border:2px solid purple;
		  }
		  
		</style>
		
<div id="side-wallet-w" class="side-wallet-w bg-gray-600 ">
<lead>Current Balance : <span class="user-balance">'.$bal.'</span></lead>

<div class="fund-self-wallet">
<h4>Fund Account</h4>
<form method="post" > 
<label class="form-label">Amount</label><br>
<input type="number" name="amount" class="form-control mb-2" required><br>
<div class="input-group" id="basic-addon1">
';
if(vp_getoption("charge_method") == "fixed"){
	?>
<span class="input-group-text">Charge In ₦</span>
<?php
}
else{
		?>
<span class="input-group-text">Charge In %</span>
<?php
}
echo'
<input type="number" name="charge" class="form-control mb-2" readonly value="'.intval(vp_option_array($option_array,"charge_back")).'">
</div>
<input style="background-color:white;" type="hidden" name="vpemail" value="'.$user_email.'" class="form-control">
<input type="hidden" name="tcode" value="wallet" >
<input type="hidden" name="userid" value="'.$id.'">
<input type="submit" name="pay" value="Fund Wallet" formaction="/wp-content/plugins/vtupress/pay.php" style="background-color:#9c27b0; color:white; padding:10px; border-radius:10px; border:0;" class="mb-2 form-control p-3 text-xs font-bold text-white uppercase bg-indigo-600 rounded shadow  "><br>
<input type="hidden" name="amounte" value="1">
<input type="hidden" id="id" name="id" value="'.uniqid("VTU-",false).'"><br>
<input type="hidden" value="'.$sec.'" name="secret"><br>
<input type="hidden" id="url1" name="url1" value="'.vp_option_array($option_array,'siteurl')."/wp-content/plugins/vtupress/process.php".'">
</form>
</div>
</div>
	';?> 
	 
		</div>
    </div>
  </div>
 
<?php
}
?>

 <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
        Manual Bank Transfer
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">
	  
      <div style="text-align:center; background-color: #6c6cd426;"><?php echo vp_option_array($option_array,'manual_funding');?></div>

	  </div>
    </div>
  </div>
 
 <?php
 if(vp_option_array($option_array,"airtime_to_cash") == "yes" || vp_option_array($option_array,"airtime_to_wallet") == "yes" && vp_option_array($option_array,"resell") == "yes"){
?>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
        Airtime Conversion
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">
	<div class="container-md mt-3">
    <div class="p-3" style="border: 1px solid grey; border-radius: 5px;">
	    <div class="mb-2">
			<label class="form-label">Conversion</label>
			<select class="conversion form-select" name="conversion">
			<option value="none">---Select---</option>
			<?php
			if(vp_option_array($option_array,"airtime_to_wallet") == "yes"){
				?>
			<option value="wallet">Airtime To Wallet</option>
			<?php
			}
			if(vp_option_array($option_array,"airtime_to_cash") == "yes"){
			?>
			<option value="cash">Airtime To Cash</option>
			<?php
			}
			?>
			</select>
			<label class="form-label">Network</label>
			<select class="network form-select" name="network">
			<option value="none">---Select---</option>
			<?php
			if(!empty(vp_option_array($option_array,"mtn_airtime")) && vp_option_array($option_array,"mtn_airtime") != "08012346789"){
				?>
				<option value="mtn">MTN</option>
				<?php
			}
			if(!empty(vp_option_array($option_array,"glo_airtime")) && vp_option_array($option_array,"glo_airtime") != "08012346789"){
				?>
				<option value="glo">GLO</option>
				<?php
			}
			if(!empty(vp_option_array($option_array,"airtel_airtime")) && vp_option_array($option_array,"airtel_airtime") != "08012346789"){
				?>
				<option value="airtel">AIRTEL</option>
				<?php
			}
			if(!empty(vp_option_array($option_array,"9mobile_airtime")) && vp_option_array($option_array,"9mobile_airtime") != "08012346789"){
				?>
				<option value="9mobile">9MOBILE</option>
				<?php
			}
				?>
			</select>
			<label class="form-label">Amount</label>
			<input type="number"  name="amount" class="amount form-control"value="">
			<div class="bank_div">
			<label class="form-label">Account Details</label>
			<textarea class="bank form-control" name="bank"></textarea>
			</div>
			<label class="form-label">To Be Transfered From</label>
			<input type="number"  name="transfer_from" class="transfer_from form-control" value="" placeholder="Phone Number">
			<label class="form-label">Pay To</label>
			<input type="text"  name="pay_to" class="pay_to form-control" readOnly value="">
			<label class="form-label">Charge</label>
			<div class="input-group">
			<input type="number" name="pay_charge" class="pay_charge form-control" readOnly value="0">
			<span class="input-group-text">%</span>
			</div>
			<label class="form-label">You'll Get</label>
			<input type="text" name="pay_get" class="pay_get form-control" readOnly value="">
			<input type="button" name="convert_it" value="Convert" class="form-control mt-2 convert_it w-full p-3 text-xs font-bold text-white uppercase bg-indigo-600 rounded shadow text-light">
		</div>
		
<script>

var convert = jQuery("select.conversion").val();
		jQuery(".conversion").val("none");
		jQuery(".network").val("none");
if(convert == "wallet"){
	jQuery(".network").val("none");
		jQuery(".bank_div").hide();
}
else if(convert == "cash"){
	jQuery(".network").val("none");
	jQuery(".bank_div").show();
}
else{
	jQuery(".pay_charge").val("0");
	jQuery(".network").val("none");
		jQuery(".bank_div").hide();
}


jQuery("select.conversion").on("change",function(){
	var convert = jQuery("select.conversion").val();
	
if(convert == "wallet"){
//jQuery(".pay_charge").val("<?php echo intval(vp_option_array($option_array,'airtime_to_wallet_charge'));?>");
		jQuery(".network").val("none");
		/*
	var minus = (parseInt(jQuery(".amount").val()) * parseInt(jQuery(".pay_charge").val()))/100;
	var charge = parseInt(jQuery(".amount").val()) - minus;
		jQuery(".bank_div").hide();
	jQuery(".pay_get").val(charge);
	*/
}
if(convert == "cash"){
//jQuery(".pay_charge").val("<?php echo intval(vp_option_array($option_array,'airtime_to_cash_charge'));?>");
		jQuery(".network").val("none");
			jQuery(".bank_div").show();
			/*
	var minus = (parseInt(jQuery(".amount").val()) * parseInt(jQuery(".pay_charge").val()))/100;
	var charge = parseInt(jQuery(".amount").val()) - minus;
	
	jQuery(".pay_get").val(charge);
	*/
}
	
});

jQuery("select.network").on("change",function(){
	var network = jQuery("select.network").val();
	var conversion = jQuery("select.conversion").val();
	switch(conversion){
		case"wallet":
if(network == "mtn"){
	jQuery("input.pay_to").val("<?php echo intval(vp_option_array($option_array,'mtn_airtime'));?>");
	jQuery(".pay_charge").val("<?php echo intval(vp_option_array($option_array,'airtime_to_wallet_charge'));?>");
	var minus = (parseInt(jQuery(".amount").val()) * <?php echo intval(vp_option_array($option_array,'airtime_to_wallet_charge'));?>)/100;
	var charge = parseInt(jQuery(".amount").val()) - minus;
	
	jQuery(".pay_get").val(charge);
}

if(network == "glo"){
	jQuery("input.pay_to").val("<?php echo intval(vp_option_array($option_array,'glo_airtime'));?>");
			jQuery(".pay_charge").val("<?php echo intval(vp_option_array($option_array,'gairtime_to_wallet_charge'));?>");
	var minus = (parseInt(jQuery(".amount").val()) * <?php echo intval(vp_option_array($option_array,'gairtime_to_wallet_charge'));?>)/100;
	var charge = parseInt(jQuery(".amount").val()) - minus;
	
	jQuery(".pay_get").val(charge);
}

if(network == "airtel"){
	jQuery("input.pay_to").val("<?php echo intval(vp_option_array($option_array,'airtel_airtime'));?>");
			jQuery(".pay_charge").val("<?php echo intval(vp_option_array($option_array,'aairtime_to_wallet_charge'));?>");
	var minus = (parseInt(jQuery(".amount").val()) * <?php echo intval(vp_option_array($option_array,'aairtime_to_wallet_charge'));?>)/100;
	var charge = parseInt(jQuery(".amount").val()) - minus;
	
	jQuery(".pay_get").val(charge);
}

if(network == "9mobile"){
	jQuery("input.pay_to").val("<?php echo intval(vp_option_array($option_array,'9mobile_airtime'));?>");
			jQuery(".pay_charge").val("<?php echo intval(vp_option_array($option_array,'9airtime_to_wallet_charge'));?>");
	var minus = (parseInt(jQuery(".amount").val()) * <?php echo intval(vp_option_array($option_array,'9airtime_to_wallet_charge'));?>)/100;
	var charge = parseInt(jQuery(".amount").val()) - minus;
	
	jQuery(".pay_get").val(charge);
}

break;
		case"cash":
if(network == "mtn"){
	jQuery("input.pay_to").val("<?php echo intval(vp_option_array($option_array,'mtn_airtime'));?>");
			jQuery(".pay_charge").val("<?php echo intval(vp_option_array($option_array,'airtime_to_cash_charge'));?>");
	var minus = (parseInt(jQuery(".amount").val()) * <?php echo intval(vp_option_array($option_array,'airtime_to_cash_charge'));?>)/100;
	var charge = parseInt(jQuery(".amount").val()) - minus;
	
	jQuery(".pay_get").val(charge);
}

if(network == "glo"){
	jQuery("input.pay_to").val("<?php echo intval(vp_option_array($option_array,'glo_airtime'));?>");
				jQuery(".pay_charge").val("<?php echo intval(vp_option_array($option_array,'gairtime_to_cash_charge'));?>");	
	var minus = (parseInt(jQuery(".amount").val()) * <?php echo intval(vp_option_array($option_array,'gairtime_to_cash_charge'));?>)/100;
	var charge = parseInt(jQuery(".amount").val()) - minus;
	
	jQuery(".pay_get").val(charge);
}

if(network == "airtel"){
	jQuery("input.pay_to").val("<?php echo intval(vp_option_array($option_array,'airtel_airtime'));?>");
				jQuery(".pay_charge").val("<?php echo intval(vp_option_array($option_array,'aairtime_to_cash_charge'));?>");
	var minus = (parseInt(jQuery(".amount").val()) * <?php echo intval(vp_option_array($option_array,'aairtime_to_cash_charge'));?>)/100;
	var charge = parseInt(jQuery(".amount").val()) - minus;
	
	jQuery(".pay_get").val(charge);
}

if(network == "9mobile"){
	jQuery("input.pay_to").val("<?php echo intval(vp_option_array($option_array,'9mobile_airtime'));?>");
	jQuery(".pay_charge").val("<?php echo intval(vp_option_array($option_array,'9airtime_to_cash_charge'));?>");
	var minus = (parseInt(jQuery(".amount").val()) * <?php echo intval(vp_option_array($option_array,'9airtime_to_cash_charge'));?>)/100;
	var charge = parseInt(jQuery(".amount").val()) - minus;
	
	jQuery(".pay_get").val(charge);
}

break;


	}
	
});

jQuery(".amount").on("change",function(){
	var minus = (parseInt(jQuery(".amount").val()) * parseInt(jQuery(".pay_charge").val()))/100;
	var charge = parseInt(jQuery(".amount").val()) - minus;
	
	jQuery(".pay_get").val(charge);
});



jQuery(".convert_it").click(function(){

	var minus = (parseInt(jQuery(".amount").val()) * parseInt(jQuery(".pay_charge").val()))/100;
	var charge = parseInt(jQuery(".amount").val()) - minus;
	
	jQuery(".pay_get").val(charge);
	
jQuery("#cover-spin").show();
	
var obj = {};
obj["convert_it"] = "airtime";
obj["conversion"] = jQuery(".conversion").val();
obj["network"] = jQuery(".network").val();
obj["pay_to"] = jQuery(".pay_to").val();
obj["pay_charge"] = jQuery(".pay_charge").val();
obj["pay_get"] = jQuery(".pay_get").val();
obj["amount"] = jQuery(".amount").val();
obj["bank"] = jQuery(".bank").val();
obj["from"] = jQuery(".transfer_from").val();
jQuery.ajax({
  url: '<?php echo esc_url(plugins_url('vtupress/vend.php'));?>',
  data: obj,
 dataType: 'text',
  'cache': false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data) {
	  jQuery("#cover-spin").hide();
        if(data == "100"){
		  swal({
  title: "Conversion Submitted",
  text: "We'll Approve Your Conversion After Confirmation",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Submission Failed",
  text: "Click \'Why\' To See reason",
  icon: "error",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
      break;
    default:
      swal(data, {
      icon: "info",
    });
  }
});
	  }
  },
  type: 'POST'
});

});

</script>
	
	</div>
	</div>
	  
	  </div>
    </div>
  </div>
<?php
 }
 if(vp_option_array($option_array,"enable_coupon") == "yes" && vp_option_array($option_array,"resell") == "yes"){
?>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFour">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
        Coupon Funding
      </button>
    </h2>
    <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">
	<div class="container-md mt-3">
    <div class="p-3" style="border: 1px solid grey; border-radius: 5px;">
	    <div class="mb-2">
		<label class="form-label">Coupon Code</label>
			<input type="text" name="coupon_code" class="coupon_code form-control">
			<input type="button" name="run_coupon" value="Redeem Code" class="form-control run_coupon btn btn-secondary w-full p-2 text-xs font-bold text-white uppercase bg-indigo-600 rounded shadow text-light">
		</div>
		
<script>


jQuery(".run_coupon").click(function(){
	
jQuery("#cover-spin").show();
	
var obj = {};
obj["run_coupon"] = jQuery(".coupon_code").val();
jQuery.ajax({
  url: '<?php echo esc_url(plugins_url('vtupress/coupon.php'));?>',
  data: obj,
 dataType: 'json',
  'cache': false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data) {
	  jQuery("#cover-spin").hide();
        if(data.status == "100"){
		  swal({
  title: "Redeemed",
  text: data.message,
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Redeem Failed",
  text: "Click \'Why\' To See reason",
  icon: "error",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
      break;
    default:
      swal(data.message, {
      icon: "info",
    });
  }
});
	  }
  },
  type: 'POST'
});

});

</script>
	
	</div>
	</div>
	  
	  </div>
    </div>
  </div>
<?php
 }
 ?>
  
</div>


<?php

}
		
		
		?>