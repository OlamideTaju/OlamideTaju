
<?php

if(isset($_GET["vend"]) && $_GET["vend"]=="developer" && is_plugin_active("vprest/vprest.php") && vp_option_array($option_array,"resell") == "yes" && isset($level)){
	
if(strtolower($level[0]->developer) == "yes"){
?>
<h3>Developers Api Documentation</h3><br>
<div class="col">
<div class="mb-3">
<h5>End Point</h5><br>
Method: [Post or Get]<br>
<?php echo esc_url(plugins_url('vprest/')); ?>
</div>
<div class="mb-3">
<h5>Authentication</h5><br>
<p>Requirements are <code>ID(<?php echo get_current_user_id();?> )</code> and <code>ApiKey</code> </p>
<p>Your API key can be found <a href="?vend=upgrade">here</a></p>

</div>
<div class="mb-3">
<h5>Check User Details [Get/Post]</h5><br>
Parameters:<br>
<table class="table table-responsive table-hover">
<tbody>
<tr>
<th  scope="col">Parameter</th>
<th  scope="col">Meaning</th>
<th  scope="col">Value</th>
</tr>
<tr>
<td>q</td>
<td>Query</td>
<td>user</td>
</tr>
<tr>
<td>id</td>
<td>your user id</td>
<td>20</td>
</tr>
<tr>
<td>apikey</td>
<td>your Api key</td>
<td>23403</td>
</tr>
</tbody>
</table>
<br>
Example: <?php echo esc_url(plugins_url('vprest/?q=user&id=20&apikey=12345'));?><br>

Response [JSON]: {"Status":"100","Successful":"true","Id":"20","Plan":"reseller","Balance":"13372","Referred_By":"0"}<br>

<!--https://dev.betabundles.com.ng/wp-content/plugins/vprest/?id=1&apikey=2344&q=data&phone=07049626922&amount=200&network=mtn&type=sme&dataplan=1-->
</div>

<div class="mb-3">
<h5>Buy Airtime [Get/Post]</h5><br>
Parameters:<br>
<table>
<tbody>
<table class="table table-responsive table-hover">
<tbody>
<tr>
<th  scope="col">Parameter</th>
<th  scope="col">Meaning</th>
<th  scope="col">Value</th>
</tr>
<tr>
<td>q</td>
<td>Query</td>
<td>user</td>
</tr>
<tr>
<td>id</td>
<td>your user id</td>
<td>20</td>
</tr>
<tr>
<td>apikey</td>
<td>your Api key</td>
<td>23403</td>
</tr>
<tr>
<td>phone</td>
<td>recipient phone number</td>
<td>07049626922</td>
</tr>
<tr>
<td>network</td>
<td>Telecom Network</td>
<td>mtn/glo/airtel/9mobile</td>
</tr>
<tr>
<td>amount</td>
<td>Amount you wanna vend recipient</td>
<td>200</td>
</tr>
<tr>
<td>type</td>
<td>Airtime Type</td>
<td>vtu/share/awuf</td>
</tr>
</tbody>
</table>
<br>
Example: <?php echo esc_url(plugins_url('vprest/?q=airtime&id=88&apikey=2878&phone=07049626922&amount=200&network=mtn&type=sme'));?><br>

Response [JSON]:
<div class="" style="overflow-x:auto;">
<?php
$obj = new stdClass;
$obj->Status = "100";
$obj->Successful = "true";
$obj->Message = "Purchase Was Successful";
$obj->Previous_Balance = 500;
$obj->Current_Balance = 300;
$obj->Amount_Charged = 200;
$obj->Type = "sme";
$obj->Receiver = "07049626922";
$obj->Network = "mtn";
echo json_encode($obj);
?>
</div>
<br>
</div>

<div class="col my-2 shadow rounded p-3">
<h5 class="font-bold code">AIRTIME</h5><br>
<table class="table table-responsive table-hover history-successful h6 font-size">
<thead>
<tr>
<th scope='col'>Type</th>
<th scope='col'>Product ID</th>
<th scope='col'>Network</th>
<th scope='col'>Discount</th>
</tr>
</thead>
<tbody>
<?php

//VTU

#MTN VTU
$discount = floatval($level[0]->mtn_vtu);
$plan_network = "MTN";
$plan_type = "VTU";
$api = strtolower($plan_network);
if(vp_option_array($option_array,"vtucontrol") == "checked" && vp_option_array($option_array,"setairtime") == "checked"){
echo"
<tr style='background-color:#ffc107;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td>
<td> $discount% </td>
</tr>
";

}




#GLO VTU
$discount = floatval($level[0]->glo_vtu);
$plan_network = "GLO";
$plan_type = "VTU";
$api = strtolower($plan_network);
if( vp_option_array($option_array,"vtucontrol") == "checked"  && vp_option_array($option_array,"setairtime") == "checked"){
echo"
<tr style='background-color:#28a745;color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td>
<td> $discount% </td>
</tr>
";

}





#9MOBILE VTU
$discount = floatval($level[0]->mobile_vtu);
$plan_network = "9MOBILE";
$plan_type = "VTU";
$api = strtolower($plan_network);
if( vp_option_array($option_array,"vtucontrol") == "checked"  && vp_option_array($option_array,"setairtime") == "checked"){
echo"
<tr style='background-color:#20c997; color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td>
<td> $discount% </td>
</tr>
";

}





#AIRTEL VTU
$discount = floatval($level[0]->airtel_vtu);
$plan_network = "AIRTEL";
$plan_type = "VTU";
$api = strtolower($plan_network);
if( vp_option_array($option_array,"vtucontrol") == "checked"  && vp_option_array($option_array,"setairtime") == "checked"){
echo"
<tr style='background-color:#e83e8c; color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td>
<td> $discount% </td>
</tr>
";

}






//SHARE
#MTN SHARE
$discount = floatval($level[0]->mtn_share);
$plan_network = "MTN";
$plan_type = "SHARE & SELL";
$api = strtolower($plan_network);
if(vp_option_array($option_array,"sharecontrol") == "checked"  && vp_option_array($option_array,"setairtime") == "checked"){
echo"
<tr style='background-color:#ffc107;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td>
<td> $discount% </td>
</tr>
";

}




#GLO SHARE
$discount = floatval($level[0]->glo_share);
$plan_network = "GLO";
$plan_type = "SHARE & SELL";
$api = strtolower($plan_network);
if(vp_option_array($option_array,"sharecontrol") == "checked"  && vp_option_array($option_array,"setairtime") == "checked"){
echo"
<tr style='background-color:#28a745;color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td>
<td> $discount% </td>
</tr>
";

}





#9MOBILE SHARE
$discount = floatval($level[0]->mobile_share);
$plan_network = "9MOBILE";
$plan_type = "SHARE & SELL";
$api = strtolower($plan_network);
if(vp_option_array($option_array,"sharecontrol") == "checked"  && vp_option_array($option_array,"setairtime") == "checked"){
echo"
<tr style='background-color:#20c997; color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td>
<td> $discount% </td>
</tr>
";

}





#AIRTEL SHARE
$discount = floatval($level[0]->airtel_share);
$plan_network = "AIRTEL";
$plan_type = "SHARE & SELL";
$api = strtolower($plan_network);
if( vp_option_array($option_array,"sharecontrol") == "checked"  && vp_option_array($option_array,"setairtime") == "checked"){
echo"
<tr style='background-color:#e83e8c; color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td>
<td> $discount% </td>
</tr>
";

}






//AWUF
#MTN AWUF
$discount = floatval($level[0]->mtn_awuf);
$plan_network = "MTN";
$plan_type = "AWUF";
$api = strtolower($plan_network);
if( vp_option_array($option_array,"awufcontrol") == "checked"  && vp_option_array($option_array,"setairtime") == "checked"){
echo"
<tr style='background-color:#ffc107;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td>
<td> $discount% </td>
</tr>
";

}




#GLO AWUF
$discount = floatval($level[0]->glo_awuf);
$plan_network = "GLO";
$plan_type = "AWUF";
$api = strtolower($plan_network);
if(vp_option_array($option_array,"awufcontrol") == "checked"  && vp_option_array($option_array,"setairtime") == "checked"){
echo"
<tr style='background-color:#28a745;color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td>
<td> $discount% </td>
</tr>
";

}





#9MOBILE AWUF
$discount = floatval($level[0]->mobile_awuf);
$plan_network = "9MOBILE";
$plan_type = "AWUF";
$api = strtolower($plan_network);
if( vp_option_array($option_array,"awufcontrol") == "checked"  && vp_option_array($option_array,"setairtime") == "checked"){
echo"
<tr style='background-color:#20c997; color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td>
<td> $discount% </td>
</tr>
";

}





#AIRTEL AWUF
$discount = floatval($level[0]->airtel_awuf);
$plan_network = "AIRTEL";
$plan_type = "AWUF";
$api = strtolower($plan_network);
if(vp_option_array($option_array,"awufcontrol") == "checked"  && vp_option_array($option_array,"setairtime") == "checked"){
echo"
<tr style='background-color:#e83e8c; color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td>
<td> $discount% </td>
</tr>
";

}




?>
</tbody>
</table>
</div>


<div class="mb-3 mt-3">
<h5>Buy Data [Get/Post]</h5><br>
Parameters:<br>
<table>
<tbody>
<table class="table table-responsive table-hover">
<tbody>
<tr>
<th  scope="col">Parameter</th>
<th  scope="col">Meaning</th>
<th  scope="col">Value</th>
</tr>
<tr>
<td>q</td>
<td>Query</td>
<td>user</td>
</tr>
<tr>
<td>id</td>
<td>your user id</td>
<td>20</td>
</tr>
<tr>
<td>apikey</td>
<td>your Api key</td>
<td>23403</td>
</tr>
<tr>
<td>phone</td>
<td>recipient phone number</td>
<td>07049626922</td>
</tr>
<tr>
<td>network</td>
<td>Telecom Network</td>
<td>mtn/glo/airtel/9mobile</td>
</tr>
<tr>
<td>dataplan</td>
<td>The Dataplan You Wanna Buy</td>
<td>1,2,3,4....see below for list of dataplans and id</td>
</tr>
<tr>
<td>type</td>
<td>Data Type</td>
<td>sme/direct/corporate</td>
</tr>
</tbody>
</table>
<br>
Example: <?php echo esc_url(plugins_url('vprest/?id=1&apikey=234&q=data&phone=07049626922&network=mtn&type=sme&dataplan=1'));?><br>

Response [JSON]: 
<?php

$obj = new stdClass;
$obj->Status = "100";
$obj->Successful = "true";
$obj->Message = "Purchase Of MTN 1GB Was Successful";
$obj->Previous_Balance = 1000;
$obj->Current_Balance = 900;
$obj->Amount_Charged = 100;
$obj->Data_Plan = "Mtn 1GB";
$obj->Plan_Code = 1;
$obj->Data_Type = "SME";
$obj->Network = "Mtn";
$obj->Receiver = "07049626922";
echo json_encode($obj);

?>
<br>

<!--https://dev.betabundles.com.ng/wp-content/plugins/vprest/?id=1&apikey=2344&q=data&phone=07049626922&amount=200&network=mtn&type=sme&dataplan=1-->
</div>


</div>
<div class="col">
<h5>RESPONSES</h5><br>
<table class="table table-hover table-responsive">
<tbody>
<tr>
<th>Response Code</th>
<th>Response Meaning</th>
</tr>
<tr>
<td>Status:100 or Successful:true</td>
<td>Successful Query/Transaction</td>
</tr>
<tr>
<td>Status:200 or Successful:false</td>
<td>Failed Query/Transaction</td>
</tr>
<tr>
<td>Message</td>
<td>Response Message</td>
</tr>
<tr>
<td>Response</td>
<td>Response Message</td>
</tr>
</tbody>
</table>

</div>




<div class="col my-2 shadow rounded p-3">
<h5 class="font-bold code">DATA PLANS AND PRODUCT ID </h5><br>
<table class="table table-responsive table-hover history-successful h6 font-size">
<thead>
<tr>
<th scope='col'>Type</th>
<th scope='col'>Product ID</th>
<th scope='col'>Network</th>
<th scope='col'>Name</th>
<th scope='col'>Amount</th>
<th scope='col'>Discount</th>
</tr>
</thead>
<tbody>
<?php

for($i = 0; $i <= 10; $i++ ){
$api = vp_option_array($option_array,"api$i");
$disamount = vp_option_array($option_array,"cdatap$i");
$discount = floatval($level[0]->mtn_sme);
$plan_network = "MTN";
$plan_type = "SME";
$plan_name = vp_option_array($option_array,"cdatan$i");
$plan = vp_option_array($option_array,"cdata$i");

if(!empty($plan) && !empty($plan_name)&& !empty($disamount)   && vp_option_array($option_array,"smecontrol") == "checked"  && vp_option_array($option_array,"setdata") == "checked"){
echo"
<tr style='background-color:#ffc107;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td><td> ".strtoupper($plan_name)." </td>
<td> NGN $disamount </td>
<td> $discount% </td>
</tr>
";

}

}

for($i = 0; $i <= 10; $i++ ){
$api = vp_option_array($option_array,"aapi$i");
$plan = vp_option_array($option_array,"acdata$i");
$disamount = vp_option_array($option_array,"acdatap$i");
$discount = floatval($level[0]->airtel_sme);
$plan_network = "AIRTEL";
$plan_type = "SME";
$plan_name = vp_option_array($option_array,"acdatan$i");
$plan = vp_option_array($option_array,"acdata$i");

if(!empty($plan) && !empty($plan_name)&& !empty($disamount)   && vp_option_array($option_array,"smecontrol") == "checked"   && vp_option_array($option_array,"setdata") == "checked"){
echo"
<tr style='background-color:#e83e8c; color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td>
<td> ".strtoupper($plan_name)." </td>
<td> NGN $disamount </td>
<td> $discount% </td>
</tr>
";

}
}


for($i = 0; $i <= 10; $i++ ){
$api = vp_option_array($option_array,"9api$i");
$plan = vp_option_array($option_array,"9cdata$i");
$disamount = floatval($level[0]->mobile_sme);
$plan_network = "9MOBILE";
$plan_type = "SME";
$discount = vp_option_array($option_array,"sme_9dd");
$plan_name = vp_option_array($option_array,"9cdatan$i");
$plan = vp_option_array($option_array,"9cdata$i");


if(!empty($plan) && !empty($plan_name)&& !empty($disamount)   && vp_option_array($option_array,"smecontrol") == "checked"   && vp_option_array($option_array,"setdata") == "checked"){
echo"
<tr style='background-color:#20c997; color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td><td> ".strtoupper($plan_name)." </td>
<td> NGN $disamount </td>
<td> $discount% </td>
</tr>
";

}

}


for($i = 0; $i <= 10; $i++ ){
$api =  vp_option_array($option_array,"gapi$i");
$plan = vp_option_array($option_array,"gcdata$i");
$disamount = floatval($level[0]->glo_sme);
$plan_name = vp_option_array($option_array,"gcdatan$i");
$plan_network = "GLO";
$plan_type = "SME";
$discount = vp_option_array($option_array,"sme_gdd");
$plan = vp_option_array($option_array,"gcdata$i");

if(!empty($plan) && !empty($plan_name)&& !empty($disamount)  && vp_option_array($option_array,"smecontrol") == "checked"   && vp_option_array($option_array,"setdata") == "checked"){
echo"
<tr style='background-color:#28a745;color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td><td> ".strtoupper($plan_name)." </td>
<td> NGN $disamount </td>
<td> $discount% </td>
</tr>
";

}
}

//GIFTING
for($i = 0; $i <= 10; $i++ ){
$api =  vp_option_array($option_array,"api2$i");
$plan = vp_option_array($option_array,"rcdata$i");
$disamount = floatval($level[0]->mtn_gifting);
$plan_network = "MTN";
$plan_type = "DIRECT";
$plan_name = vp_option_array($option_array,"rcdatan$i");
$plan = vp_option_array($option_array,"rcdata$i");
$discount = vp_option_array($option_array,"direct_mdd");


if(!empty($plan) && !empty($plan_name)&& !empty($disamount)   && vp_option_array($option_array,"directcontrol") == "checked"   && vp_option_array($option_array,"setdata") == "checked"){
echo"
<tr style='background-color:#ffc107;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td><td> ".strtoupper($plan_name)." </td>
<td> NGN $disamount </td>
<td> $discount% </td>
</tr>
";

}


}

for($i = 0; $i <= 10; $i++ ){
$api =  vp_option_array($option_array,"aapi2$i");
$plan = vp_option_array($option_array,"racdata$i");
$disamount = floatval($level[0]->airtel_gifting);
$plan_network = "AIRTEL";
$plan_type = "DIRECT";
$plan_name = vp_option_array($option_array,"racdatan$i");
$plan = vp_option_array($option_array,"racdata$i");
$discount = vp_option_array($option_array,"direct_mdd");

if(!empty($plan) && !empty($plan_name)&& !empty($disamount)   && vp_option_array($option_array,"directcontrol") == "checked"   && vp_option_array($option_array,"setdata") == "checked"){
echo"
<tr style='background-color:#e83e8c; color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td><td> ".strtoupper($plan_name)." </td>
<td> NGN $disamount </td>
<td> $discount% </td>
</tr>
";

}


}
for($i = 0; $i <= 10; $i++ ){
$api =  vp_option_array($option_array,"9api2$i");
$plan = vp_option_array($option_array,"r9cdata$i");
$disamount = floatval($level[0]->mobile_gifting);
$plan_network = "9MOBILE";
$plan_type = "DIRECT";
$plan_name = vp_option_array($option_array,"r9cdatan$i");
$plan = vp_option_array($option_array,"r9cdata$i");
$discount = vp_option_array($option_array,"direct_mdd");

if(!empty($plan) && !empty($plan_name)&& !empty($disamount)   && vp_option_array($option_array,"directcontrol") == "checked"   && vp_option_array($option_array,"setdata") == "checked"){
echo"
<tr style='background-color:#20c997; color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td><td> ".strtoupper($plan_name)." </td>
<td> NGN $disamount </td>
<td> $discount% </td>
</tr>
";

}

}
for($i = 0; $i <= 10; $i++ ){
$api =  vp_option_array($option_array,"gapi2$i");
$plan = vp_option_array($option_array,"rgcdata$i");
$disamount = floatval($level[0]->glo_gifting);
$plan_network = "GLO";
$plan_type = "DIRECT";
$plan_name = vp_option_array($option_array,"rgcdatan$i");
$plan = vp_option_array($option_array,"rgcdata$i");
$discount = vp_option_array($option_array,"direct_mdd");

if(!empty($plan) && !empty($plan_name)&& !empty($disamount)   && vp_option_array($option_array,"directcontrol") == "checked"   && vp_option_array($option_array,"setdata") == "checked"){
echo"
<tr style='background-color:#28a745;color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td><td> ".strtoupper($plan_name)." </td>
<td> NGN $disamount </td>
<td> $discount% </td>
</tr>
";

}


}

//CORPORATE
for($i = 0; $i <= 10; $i++ ){
$api =  vp_option_array($option_array,"api3$i");
$plan = vp_option_array($option_array,"r2cdata$i");
$disamount = floatval($level[0]->mtn_corporate);
$plan_network = "MTN";
$plan_type = "CORPORATE";
$plan_name = vp_option_array($option_array,"r2cdatan$i");
$plan = vp_option_array($option_array,"r2cdata$i");
$discount = vp_option_array($option_array,"corporate_mdd");

if(!empty($plan) && !empty($plan_name)&& !empty($disamount)   && vp_option_array($option_array,"corporatecontrol") == "checked"   && vp_option_array($option_array,"setdata") == "checked"){
echo"
<tr style='background-color:#ffc107;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td><td> ".strtoupper($plan_name)." </td>
<td> NGN $disamount </td>
<td> $discount% </td>
</tr>
";

}


}

for($i = 0; $i <= 10; $i++ ){
$api =  vp_option_array($option_array,"aapi3$i");
$plan = vp_option_array($option_array,"r2acdata$i");
$disamount = floatval($level[0]->airtel_corporate);
$plan_network = "AIRTEL";
$plan_type = "CORPORATE";
$plan_name = vp_option_array($option_array,"r2acdatan$i");
$plan = vp_option_array($option_array,"r2acdata$i");
$discount = vp_option_array($option_array,"corporate_mdd");


if(!empty($plan) && !empty($plan_name)&& !empty($disamount)   && vp_option_array($option_array,"corporatecontrol") == "checked"   && vp_option_array($option_array,"setdata") == "checked"){
echo"
<tr style='background-color:#e83e8c; color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td><td> ".strtoupper($plan_name)." </td>
<td> NGN $disamount </td>
<td> $discount% </td>
</tr>
";

}


}
for($i = 0; $i <= 10; $i++ ){
$api =  vp_option_array($option_array,"9api3$i");
$plan = vp_option_array($option_array,"r29cdata$i");
$disamount = floatval($level[0]->mobile_corporate);
$plan_network = "9MOBILE";
$plan_type = "CORPORATE";
$plan_name = vp_option_array($option_array,"r29cdatan$i");
$plan = vp_option_array($option_array,"r29cdata$i");
$discount = vp_option_array($option_array,"corporate_mdd");

if(!empty($plan) && !empty($plan_name)&& !empty($disamount)   && vp_option_array($option_array,"corporatecontrol") == "checked"   && vp_option_array($option_array,"setdata") == "checked"){
echo"
<tr style='background-color:#20c997; color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td><td> ".strtoupper($plan_name)." </td>
<td> NGN $disamount </td>
<td> $discount% </td>
</tr>
";

}


}
for($i = 0; $i <= 10; $i++ ){
$api =  vp_option_array($option_array,"gapi3$i");
$plan = vp_option_array($option_array,"r2gcdata$i");
$disamount = floatval($level[0]->glo_corporate);
$plan_network = "GLO";
$plan_type = "CORPORATE";
$plan_name = vp_option_array($option_array,"r2gcdatan$i");
$plan = vp_option_array($option_array,"r2gcdata$i");
$discount = vp_option_array($option_array,"corporate_mdd");


if(!empty($plan) && !empty($plan_name)&& !empty($disamount)   && vp_option_array($option_array,"corporatecontrol") == "checked"   && vp_option_array($option_array,"setdata") == "checked"){
echo"
<tr style='background-color:#28a745;color:white;'>
<td scope='row'> $plan_type </td>
<td> $api </td>
<td> $plan_network </td><td> ".strtoupper($plan_name)." </td>
<td> NGN $disamount </td>
<td> $discount% </td>
</tr>
";

}


}



?>
</tbody>
</table>
</div>


<?php
			

}
else{
	?>
	<div class="col">
<div class="mb-3">
<h1>"API ACCESSIBILTY NOT AVAILABLE FOR THIS PLAN"</h1>
</div>
</div>
<?php
}

}
		
?>