<?php
error_reporting(0);
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
include_once(ABSPATH."wp-load.php");
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');

if(isset($_POST["method"])){

if(isset($_POST["name"])  && !empty($_POST["name"])){
	
	if(isset($_POST["method"])  && !empty($_POST["method"])){
	
		
	if(isset($_FILES["file"])  && !empty($_FILES["file"])){
		if(isset($_FILES["fill"])  && !empty($_FILES["fill"])){
	
	
if($_FILES["file"]["error"] == 0){
	if($_FILES["fill"]["error"] == 0){
		
    $file_name = $_FILES["file"]["name"];
    $file_size = $_FILES["file"]["size"];
    $file_type = $_FILES["file"]["type"];
    $file_tmp = $_FILES["file"]["tmp_name"];
	
	$file_name2 = $_FILES["fill"]["name"];
    $file_size2 = $_FILES["fill"]["size"];
    $file_type2 = $_FILES["fill"]["type"];
    $file_tmp2 = $_FILES["fill"]["tmp_name"];
   
    $ext = pathinfo($file_name,PATHINFO_EXTENSION);
    $ext2 = pathinfo($file_name2,PATHINFO_EXTENSION);
    
    $exp_size = 5 * 1024 * 1024;
    
    $allowed_ext = array(
        "jpg" => "image/jpg",
        "jpeg" => "image/jpeg",
        "png" => "image/png"
        
        );
    
    if($file_size < $exp_size){
		
		    if($file_size2 < $exp_size){
        
        if(array_key_exists($ext,$allowed_ext)){ 
		
		if(array_key_exists($ext2,$allowed_ext)){


			$upload_overrides= array( 'test_form'=> false); 
            $return = media_handle_upload('file', 0); 
            $return2 = media_handle_upload('fill', 0); 
				 
			if(is_int($return) && is_int($return2)) { 	 

		$url_of_image = wp_get_attachment_url($return);
		$url_of_image2 = wp_get_attachment_url($return2);
		
		$name = $_POST["name"];
		$method = $_POST["method"];
		$selfie = $url_of_image;
		$proof = $url_of_image2;
		$user_id = get_current_user_id();
		if($method == "nin"){
			$meth = "National Identical Number/Slip";
		}
		elseif($method == "bvn"){
			$meth = "Bank verification Number";
		}
		elseif($method == "voters"){
			$meth = "Voters Card";
		}
		elseif($method == "drive"){
			$meth = "Driving License";
		}
		elseif($method == "pass"){
			$meth = "International Passport";
		}
		else{
			die("Could Not Identify Method Of Verification");
		}
global $wpdb;
$table_name = $wpdb->prefix.'vp_kyc';
$wpdb->insert($table_name, array(
'name'=> $name,
'method'=> $meth,
'selfie' => $selfie,
'proof' => $proof,
'user_id' => $user_id,
'status' => 'review',
'the_time' => current_time('mysql', 1)
));

die("100");
			
			}
			else{
		var_dump($return);	
			}
			
			        }
        else{
            
            echo $ext2."NOT ALLOWED";
        }
			
        }
        else{
            
            echo $ext."NOT ALLOWED";
        }
		
		    }
    else{
        echo "$file_name2 FILE SIZE TOO HUGE";
    }
        
    }
    else{
        echo "$file_name FILE SIZE TOO HUGE";
    }
  
  }
else{
    
    echo "ERROR. FILL :". $_FILES["name"]["error"];
    
}
}
else{
    
    echo "ERROR. FILE:". $_FILES["name"]["error"];
    
}

}
else{

die("DOCUMENT PROOF Mustn't Be Empty");
	
}


}
else{

die("PASSPORT/SELFIE PHOTO Mustn't Be Empty");
	
}


}
else{

die("METHOD Mustn't Be Empty");
	
}

}
else{

die("NAME Mustn't Be Empty");
	
}



}

elseif(isset($_POST["action"])){
	$status = $_POST["status"];
	$where = ['user_id' => $_POST["id"] ];
	$arr = ['status' => $status];
global $wpdb;
$table_name = $wpdb->prefix."vp_kyc";
$updated = $wpdb->update($table_name , $arr, $where);

vp_updateuser($_POST["id"],"vp_kyc_status", $status);
die("100");
}

elseif(isset($_POST["limit"])){
	$enable = $_POST["enable"];
	$duration = $_POST["duration"];
	$limit = $_POST["limit"];

$arr = ['enable' => $enable, 'duration' => $duration, 'kyc_limit' => $limit];
$where = ['id' => 1];
global $wpdb;
$table_name = $wpdb->prefix."vp_kyc_settings";
$updated = $wpdb->update($table_name , $arr, $where);

die("100");
}
else{
	die("NO ACTION");
}

?>