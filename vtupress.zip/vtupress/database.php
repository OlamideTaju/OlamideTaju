<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');
global $wpdb;
$stable_name = $wpdb->prefix.'vp_withdrawal';
$charset_collate=$wpdb->get_charset_collate();
$sql= "CREATE TABLE IF NOT EXISTS $stable_name(
id int NOT NULL AUTO_INCREMENT,
name text NOT NULL,
description text NOT NULL,
amount bigint NOT NULL,
status text NOT NULL,
user_id int NOT NULL,
the_time datetime NOT NULL,
PRIMARY KEY (id))$charset_collate;";
require_once(ABSPATH.'wp-admin/includes/upgrade.php');
dbDelta($sql);
vp_updateoption("vtupress_withdrawal","yes");



global $wpdb;
$stable_name = $wpdb->prefix.'vp_wallet';
$charset_collate=$wpdb->get_charset_collate();
$sql= "CREATE TABLE IF NOT EXISTS $stable_name(
id int NOT NULL AUTO_INCREMENT,
type text NOT NULL,
name text NOT NULL,
description text NOT NULL,
fund_amount bigint NOT NULL,
before_amount text,
now_amount text,
user_id int NOT NULL,
the_time datetime NOT NULL,
status text,
PRIMARY KEY (id))$charset_collate;";
require_once(ABSPATH.'wp-admin/includes/upgrade.php');
dbDelta($sql);


global $wpdb;
$stable_name = $wpdb->prefix.'vp_coupon';
$charset_collate=$wpdb->get_charset_collate();
$sql= "CREATE TABLE IF NOT EXISTS $stable_name(
id int NOT NULL AUTO_INCREMENT,
code text NOT NULL,
applicable_to text NOT NULL,
amount text NOT NULL,
used_by text,
status text,
the_time datetime NOT NULL,
PRIMARY KEY (id))$charset_collate;";
require_once(ABSPATH.'wp-admin/includes/upgrade.php');
dbDelta($sql);

global $wpdb;
$stable_name = $wpdb->prefix.'vp_message';
$charset_collate=$wpdb->get_charset_collate();
$sql= "CREATE TABLE IF NOT EXISTS $stable_name(
id int NOT NULL AUTO_INCREMENT,
user_id text NOT NULL,
user_name text NOT NULL,
user_token text NOT NULL,
PRIMARY KEY (id))$charset_collate;";
require_once(ABSPATH.'wp-admin/includes/upgrade.php');
dbDelta($sql);





function create_s_transaction(){

vp_updateoption('suc','successful');

global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$charset_collate=$wpdb->get_charset_collate();
$sql= "CREATE TABLE IF NOT EXISTS $table_name(
id int NOT NULL AUTO_INCREMENT,
name text NOT NULL,
email varchar(255),
network text NOT NULL,
phone bigint NOT NULL,
bal_bf bigint,
bal_nw bigint,
amount bigint NOT NULL,
resp_log text NOT NULL,
user_id int NOT NULL,
status text NOT NULL,
the_time datetime NOT NULL,
PRIMARY KEY (id))$charset_collate;";
require_once(ABSPATH.'wp-admin/includes/upgrade.php');
dbDelta($sql);
}
//Default Datas to sairtime (s-airtime db)
function addsdata(){
global $wpdb;
$name='Vtupress Plugin';
$email='vtupress.com@gmail.com';
$network='mtn';
$bal_bf ='0';
$bal_nw ='0';
$phone= '07049626922';
$amount= '0';
$tid = '1';
$table_name = $wpdb->prefix.'sairtime';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'network' => $network,
'phone' => $phone,
'bal_bf' => $bal_bf,
'bal_nw' => $bal_nw,
'amount' => $amount,
'resp_log' => "sample of successful airtime log",
'user_id' => $tid,
'status' => 'successful',
'the_time' => current_time('mysql', 1)
));
}
//create failed Airtime transaction db


function create_sd_transaction(){
global $wpdb;
$sd_name = $wpdb->prefix.'sdata';
$charset_collate=$wpdb->get_charset_collate();
$sql= "CREATE TABLE IF NOT EXISTS $sd_name(
id int NOT NULL AUTO_INCREMENT,
name text NOT NULL,
email varchar(255),
plan text NOT NULL,
phone BIGINT NOT NULL,
bal_bf bigint,
bal_nw bigint,
amount bigint NOT NULL,
resp_log text NOT NULL,
user_id int NOT NULL,
status text NOT NULL,
the_time datetime NOT NULL,
PRIMARY KEY (id))$charset_collate;";
require_once(ABSPATH.'wp-admin/includes/upgrade.php');
dbDelta($sql);
}
//Default Datas to sdata (s-db)
function addsddata(){
global $wpdb;
$sname='Vtupress Plugin';
$semail='vtupress.com@gmail.com';
$splan='MTN 500MB';
$sphone= '07049626922';
$bal_bf ='0';
$bal_nw ='0';
$samount= '0';
$tid = '1';
$sd_name = $wpdb->prefix.'sdata';
$wpdb->insert($sd_name, array(
'name'=> $sname,
'email'=> $semail,
'plan' => $splan,
'phone' => $sphone,
'bal_bf' => $bal_bf,
'bal_nw' => $bal_nw,
'amount' => $samount,
'resp_log' => "sample of successful data log",
'user_id' => $tid,
'status' => "successful",
'the_time' => current_time('mysql', 1)
));
}

function flutterwave(){
global $wpdb;
$table_name = $wpdb->prefix.'flutterwave';
$charset_collate=$wpdb->get_charset_collate();
$sql= "CREATE TABLE IF NOT EXISTS $table_name(
id int NOT NULL AUTO_INCREMENT,
public_key text NOT NULL,
secret_key text NOT NULL,
PRIMARY KEY (id))$charset_collate;";
require_once(ABSPATH.'wp-admin/includes/upgrade.php');
dbDelta($sql);
}
//add default data to Flutterwave db
function flutterwavedata(){
global $wpdb;
$public='PUBKEY';
$secret = 'SECKEY';
$table_name = $wpdb->prefix.'flutterwave';
$wpdb->insert($table_name, array(
'public_key'=> $public,
'secret_key' => $secret
));
}
//create vtu choice db
function vtuchoice(){
global $wpdb;
$table_name = $wpdb->prefix.'vtuchoice';
$charset_collate = $wpdb->get_charset_collate();
$sql = "CREATE TABLE IF NOT EXISTS $table_name(
id int NOT NULL AUTO_INCREMENT,
vtuchoice text NOT NULL,
PRIMARY KEY  (id))$charset_collate;";
require_once(ABSPATH.'wp-admin/includes/upgrade.php');
dbDelta($sql);
}
//create default data for vtuchoice
function vtuchoiced(){
global $wpdb;
$table_name = $wpdb->prefix.'vtuchoice';
$data = array('vtuchoice' => 'custom');
$wpdb->insert($table_name,$data);
}
do_action('vpdb');
?>