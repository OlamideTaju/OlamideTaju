<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH."wp-load.php");
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');
echo'
<style>
body{max-width:700px; margin:auto;}
.div{max-width:700px; margin:auto; font-family:verdana; color: black;}
h1{color: orange;}
input{height:50px; width:100%;}
input[type=submit]{height:58px; width:100%; background-color:green; color:white;}
label{text-align:center; font-size:30px;}
</style>
<b class="div" id="div">
<form method="GET" target="_self">
<h1>You need to activate your plugin with an API key</h1>
<label> ID number</label><br>
<input type="number" id="idno" name="id"><br>
<label> API key</label><br>
<input type="text" id="actkey" name="actkey"><br>
<input type="submit" name="act" value="Activate">
</form>
</b>

';

if(isset($_GET["act"])){
include_once(ABSPATH."wp-load.php");
$id = $_GET["id"];
$actkey =$_GET["actkey"];

$url = 'https://vtupress.com/wp-content/plugins/vtuadmin?id='.$id.'&actkey='.$actkey;
$request_url = $url;

//echo "<script>alert('".$request_url."');</script>";

$curl = curl_init($request_url);

$agent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)";

curl_setopt($curl, CURLOPT_USERAGENT, $agent);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, [
'Content-Type: application/json'
]);
//curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
//curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);

$resp = curl_exec($curl);
//echo "<script>alert('resp".$resp."');</script>";

if($e = curl_error($curl)){
echo $e;
}elseif ($curl === false) {
throw new Exception('failed to initialize');
}else{
$en = json_decode($resp);
curl_close($curl);
}
$one =  $en->status;
$two = $en->actkey;
//echo "<script>alert('one".$one."');</script>";
//echo "<script>alert('two".$two."');</script>";
if($one == "active"){
include_once(ABSPATH."wp-load.php");
vp_updateoption('vprun','none');
vp_updateoption('vpid',$id);
vp_updateoption('actkey',$actkey);
echo '<script>alert("activated!!! Kindly refresh the page when redirected to remove the activation pop-up. Go back if you are not redirected within 5sec Max.");
window.history.back();
</script>';
}
else{echo '<script>alert("wrong id or actkey please retry or \'go back\'");</script>';
}
}
?>