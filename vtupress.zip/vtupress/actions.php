<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH."wp-load.php");
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');
ob_start();
  if ( ! function_exists( 'get_plugins' )){
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
  }
add_action("admin_menu","addMenu");

function addMenu(){
add_menu_page("Vtu Press","Vtupress","vtupress_access_addons","vtu-press","vtuPress", "dashicons-calculator");
add_submenu_page("vtu-press", "License", "License", "vtupress_access_license", "vplicense","vplicense");
add_submenu_page("vtu-press","VTU-Settings", "VTU-Settings", "vtupress_access_settings", "vtu-settings", "vtusettings");
add_submenu_page("vtu-press","Levels", "Levels", "vtupress_access_levels", "vtulevels", "vtulevels");
add_submenu_page("vtu-press","Kyc", "Kyc", "vtupress_access_kyc", "vpkyc", "vpkyc");
add_submenu_page("vtu-press","System & Security", "System & Security", "vtupress_access_security", "vpsystem", "vpsystem");
do_action("vpsubpages");
}


function vpkyc(){
	global $wpdb;
	$table_name = $wpdb->prefix."vp_kyc_settings";
	$datas = $wpdb->get_results("SELECT * FROM $table_name WHERE id = 1");
	$option_array = json_decode(get_option("vp_options"),true);
	

?>

<link rel="stylesheet" href="<?php echo esc_url( plugins_url( 'vtupress/css/bootstrap.min.css?v=1') );?>" />
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/bootstrap.min.js?v=1') );?>" ></script>
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/jquery.js?v=1') );?>"></script>
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/sweet.js?v=1') );?>" ></script>

<style>



  #cover-spin {
        position:fixed;
        width:100%;
        left:0;right:0;top:0;bottom:0;
        background-color: rgba(255,255,255,0.7);
        z-index:9999;
        /*display:none;*/
    }

    @-webkit-keyframes spin {
      from {-webkit-transform:rotate(0deg);}
      to {-webkit-transform:rotate(360deg);}
    }

    @keyframes  spin {
      from {transform:rotate(0deg);}
      to {transform:rotate(360deg);}
    }

    #cover-spin::after {
        content:"";
        display:block;
        position:absolute;
        left:48%;top:40%;
        width:40px;height:40px;
        border-style:solid;
		border-top: 16px solid blue;
  border-right: 16px solid green;
  border-bottom: 16px solid red;
  border-left: 16px solid pink;
        border-width: 4px;
        border-radius:50%;
        -webkit-animation: spin .8s linear infinite;
        animation: spin .8s linear infinite;
    }

</style>



<?php
if(!is_plugin_active("vprest/vprest.php")  || vp_option_array($option_array,"resell") != "yes"){
	
	die("
<div class='row my-3 mx-3'>
<div class='col font-bold text-white bg bg-danger p-3 rounded shadow'>
YOU CANT ACCESS THIS PAGE BECAUSE YOU ARE A PERSONAL/DEMO USER OR DOES NOT HAVE VP RESELLER ADDON INSTALLED
</div>
</div>
");

}
else{
$path = $_SERVER["DOCUMENT_ROOT"]."/wp-content/plugins/vprest/vprest.php";
$path = get_plugin_data($path);


if($path["Version"] < "2.1.0"){
		die("
<div class='row my-3 mx-3'>
<div class='col font-bold text-white bg bg-danger p-3 rounded shadow'>
VP RESELLER ADDON IS LESS THAN 2.1.0 PLEASE UPDATE IT.
</div>
</div>
");

}
else{

if(!is_plugin_active("vpmlm/vpmlm.php")  || vp_option_array($option_array,"resell") != "yes"){
	
	echo"
<div class='row my-3 mx-3'>
<div class='col font-bold text-white bg bg-primary p-3 rounded shadow'>
YOU CAN EXTEND YOUR PLUGIN FUNCTIONALITY INSTALLING VPMLM.
</div>
</div>
";

}
else{
$path2 = $_SERVER["DOCUMENT_ROOT"]."/wp-content/plugins/vpmlm/vpmlm.php";
$path2 = get_plugin_data($path2);
	if($path2["Version"] < "2.1.0"){
		die("
<div class='row my-3 mx-3'>
<div class='col font-bold text-white bg bg-danger p-3 rounded shadow'>
VP MLM ADDON IS LESS THAN 2.1.0 PLEASE UPDATE IT.
</div>
</div>
");

}

}
	
}
}
?>

<div id="cover-spin">

<div class="loader">
</div>

</div>
<div class="container">

<div class="row my-4">
<div class="col col-sm-6">
<div class="input-group">
<span class="input-group-text">Enable KYC</span>
<select class="enable_kyc">
<option value="<?php echo $datas[0]->enable;?>"><?php echo strtoupper($datas[0]->enable);?></option>
<option value="yes">YES</option>
<option value="no">NO</option>
</select>
</div>
</div>
<div class="col col-sm-6">
<input type="number" name="kyc_limit" class="kyc_limit" value="<?php echo $datas[0]->kyc_limit;?>"><br>
<small> Transaction Limit Only Applies For Unverified Users </small>
<div class="input-group">
<span class="input-group-text">Duration</span>
<select class="kyc_duration">
<option value="<?php echo $datas[0]->duration;?>"><?php echo strtoupper($datas[0]->duration);?></option>
<option value="total">Total Transaction Sum</option>
<option value="day">Per Day</option>
<option value="month">Per Month</option>
</select>
</div>
</div>

<script>
jQuery(".enable_kyc, .kyc_duration, .kyc_limit").on("change",function(){
	var enable = jQuery(".enable_kyc").val();
	var limit = jQuery(".kyc_limit").val();
	var duration = jQuery(".kyc_duration").val();
	
 jQuery("#cover-spin").show();	

var obj = {};
obj["enable"] = enable;
obj["limit"] = limit;
obj["duration"] = duration;

 
jQuery.ajax({
url: "<?php echo esc_url(plugins_url('vtupress/template/classic/sections/kycupload.php'));?>",
data : obj,
dataType: 'text',
'cache': false,
 "async": true,
error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data) {
	  jQuery("#cover-spin").hide();
        if(data == "100"){
		  swal({
  title: "Successfully Changed KYC Status",
  text: "Thanks",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Error Changing KYC tatus",
  text: "Click Why To See Reason",
  icon: "warning",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
		location.reload();
      break;
    default:
      swal(data, {
      icon: "info",
    });
  }
});
	  }
  },
type : 'POST'
});


});

</script>
</div>

<div class="row mr-2">

<div class="col overflow-auto p-4 mr-3">
<table class="table table-responsive table-stripped">
<thead>
<tr>
<th> S/N </th>
<th> User Id </th>
<th> Full Name </th>
<th> Ver. method </th>
<th> Selfie/Passport </th>
<th> Doc. Proof </th>
<th> Time </th>
<th> Status </th>
<th> Action </th>
</tr>
</thead>
<tbody>
<?php
global $wpdb;
$table_name = $wpdb->prefix."vp_kyc";
$datas = $wpdb->get_results("SELECT * FROM $table_name ");

foreach($datas as $dis){
	$sn  = $dis->id;
	$user = $dis->user_id;
	$name = $dis->name;
	$method = $dis->method;
	$selfie = $dis->selfie;
	$proof = $dis->proof;
	$time = $dis->the_time;
	$status = $dis->status;
echo"
<tr>
<td> $sn </td>
<td> $user </td>
<td> $name </td>
<td> $method </td>
<td> $selfie </td>
<td> $proof </td>
<td> $time </td>
<td> $status </td>
<td>
";
?>
<select class="kyc_<?php echo $user.$sn;?> ">
<option value="review">REVIEW</option>
<option value="retry">RETRY</option>
<option value="verified">APPROVE</option>
<option value="ban">BAN</option>
</select>
<script>
jQuery(".kyc_<?php echo $user.$sn;?>").on("change",function(){
	jQuery("#cover-spin").show();

var obj = {};
obj["status"] = jQuery(".kyc_<?php echo $user.$sn;?>").val();
obj["action"] = jQuery(".kyc_<?php echo $user.$sn;?>").val();
obj["id"] = "<?php echo $user;?>";

 
jQuery.ajax({
url: "<?php echo esc_url(plugins_url('vtupress/template/classic/sections/kycupload.php'));?>",
data : obj,
dataType: 'text',
'cache': false,
 "async": true,
error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data) {
	  jQuery("#cover-spin").hide();
        if(data == "100"){
		  swal({
  title: "Successfully Changed Status",
  text: "Thanks",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Error Changing Status",
  text: "Click Why To See Reason",
  icon: "warning",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
		location.reload();
      break;
    default:
      swal(data, {
      icon: "info",
    });
  }
});
	  }
  },
type : 'POST'
});

 
});


</script>
<?php
echo"
</td>
</tr>
";
}

?>
</tbody>
</table>
</div>

</div>

</div>
<script>
jQuery(window).on("load",function(){
	jQuery("#cover-spin").hide();

	});
	


</script>
<?php
	
	
}


function vtulevels(){
	global $wpdb;
	
	add_option("drop_tb1",1);
	
if(get_option("drop_tb1") == 1){
$table_name = $wpdb->prefix . 'vp_levels';
$sql = "DROP TABLE IF EXISTS $table_name";
$wpdb->query($sql);


$charset_collate=$wpdb->get_charset_collate();
$sql= "CREATE TABLE IF NOT EXISTS $table_name(
id int NOT NULL AUTO_INCREMENT,
name text,

mtn_vtu DECIMAL(5,2) zerofill,
glo_vtu DECIMAL(5,2) zerofill,
mobile_vtu DECIMAL(5,2) zerofill,
airtel_vtu DECIMAL(5,2) zerofill,

mtn_awuf DECIMAL(5,2) zerofill,
glo_awuf DECIMAL(5,2) zerofill,
mobile_awuf DECIMAL(5,2) zerofill,
airtel_awuf DECIMAL(5,2) zerofill,

mtn_share DECIMAL(5,2) zerofill,
glo_share DECIMAL(5,2) zerofill,
mobile_share DECIMAL(5,2) zerofill,
airtel_share DECIMAL(5,2) zerofill,


mtn_sme DECIMAL(5,2) zerofill,
glo_sme DECIMAL(5,2) zerofill,
mobile_sme DECIMAL(5,2) zerofill,
airtel_sme DECIMAL(5,2) zerofill,

mtn_corporate DECIMAL(5,2) zerofill,
glo_corporate DECIMAL(5,2) zerofill,
mobile_corporate DECIMAL(5,2) zerofill,
airtel_corporate DECIMAL(5,2) zerofill,

mtn_gifting DECIMAL(5,2) zerofill,
glo_gifting DECIMAL(5,2) zerofill,
mobile_gifting DECIMAL(5,2) zerofill,
airtel_gifting DECIMAL(5,2) zerofill,

cable DECIMAL(5,2) zerofill,
bill_prepaid DECIMAL(5,2) zerofill,

card_mtn DECIMAL(5,2) zerofill,
card_glo DECIMAL(5,2) zerofill,
card_9mobile DECIMAL(5,2) zerofill,
card_airtel DECIMAL(5,2) zerofill,

epin_waec DECIMAL(5,2) zerofill,
epin_neco DECIMAL(5,2) zerofill,
epin_jamb DECIMAL(5,2) zerofill,
epin_nabteb DECIMAL(5,2) zerofill,


status text,
upgrade bigint,
developer text,
transfer text,

total_level int,
level_1 DECIMAL(5,2) zerofill,
level_1_upgrade DECIMAL(5,2) zerofill,


PRIMARY KEY (id))$charset_collate;";

require_once(ABSPATH.'wp-admin/includes/upgrade.php');
dbDelta($sql);

global $wpdb;
$table_name = $wpdb->prefix."vp_levels";
$customer = $wpdb->get_results("SELECT * FROM $table_name WHERE name = 'customer'");
$reseller = $wpdb->get_results("SELECT * FROM $table_name WHERE name = 'reseller'");

if($reseller == NULL){
$wpdb->insert($table_name, array(
'name'=> "reseller",
'mtn_vtu'=> "0",
'glo_vtu'=> "0",
'mobile_vtu'=> "0",
'airtel_vtu'=> "0",

'mtn_awuf'=> "0",
'glo_awuf'=> "0",
'mobile_awuf'=> "0",
'airtel_awuf'=> "0",

'mtn_share'=> "0",
'glo_share'=> "0",
'mobile_share'=> "0",
'airtel_share'=> "0",

'mtn_sme'=> "0",
'glo_sme'=> "0",
'mobile_sme'=> "0",
'airtel_sme'=> "0",

'mtn_corporate'=> "0",
'glo_corporate'=> "0",
'mobile_corporate'=> "0",
'airtel_corporate'=> "0",

'mtn_gifting'=> "0",
'glo_gifting'=> "0",
'mobile_gifting'=> "0",
'airtel_gifting'=> "0",

'cable'=> "0",

'bill_prepaid'=> "0",

'card_mtn'=> "0",
'card_glo'=> "0",
'card_9mobile'=> "0",
'card_airtel'=> "0",

'epin_waec'=> "0",
'epin_neco'=> "0",
'epin_jamb'=> "0",
'epin_nabteb'=> "0",

'status'=> "active",

'upgrade'=> "1000",
'total_level'=> "0",
'level_1'=> "0",
'level_1_upgrade'=> "0",
'developer'=> "no",
'transfer'=> "no"


));



}


if($customer == NULL){
$wpdb->insert($table_name, array(
'name'=> "customer",
'mtn_vtu'=> "0",
'glo_vtu'=> "0",
'mobile_vtu'=> "0",
'airtel_vtu'=> "0",

'mtn_awuf'=> "0",
'glo_awuf'=> "0",
'mobile_awuf'=> "0",
'airtel_awuf'=> "0",

'mtn_share'=> "0",
'glo_share'=> "0",
'mobile_share'=> "0",
'airtel_share'=> "0",

'mtn_sme'=> "0",
'glo_sme'=> "0",
'mobile_sme'=> "0",
'airtel_sme'=> "0",

'mtn_corporate'=> "0",
'glo_corporate'=> "0",
'mobile_corporate'=> "0",
'airtel_corporate'=> "0",

'mtn_gifting'=> "0",
'glo_gifting'=> "0",
'mobile_gifting'=> "0",
'airtel_gifting'=> "0",

'cable'=> "0",

'bill_prepaid'=> "0",

'card_mtn'=> "0",
'card_glo'=> "0",
'card_9mobile'=> "0",
'card_airtel'=> "0",

'epin_waec'=> "0",
'epin_neco'=> "0",
'epin_jamb'=> "0",
'epin_nabteb'=> "0",

'status'=> "active",

'upgrade'=> "1000",
'total_level'=> "0",
'level_1'=> "0",
'level_1_upgrade'=> "0",
'developer'=> "no",
'transfer'=> "no"


));



}

update_option("drop_tb1",2);
}
	
	
	
	
	
	
	
	
	$table_name = $wpdb->prefix."vp_levels";
	$option_array = json_decode(get_option("vp_options"),true);

  	

	$level = isset($_REQUEST["level"]) ? $_REQUEST["level"] : "1";
	
	$where = "WHERE id = $level";
	$datas = $wpdb->get_results("SELECT * FROM  $table_name $where");
	$data = $wpdb->get_results("SELECT * FROM  $table_name");


	
	?>
<link rel="stylesheet" href="<?php echo esc_url( plugins_url( 'vtupress/css/bootstrap.min.css?v=1') );?>" />
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/bootstrap.min.js?v=1') );?>" ></script>
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/jquery.js?v=1') );?>"></script>
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/sweet.js?v=1') );?>" ></script>

<style>

 #cover-spin {
        position:fixed;
        width:100%;
        left:0;right:0;top:0;bottom:0;
        background-color: rgba(255,255,255,0.7);
        z-index:9999;
        /*display:none;*/
    }
	 #cover-spin::after {
        content:"";
        display:block;
        position:absolute;
        left:48%;top:40%;
        width:40px;height:40px;
        border-style:solid;
        border-color:black;
        border-top-color:transparent;
        border-width: 4px;
        border-radius:50%;
        -webkit-animation: spin .8s linear infinite;
        animation: spin .8s linear infinite;
    }
.swal-button.swal-button--confirm {
    width: fit-content;
    padding: 10px !important;
}
</style>



<?php
if(!is_plugin_active("vprest/vprest.php")  || vp_option_array($option_array,"resell") != "yes"){
	
	die("
<div class='row my-3 mx-3'>
<div class='col font-bold text-white bg bg-danger p-3 rounded shadow'>
YOU CANT ACCESS THIS PAGE BECAUSE YOU ARE A PERSONAL/DEMO USER OR DOES NOT HAVE VP RESELLER ADDON INSTALLED
</div>
</div>
");

}
else{
$path = $_SERVER["DOCUMENT_ROOT"]."/wp-content/plugins/vprest/vprest.php";
$path = get_plugin_data($path);


if($path["Version"] < "2.1.0"){
		die("
<div class='row my-3 mx-3'>
<div class='col font-bold text-white bg bg-danger p-3 rounded shadow'>
VP RESELLER ADDON IS LESS THAN 2.1.0 PLEASE UPDATE IT.
</div>
</div>
");

}
else{

if(!is_plugin_active("vpmlm/vpmlm.php")  || vp_option_array($option_array,"resell") != "yes"){
	
	echo"
<div class='row my-3 mx-3'>
<div class='col font-bold text-white bg bg-primary p-3 rounded shadow'>
YOU CAN EXTEND YOUR PLUGIN FUNCTIONALITY INSTALLING VPMLM.
</div>
</div>
";

}
else{
$path2 = $_SERVER["DOCUMENT_ROOT"]."/wp-content/plugins/vpmlm/vpmlm.php";
$path2 = get_plugin_data($path2);
	if($path2["Version"] < "2.1.0"){
		die("
<div class='row my-3 mx-3'>
<div class='col font-bold text-white bg bg-danger p-3 rounded shadow'>
VP MLM ADDON IS LESS THAN 2.1.0 PLEASE UPDATE IT.
</div>
</div>
");

}

}
	
}
}
?>

 <div id="cover-spin" >

</div>

<script>
jQuery("body").ready(function(){
	jQuery("#cover-spin").hide();
	jQuery("#wpfooter").hide();
});
</script>


<div class="container">

<div class="row">
<form class="vtupress_level">
<div class="col-12 bg bg-white">


<div class="row pt-5 bg-primary">

<div class="col-12 col-sm  ">
<div class="input-group">

<span class="input-group-text">NEW LEVEL</span>
<input type="text" placeholder="Plan Name" class="level_name">
<input type="button" class="create_level" value="CREATE">

</div>
</div>

<div class="col-12 col-sm ">

<div class="input-group">
<span class="input-group-text">SELECT LEVEL</span>
<select class="form-control level_id">
<option value="<?php echo $datas[0]->id;?>"><?php echo strtoupper($datas[0]->name);?></option>
<?php
foreach($data as $levels){
	?>
<option value="<?php echo $levels->id;?>"><?php echo strtoupper($levels->name);?></option>
	<?php
}
?>
</select>
<input type="button" value="DELETE" class="delete_level">
</div>
</div>

</div>

<div class="row p-4 bg bg-primary">
<div class="font-bold text-black bg bg-warning p-3 p-sm-5">
Please note that all values are percentage based and are calculated based on fixed price e.g fixed price on the data prices page compared to the percentage given for the service.
</div>
<div class="col-12 bg bg-secondary">
<div class="row">

<div class="col-12 col-sm  bg bg-secondary p-3">
<div class="input-group">
<span class="input-group-text">NAME</span>
<input type="text" placeholder="Plan Name" name="name" value="<?php echo $datas[0]->name;?>" class="d_level_name" readOnly>
</div>

<div class="input-group">
<span class="input-group-text">UPGRADE AMOUNT</span>
<input type="number" placeholder="Plan Price" name="upgrade" value="<?php echo $datas[0]->upgrade;?>">
</div>
</div>

<div class="col-12 col-sm bg bg-secondary p-3">
<div class="input-group">
<span class="input-group-text">STATUS</span>
<select class="form-control status" name="status">
<option value="<?php echo $datas[0]->status;?>"><?php echo strtoupper($datas[0]->status);?></option>
<option value="in-active">IN ACTIVE</option>
<option value="active">ACTIVE</option>
</select>
</div>

<div class="input-group">
<span class="input-group-text">API ACCESS</span>
<select class="form-control developer"  name="developer">
<option value="<?php echo $datas[0]->developer;?>"><?php echo strtoupper($datas[0]->developer);?></option>
<option value="no">NO</option>
<option value="yes">YES</option>
</select>
<span class="input-group-text">Transfer Access</span>
<select class="form-control transfer"  name="transfer">
<option value="<?php echo $datas[0]->transfer;?>"><?php echo strtoupper($datas[0]->transfer);?></option>
<option value="no">NO</option>
<option value="yes">YES</option>
</select>
</div>
</div>

</div>
</div>
</div>



<div class="col-12 col-sm my-5 mx-1">
		<span class="font-bold">AIRTIME</span>
		<div class="p-3">
	<div class="row">
	
		<div class="col-12 col-sm my-3">
		<span> VTU </span>
			<div class="input-group">
				<span class="input-group-text">MTN VTU</span>
				<input type="number" class="form-group" name="mtn_vtu" value="<?php echo floatval($datas[0]->mtn_vtu);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">GLO VTU</span>
				<input type="number" class="form-group"  name="glo_vtu" value="<?php echo floatval($datas[0]->glo_vtu);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">AIRTEL VTU</span>
				<input type="number" class="form-group"  name="airtel_vtu"  value="<?php echo floatval($datas[0]->airtel_vtu);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">9MOBILE VTU</span>
				<input type="number" class="form-group"  name="mobile_vtu"  value="<?php echo floatval($datas[0]->mobile_vtu);?>">
			</div>
		</div>


		<div class="col-12 col-sm  my-3">
		<span> SHARE & SELL </span>
			<div class="input-group">
				<span class="input-group-text">MTN SHARE</span>
				<input type="number" class="form-group"  name="mtn_share"  value="<?php echo floatval($datas[0]->mtn_share);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">GLO SHARE</span>
				<input type="number" class="form-group"  name="glo_share"  value="<?php echo floatval($datas[0]->glo_share);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">AIRTEL SHARE</span>
				<input type="number" class="form-group"  name="airtel_share"  value="<?php echo floatval($datas[0]->airtel_share);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">9MOBILE SHARE</span>
				<input type="number" class="form-group"  name="mobile_share"  value="<?php echo floatval($datas[0]->mobile_share);?>">
			</div>
		</div>
		
		
		<div class="col-12 col-sm  my-3">
		<span> AWUF </span>
			<div class="input-group">
				<span class="input-group-text">MTN AWUF</span>
				<input type="number" class="form-group"  name="mtn_awuf"  value="<?php echo floatval($datas[0]->mtn_awuf);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">GLO AWUF</span>
				<input type="number" class="form-group"  name="glo_awuf"  value="<?php echo floatval($datas[0]->glo_awuf);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">AIRTEL AWUF</span>
				<input type="number" class="form-group"  name="airtel_awuf"  value="<?php echo floatval($datas[0]->airtel_awuf);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">9MOBILE AWUF</span>
				<input type="number" class="form-group"  name="mobile_awuf" value="<?php echo floatval($datas[0]->mobile_awuf);?>">
			</div>
		</div>
		
</div>
	</div>
</div>



<div class="col-12 col-sm my-5 mx-1">
		<span class="font-bold">DATA</span>
		<div class="p-3">
	<div class="row">
	
		<div class="col-12 col-sm my-3">
		<span> SME </span>
			<div class="input-group">
				<span class="input-group-text">MTN SME</span>
				<input type="number" class="form-group"  name="mtn_sme"  value="<?php echo floatval($datas[0]->mtn_sme);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">GLO SME</span>
				<input type="number" class="form-group"  name="glo_sme"  value="<?php echo floatval($datas[0]->glo_sme);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">AIRTEL SME</span>
				<input type="number" class="form-group"  name="airtel_sme"  value="<?php echo floatval($datas[0]->airtel_sme);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">9MOBILE SME</span>
				<input type="number" class="form-group"  name="mobile_sme"  value="<?php echo floatval($datas[0]->mobile_sme);?>">
			</div>
		</div>


		<div class="col-12 col-sm my-3">
		<span> CORPORATE </span>
			<div class="input-group">
				<span class="input-group-text">MTN Corp</span>
				<input type="number" class="form-group"  name="mtn_corporate"  value="<?php echo floatval($datas[0]->mtn_corporate);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">GLO Corp</span>
				<input type="number" class="form-group"  name="glo_corporate"  value="<?php echo floatval($datas[0]->glo_corporate);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">AIRTEL Corp</span>
				<input type="number" class="form-group"  name="airtel_corporate"  value="<?php echo floatval($datas[0]->airtel_corporate);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">9MOBILE Corp</span>
				<input type="number" class="form-group"  name="mobile_corporate"  value="<?php echo floatval($datas[0]->mobile_corporate);?>">
			</div>
		</div>
		
		
		<div class="col-12 col-sm my-3">
		<span> GIFTING </span>
			<div class="input-group">
				<span class="input-group-text">MTN Gift</span>
				<input type="number" class="form-group"  name="mtn_gifting"  value="<?php echo floatval($datas[0]->mtn_gifting);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">GLO Gift</span>
				<input type="number" class="form-group"   name="glo_gifting"    value="<?php echo floatval($datas[0]->glo_gifting);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">AIRTEL Gift</span>
				<input type="number" class="form-group"   name="airtel_gifting"   value="<?php echo floatval($datas[0]->airtel_gifting);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">9MOBILE Gift</span>
				<input type="number" class="form-group"   name="mobile_gifting"   value="<?php echo floatval($datas[0]->mobile_gifting);?>">
			</div>
		</div>
		

	</div>

</div>

</div>




<div class="col-12 col-sm my-5 mx-1">
		<span class="font-bold">MISC.</span>
		<div class="p-3">
	<div class="row">
	
		<div class="col-12 col-sm my-3">
		<span> UTILITIES </span>
			<div class="input-group">
				<span class="input-group-text">CABLES</span>
				<input type="number" class="form-group"   name="cable"  value="<?php echo floatval($datas[0]->cable);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">BILLS</span>
				<input type="number" class="form-group"   name="bill_prepaid"   value="<?php echo floatval($datas[0]->bill_prepaid);?>">
			</div>
		</div>


		<div class="col-12 col-sm my-3">
		<span> ECARDS </span>
			<div class="input-group">
				<span class="input-group-text">MTN CARDS</span>
				<input type="number" class="form-group"  name="card_mtn"  value="<?php echo floatval($datas[0]->card_mtn);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">GLO CARDS</span>
				<input type="number" class="form-group" name="card_glo" value="<?php echo floatval($datas[0]->card_glo);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">AIRTEL CARDS</span>
				<input type="number" class="form-group" name="card_airtel" value="<?php echo floatval($datas[0]->card_airtel);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">9MOBILE CARDS</span>
				<input type="number" class="form-group" name="card_9mobile" value="<?php echo floatval($datas[0]->card_9mobile);?>">
			</div>
		</div>
		
		
		<div class="col-12 col-sm my-3">
		<span> EPINS </span>
			<div class="input-group">
				<span class="input-group-text">WAEC EPINS</span>
				<input type="number" class="form-group" name="epin_waec" value="<?php echo floatval($datas[0]->epin_waec);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">NECO EPINS</span>
				<input type="number" class="form-group"   name="epin_neco" value="<?php echo floatval($datas[0]->epin_neco);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">JAMB EPINS</span>
				<input type="number" class="form-group"  name="epin_jamb"  value="<?php echo floatval($datas[0]->epin_jamb);?>">
			</div>
			<div class="input-group">
				<span class="input-group-text">NABTEB EPINS</span>
				<input type="number" class="form-group"  name="epin_nabteb"  value="<?php echo floatval($datas[0]->epin_nabteb);?>">
			</div>
		</div>
		

	</div>

</div>

</div>

<div class="col-12 col-sm my-5 mx-1">
		<span class="font-bold">Referral System</span>
		<div class="p-3">
	<div class="row">
	
		<div class="col-12 col-sm my-3">
		<span> Referral Level And Goodie Applicable To User [A] Which Is The Top Level Referral </span>
		<?php $total_leve = $datas[0]->total_level; 
		$total_level = floatval($total_leve);
		
		for($level = 1; $level <= $total_level; $level++){
			$level_price = $datas[0]->{"level_".$level};
			$level_price_upgrade = $datas[0]->{"level_".$level."_upgrade"};
			?>
			<div class="input-group">
				<span class="input-group-text">Level_<?php echo $level;?> - Transaction Bonus</span>
		<input type="number" class="form-group"   name="level_<?php echo $level;?>"  value="<?php echo floatval($level_price);?>">
				<span class="input-group-text">Level_<?php echo $level;?> - Upgrade Bonus</span>
		<input type="number" class="form-group"   name="level_<?php echo $level;?>_upgrade"  value="<?php echo floatval($level_price_upgrade);?>">
		
			</div>
		<?php
		}
		?>
		</div>
		<input type="button" class="create_ref_level mb-1" value="Add A Referral Level">
		<?php
		if($total_level > "0"){
			?>
		<input type="button" class="delete_ref_level" value="Delete Last Referral Level">
	<?php
		}
		?>
	</div>

</div>

</div>

<input type="button" class="update_level btn btn-primary" value="UPDATE <?php echo strtoupper($datas[0]->name);?> LEVEL ">
</form>
</div><!--ROW DIV END-->
</div>
	



<!--SCRIPT-->
<script>



jQuery(".delete_ref_level").on("click",function(){
	
var obj = {};
obj["level_action"] = "delete_ref_level";
obj["level_id"] = jQuery(".level_id").val();
jQuery("#cover-spin").show();

jQuery.ajax({
  url: '<?php echo esc_url(plugins_url("vtupress/levels.php"));?>',
  data: obj,
 dataType: 'text',
  'cache': false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data){
	  jQuery("#cover-spin").hide();
        if(data == "100"){
		  swal({
  title: "Successful",
  text: "LAST REFERRAL LEVEL DELETED",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Failed To Delete Last Referral Level",
  text: "Click \'Why\' To See reason",
  icon: "error",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
      break;
    default:
      swal(data, {
      icon: "info",
    });
  }
});
	  }
  },
  type: 'POST'
});



});



jQuery(".create_ref_level").on("click",function(){
	
var obj = {};
obj["level_action"] = "create_ref_level";
obj["level_id"] = jQuery(".level_id").val();

	jQuery("#cover-spin").show();


jQuery.ajax({
  url: '<?php echo esc_url(plugins_url("vtupress/levels.php"));?>',
  data: obj,
 dataType: 'text',
  'cache': false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data){
	  jQuery("#cover-spin").hide();
        if(data == "100"){
		  swal({
  title: "Successful",
  text: "REFERRAL LEVEL CREATED",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Failed To Create Referral Level",
  text: "Click \'Why\' To See reason",
  icon: "error",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
      break;
    default:
      swal(data, {
      icon: "info",
    });
  }
});
	  }
  },
  type: 'POST'
});
});




jQuery(".create_level").on("click",function(){
	
var obj = {};
obj["level_action"] = "create_level";
obj["level_name"] = jQuery(".level_name").val();

	jQuery("#cover-spin").show();


jQuery.ajax({
  url: '<?php echo esc_url(plugins_url("vtupress/levels.php"));?>',
  data: obj,
 dataType: 'text',
  'cache': false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data){
	  jQuery("#cover-spin").hide();
        if(data == "100"){
		  swal({
  title: "Successful",
  text: "LEVEL CREATED",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Failed To Create Level",
  text: "Click \'Why\' To See reason",
  icon: "error",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
      break;
    default:
      swal(data, {
      icon: "info",
    });
  }
});
	  }
  },
  type: 'POST'
});
});



jQuery(".delete_level").on("click",function(){
	
var obj = {};
obj["level_action"] = "delete_level";
obj["level_id"] = jQuery(".level_id").val();
obj["level_name"] = jQuery(".d_level_name").val();
	jQuery("#cover-spin").show();
var name = jQuery(".d_level_name").val();

if(confirm("Do you want to delete plan "+name.toUpperCase()+"?") == true){
if(name != "customer" && name != "reseller"){
jQuery.ajax({
  url: '<?php echo esc_url(plugins_url("vtupress/levels.php"));?>',
  data: obj,
 dataType: 'text',
  'cache': false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data){
	  jQuery("#cover-spin").hide();
        if(data == "100"){
		  swal({
  title: "Successful",
  text: "LEVEL "+name+" DELETED",
  icon: "success",
  button: "Okay",
}).then((value) => {
	window.location = "?page=vtulevels";
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Failed To Delete Level",
  text: "Click \'Why\' To See reason",
  icon: "error",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
      break;
    default:
      swal(data, {
      icon: "info",
    });
  }
});
	  }
  },
  type: 'POST'
});
}
else{
alert("You can't Delete Default Levels Namely [Customer/Reseller]");
	jQuery("#cover-spin").hide();	
}
}
else{
	
	jQuery("#cover-spin").hide();
	
}


});



jQuery(".update_level").on("click",function(){

	jQuery("#cover-spin").show();

var obj = {};
obj["level_action"] = "update_level";
obj["level_id"] = "<?php echo $datas[0]->id; ?>";
var toatl_input = jQuery(".vtupress_level select, .vtupress_level input").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".vtupress_level select, .vtupress_level input").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}
	
}

	jQuery("#cover-spin").show();


jQuery.ajax({
  url: '<?php echo esc_url(plugins_url("vtupress/levels.php"));?>',
  data: obj,
 dataType: 'text',
  'cache': false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data){
	  jQuery("#cover-spin").hide();
        if(data == "100"){
		  swal({
  title: "Successful",
  text: "LEVEL UPDATED",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Failed To Update Level",
  text: "Click \'Why\' To See reason",
  icon: "error",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
      break;
    default:
      swal(data, {
      icon: "info",
    });
  }
});
	  }
  },
  type: 'POST'
});
});


jQuery(".level_id").on("change",function(){
jQuery("#cover-spin").show();

var id = jQuery(".level_id").val();

window.location = "?page=vtulevels&level="+id;

});

</script>
	
	<?php
	
}

function vpsystem(){
	?>
<link rel="stylesheet" href="<?php echo esc_url( plugins_url( 'vtupress/css/bootstrap.min.css?v=1') );?>" />
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/bootstrap.min.js?v=1') );?>" ></script>
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/jquery.js?v=1') );?>"></script>
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/sweet.js?v=1') );?>" ></script>
<style>
    #cover-spin {
        position:fixed;
        width:100%;
        left:0;right:0;top:0;bottom:0;
        background-color: rgba(255,255,255,0.7);
        z-index:9999;
        /*display:none;*/
    }
	    #cover-spin::after {
        content:"";
        display:block;
        position:absolute;
        left:48%;top:40%;
        width:40px;height:40px;
        border-style:solid;
        border-color:black;
        border-top-color:transparent;
        border-width: 4px;
        border-radius:50%;
        -webkit-animation: spin .8s linear infinite;
        animation: spin .8s linear infinite;
    }
	
</style>
	
      <div id="cover-spin" >
	  
	  </div>
<div class="container">
<div class="row border border-secondary mb-4">

<div class="col-3 border border-secondary bg-success text-white" style="text-align:center;">
<h3>Security:
<div class="spinner-border text-primary" role="status">

</div>

</h3><br>
<h4>
<?php
if(vp_getoption("vp_security") == "yes" && vp_getoption("secur_mod") != "off"){
echo "<span class='badge badge-info'>Running</span> ";
}
else{
echo "<span class='badge badge-danger'>Not Running</span>";	
}
?>
</h4>
</div>

<div class="col-6 border border-secondary bg-primary text-white">
<?php
//whether ip is from share internet
if (!empty($_SERVER['HTTP_CLIENT_IP']))   
  {
    $ip_address = $_SERVER['HTTP_CLIENT_IP'];
	$system = "Shared Internet";
  }
//whether ip is from proxy
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))  
  {
    $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
	$system = "Proxy";
  }
//whether ip is from remote address
else
  {
    $ip_address = $_SERVER['REMOTE_ADDR'];
	$system = "Remote";
  }
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip_address}/json"));

if(vp_getoption("vp_security") == "yes"){
	$disabled = "data=''";
}else{
	$disabled = "disabled";
}

?>
<h3>Last Login IP: - <span class="badge badge-secondary"><?php echo $system;?></span></h3><br>
<h4><?php echo $ip_address;?></h4>
</div>


<div class="col-3 border border-secondary bg-secondary text-white" style="text-align:center;">
<h3>Location</h3><br>
<h4><?php echo $details->city;?> - <?php echo $details->country;?></h4>


</div>


</div>

<div class="row">
<div class="col">
<div class="input-group">
<span class="input-group-text">URL</span>
<span class="input-group-text"><?php echo vp_getoption("siteurl");?></span>
</div>
</div>

<div class="col-2">
<div class="input-group">
<span class="input-group-text">SSL</span>
<?php
$stream = stream_context_create (array("ssl" => array("capture_peer_cert" => true)));
$read = fopen(vp_getoption("siteurl"), "rb", false, $stream);
$cont = stream_context_get_params($read);
$var = ($cont["options"]["ssl"]["peer_certificate"]);
$result = (!is_null($var)) ? true : false;
if(is_null($var)){
?>
<span class="input-group-text">NO</span>
<?php
}else{
	?>
<span class="input-group-text">YES</span>
<?php
}
?>
</div>
</div>

<div class="col">
<div class="input-group">
<span class="input-group-text">SERVER NAME</span>
<span class="input-group-text"><?php echo $_SERVER["SERVER_NAME"];?></span>
</div>
</div>

<div class="col">
<div class="input-group">
<span class="input-group-text">HTTP HOST</span>
<span class="input-group-text"><?php echo $_SERVER['HTTP_HOST'];?></span>
</div>
</div>


</div>



<div class="row border border-secondary mb-4">
<div class="col border border-primary">
<div class="info">
<label class="form-label">HTTP REDIRECTION</label>
<br>
Redirect All http request to https (recommended)
</div><br>
<div class="input-group">
<span class="input-group-text">Force Http</span>
<input type="checkbox" class="btn-check hr" id="btn-check-outlined" autocomplete="off" name="http-redirection" >
<label class="btn btn-outline-primary hrt" for="btn-check-outlined">...</label>

</div>
 </div>
 
 <div class="col border border-primary">
 <div class="info">
 <label class="form-label">SECURITY MODE</label>
 <br>
Calm: Make the login security level focus on Vpaccount login page.<br>
Calm: Automatically takes time to ban users<br>
Wild: Makes the login security level focus on vpaccount and wp_login levels<br>
Wild: Watches system strictly and automatically handles users with it's Artificial Intelligence<br>
 </div><br>
 <?php
 if(vp_getoption("vp_security") == "yes"){
?>
 <div class="bottom-button" style="position:relative; bottom:0;">
 <input type="radio" class="btn-check sm off" name="security-mode" id="success-outlied" autocomplete="off" value="off">
<label class="btn btn-outline-primary" for="success-outlied">Off</label>
 
<input type="radio" class="btn-check sm calm" name="security-mode" id="success-outlined" autocomplete="off" value="calm">
<label class="btn btn-outline-success" for="success-outlined">Calm</label>

<input type="radio" class="btn-check sm wild" name="security-mode" id="danger-outlined" autocomplete="off" value="wild">
<label class="btn btn-outline-danger" for="danger-outlined">Wild</label>
 </div>
 
<?php
}
else{
?>
<a href="https://api.whatsapp.com/send/?phone=2347049626922&text=Unlock%20Security%20Feature%20For%20Me&app_absent=0" >
<input type="button" class="btn-check btn-primary" name="security-mode" id="danger-outlined" autocomplete="off" checked>
<label class="btn btn-outline-primary text-whit" for="danger-outlined">UNLOCK SECURITY FEATURE</label>
</a>
<?php	
}
?>
 </div>
 

  <div class="col border border-primary">
 <div class="info">
 
 
 <label class="form-label">GLOBAL SECURITY</label>
 <br>
Choose whether you want vtupress to handle security steps from your site across all other sites using vtupress.<br>
<blockquote>That is, Once you ban a user, the user will not be able to access other websites using vtupress<blockquote><br>
</div><br>
<?php
if(vp_getoption("vp_security") == "yes"){
?>
 <div class="bottom-button" style="position:relative; bottom:0;">

<input type="radio" class="btn-check gs enabled" name="global-security" id="success-outline" autocomplete="off" value="enabled">
<label class="btn btn-outline-success" for="success-outline">Enable</label>

<input type="radio" class="btn-check gs disabled" name="global-security" id="danger-outline" autocomplete="off" value="disabled">
<label class="btn btn-outline-danger" for="danger-outline">Disable</label>
</div>
<?php
}
else{
?>
<a href="https://api.whatsapp.com/send/?phone=2347049626922&text=Unlock%20Security%20Feature%20For%20Me&app_absent=0" >
<input type="button" class="btn-check bg-primary" name="security-mode" id="primary-outlined" autocomplete="off"  checked>
<label class="btn btn-outline-primary text-whit" for="primary-outlined">UNLOCK SECURITY FEATURE</label>
</a>
<?php	
}
?>
 </div>
 </div>



</div>

<div class="container">
<div class="row border border-secondary mb-4">
<div class="col p-3">
<div class="row">
<div class="col">
<h5>Ban IPs:<small class="small">Separate Ips by Comma [,]</small></h5><br>
<textarea class="form-control ips" <?php echo $disabled;?> ><?php echo vp_getoption("vp_ips_ban");?></textarea>
</div>
<div class="col">
<h5>Ban users:<small class="small" >Separate Ips by Comma [,]</small></h5><br>
<textarea class="form-control users" <?php echo $disabled;?>><?php echo vp_getoption("vp_users_ban");?></textarea>
</div>
</div>
<br>
<h5>Ban From:</h5><br>
<div class="form-check">
  <input class="form-check-input user-dashboard" type="checkbox" value="" id="flexCheckDefault" <?php echo $disabled;?>>
  <label class="form-check-label" for="flexCheckDefault">
   Accessing User Dashboard
  </label>
</div>
<div class="form-check">
  <input class="form-check-input entire-website" type="checkbox" value="" id="flexCheckChecked" <?php echo $disabled;?>>
  <label class="form-check-label" for="flexCheckChecked">
   Accessing Entire Website
  </label>
</div>
<div class="form-check">
  <input class="form-check-input other-country" type="checkbox" value="" id="flexCheckCheckedr" <?php echo $disabled;?>>
  <label class="form-check-label" for="flexCheckCheckedr">
   Accessing Website In Other Country
  </label>
</div>

</div>

<div  class="mt-2 mb-2">
<input type="button" value="SAVE" class="btn btn-success save-security">
</div>
</div>
</div>

<script>
jQuery(window).on("load",function(){
jQuery("#cover-spin").hide();
});
jQuery(".hr").on("change",function(){
	if(jQuery(this).is(":checked")){
		jQuery('.hr').attr('checked','checked');
		jQuery('.hrt').text('Enabled');
	}
	else{
		jQuery('.hr').removeAttr('checked');
		jQuery('.hrt').text('Disabled');
	}
});
<?php
if(vp_getoption("http_redirect") == "true"){
echo"
jQuery('.hr').attr('checked','checked');
jQuery('.hr').trigger('click');
jQuery('.hrt').text('Enabled');
jQuery('.hrt').trigger('click');
";
}
else{
echo"
jQuery('.hrt').text('Disabled');
";	
}

echo"
jQuery('.".vp_getoption("global_security")."').prop('checked');
jQuery('.".vp_getoption("global_security")."').trigger('click');
";


echo "jQuery('.".vp_getoption("secur_mod")."').prop('checked');";
echo "jQuery('.".vp_getoption("secur_mod")."').trigger('click');";


if(vp_getoption("access_website") == "true"){
	echo "jQuery('.entire-website').prop('checked');";
	echo "jQuery('.entire-website').trigger('click');";
}

if(vp_getoption("access_user_dashboard") == "true"){
	echo "jQuery('.user-dashboard').prop('checked');";
	echo "jQuery('.user-dashboard').trigger('click');";
}

if(vp_getoption("access_country") == "true"){
	echo "jQuery('.other-country').prop('checked');";
	echo "jQuery('.other-country').trigger('click');";
}

?>
jQuery(".save-security").on("click",function(){
jQuery("#cover-spin").show();
var savesecurity = jQuery(".sm:checked").val();
var httpredirection = jQuery(".hr").is(":checked");
var globalsecurity = jQuery(".gs:checked").val();
var userdashboard = jQuery(".user-dashboard").is(":checked");
var enterwebsite = jQuery(".entire-website").is(":checked");
var othercountry = jQuery(".other-country").is(":checked");
var ips = jQuery(".ips").val();
var users = jQuery(".users").val();


var obj = {};
obj["secure"] = "secure";
obj["http"] = httpredirection;
obj["global"] = globalsecurity;
obj["security"] = savesecurity;
obj["httips"] = ips;
obj["users"] = users;
obj["access-website"] = enterwebsite;
obj["user-dashboard"] = userdashboard;
obj["other-country"] = othercountry;

/*
alert("http "+obj["http"]);
alert("global "+obj["global"]);
alert("security "+obj["security"]);
alert("ips "+obj["httips"]);
alert("users "+obj["users"]);
alert("aw "+obj["access-website"]);
alert("ud "+obj["user-dashboard"]);
alert("oc "+obj["other-country"]);
*/

jQuery.ajax({
  url: '<?php echo esc_url(plugins_url('vtupress/system.php'));?>',
  data: obj,
 dataType: 'text',
  'cache': false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data) {
	  jQuery("#cover-spin").hide();
        if(data == "100"){
		  swal({
  title: "SAVED",
  text: "Successfully",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
		  swal({
  title: "Error",
  text: data,
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: 'POST'
});





});

</script>
<?php	
}

function vplicense(){
	?>
<link rel="stylesheet" href="<?php echo esc_url( plugins_url( 'vtupress/css/bootstrap.min.css?v=1') );?>" />
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/bootstrap.min.js?v=1?v=1') );?>" ></script>
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/jquery.js?v=1?v=1') );?>"></script>
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/sweet.js?v=1') );?>" ></script>
<style>
.swal-button.swal-button--confirm {
    width: fit-content;
    padding: 10px !important;
}

 #cover-spin {
        position:fixed;
        width:100%;
        left:0;right:0;top:0;bottom:0;
        background-color: rgba(255,255,255,0.7);
        z-index:9999;
        /*display:none;*/
    }
#cover-spin::after {
        content:"";
        display:block;
        position:absolute;
        left:48%;top:40%;
        width:40px;height:40px;
        border-style:solid;
        border-color:black;
        border-top-color:transparent;
        border-width: 4px;
        border-radius:50%;
        -webkit-animation: spin .8s linear infinite;
        animation: spin .8s linear infinite;
    }

</style>

<div id="cover-spin" >
	  
</div>
<script>
jQuery("body").ready(function(){
	jQuery("#cover-spin").hide();
});
</script>

<?php
	
$http_args = array(
'headers' => array(
'cache-control' => 'no-cache',
'content-type' => 'application/json',
'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:100.0) Gecko/20100101 Firefox/100.0'
),
'sslverify' => false);
$url = 'https://vtupress.com/wp-content/plugins/vtuadmin?id='.vp_getoption('vpid').'&actkey='.vp_getoption('actkey');

$response = wp_remote_retrieve_body(wp_remote_get($url, $http_args));


if(is_wp_error($response)){
$error = $response->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
$json = json_encode($obj)->response;
echo"
<script>
alert($json);
</script>
";
}
else{
$en = json_decode($response, true);

if(!empty($en)){
	
$mkey = vp_getoption('actkey');

if(isset($en["security"])){
$security = $en["security"];
}
else{
$security = "no";
}

if(!empty($en["actkey"])){
	if($en["actkey"] == $mkey){
$check_key = "yes";
	}else{	
$check_key = "no";	
	}
}
else{
$check_key = "no";
}

//$_SERVER['SERVER_NAME'];

if(!empty($en["url"])){
	if(preg_match("/".$_SERVER['HTTP_HOST']."/i",$en["url"]) != 0 || strpos($en["url"],$_SERVER['HTTP_HOST']) != false || strpos($en["url"],$_SERVER['SERVER_NAME']) != false || strpos($en["url"],vp_getoption('siteurl')) != false || is_numeric(strpos($en["url"],$_SERVER['HTTP_HOST'])) != false || is_numeric(strpos($en["url"],$_SERVER['SERVER_NAME'])) != false){
$murl = "yes";
	}else{
$murl = "no";	
	}
//echo strpos($en["url"],$_SERVER['HTTP_HOST']);
//echo strpos($en["url"],$_SERVER['SERVER_NAME']);
}
else{
$murl = "no";

}



if($check_key == "yes" ){

$status = $en["status"];

$url = $en["url"];

$plan = $en["plan"];


    
    if( $murl == "yes"){
        
        if($status == "active"){
            
            if($plan){
if($security == "yes"){
	vp_updateoption("vp_security","yes");
}
else{
	vp_updateoption("vp_security","no");	
}

			/////////////////////////////////
	
if($plan == "demo"){
vp_updateoption('mlm','no');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
vp_updateoption('vprun','none');
vp_updateoption('resell','no');
}
elseif($plan == "unlimited"){
vp_updateoption('mlm','yes');
vp_updateoption('resell','yes');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
}
elseif($plan == "verified"){
vp_updateoption('resell','yes');
vp_updateoption('mlm','no');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
}
elseif($plan == "personal-y"){
vp_updateoption('resell','no');
vp_updateoption('mlm','no');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
}
elseif($plan == "premium-y"){
vp_updateoption('mlm','yes');
vp_updateoption('vprun','none');
vp_updateoption('resell','yes');
vp_updateoption('frmad','none');
}
elseif($plan == "premium"){
vp_updateoption('mlm','yes');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
vp_updateoption('resell','yes');
}
elseif($plan == "personal"){
vp_updateoption('mlm','no');
vp_updateoption('vprun','none');
vp_updateoption('resell','no');
vp_updateoption('frmad','none');
}
else{
vp_updateoption('mlm','no');
vp_updateoption('resell','no');
vp_updateoption("showlicense","hide");
vp_updateoption('vprun','block');
vp_updateoption('frmad','block');
vp_updateoption("vp_security","no");	
}
			////////////////////////////
            }
            
        }else{
//echo '{"status":"200","message":"Status Is '.$status.'"}';
vp_updateoption('mlm','no');
vp_updateoption('resell','no');
vp_updateoption("showlicense","hide");
vp_updateoption('vprun','block');
vp_updateoption('frmad','block');
vp_updateoption("vp_security","no");	
        }
    }else{
		
//echo '{"status":"200","message":"URL Doesn\'t Match or is not contained in the Url Directory in vtupress official site"}';
vp_updateoption('mlm','no');
vp_updateoption('resell','no');
vp_updateoption("showlicense","hide");
vp_updateoption('vprun','block');
vp_updateoption('frmad','block');
vp_updateoption("vp_security","no");
    }
    
}
else{
vp_updateoption('mlm','no');
vp_updateoption('resell','no');
vp_updateoption("showlicense","hide");
vp_updateoption('vprun','block');
vp_updateoption('frmad','block');
vp_updateoption("vp_security","no");
//echo '{"status":"200","message":"Activation Key Or Id Incorrect"}';
	
}	

}



}
	
	

//echo vp_getoption('vprun');



if(vp_getoption('vprun') == 'none'){
	
	$dstat = "active";
}
if(vp_getoption('vprun') != 'none'){
	
	$dstat = "not active";
}

	$did = vp_getoption('vpid');
	$actkey = vp_getoption('actkey');
	$mainurl = $_SERVER['HTTP_HOST'];
	echo "
	<form method='post' target='_self' class='setactivation'>
	<label>Your ID</label><br>
	<input type='number' value='$did' name='actid'><br>
	<label>Your Activation Key</label><br>
	<input type='text' value='$actkey' name='actkey'><br>
	<input type='text' value='$mainurl' name='mainurl' readOnly><br>
	<input type='text' value='$dstat' readOnly><br>
	<input type='button' value='Activate' name='setactivation' class='setactivation1'>
	
	</form>
	";
	echo'
	<script>
	
jQuery(".setactivation1").click(function(){
	jQuery("#cover-spin").show();
var obj = {};
var toatl_input = jQuery(".setactivation input").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".setactivation input").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}
	
	
}

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/vend.php')).'",
  data: obj,
  dataType: "json",
  cache: false,
  async: true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
		var text = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			text = jqXHR.responseText;
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){
	
		  swal({
  title: "Activated",
  text: "Activation Successful",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Activation Wasn\'t Successful",
  text: "Click \'Why\' To See reason",
  icon: "error",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
      break;
    default:
      swal(data.message, {
      icon: "info",
    });
  }
});
	
	
	
	  }
  },
  type: "POST"
});

});
	</script>
	';
	
}


function general(){
	?>
<link rel="stylesheet" href="<?php echo esc_url( plugins_url( 'vtupress/css/bootstrap.min.css?v=1') );?>" />
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/bootstrap.min.js?v=1') );?>" ></script>
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/jquery.js?v=1') );?>"></script>
<script src="<?php echo esc_url( plugins_url( 'vtupress/js/sweet.js?v=1') );?>" ></script>
<style>
.swal-button.swal-button--confirm {
    width: fit-content;
    padding: 10px !important;
}
</style>
	<?php
if(current_user_can("vtupress_access_general")){
echo '
<form method="post" class="fset_form" target="_SELF"><br>
<!--///////////////////////////////////////////DEBUG///////////////////-->



<div class="input-group mb-2">
<span class="input-group-text" id="basic-addon1">Template</span>
<select class="form-select form-select-sm" name="template">
<option value="'.vp_getoption("vp_template").'">'.vp_getoption("vp_template").'</option>
<option value="default">Default</option>
';
if(vp_getoption("resell") == "yes"){
	echo'
<option value="classic">Classic</option>
';
}

vp_addoption("vp_redirect","vpaccount");
vp_addoption("totcons","yes");
echo'
</select>
</div>



<div class="input-group mb-2">
<span class="input-group-text" id="basic-addon1">Enable Debug</span>
<select class="form-select form-select-sm" name="vpdebug">
<option value="'.vp_getoption("vpdebug").'">'.vp_getoption("vpdebug").'</option>
<option value="yes">Yes</option>
<option value="no">No</option>
</select>
</div>

<div class="input-group mb-2">
<span class="input-group-text" id="basic-addon1">Phone +234(0)</span>
<input type="number" class="form-control" name="vpphone" value="'.vp_getoption("vp_phone_line").'" required>
</div>

<div class="input-group mb-2">
<span class="input-group-text" id="basic-addon1">WhatsApp +234(0)</span>
<input type="number" class="form-control" name="vpwhatsapp" value="'.vp_getoption("vp_whatsapp").'" required>
</div>

<div class="input-group mb-2">
<span class="input-group-text" id="basic-addon1">WhatsApp Group Link</span>
<input type="text" class="form-control" name="vpwhatsappg" value="'.vp_getoption("vp_whatsapp_group").'" required>
</div>

<div class="input-group mb-2">
<span class="input-group-text" id="basic-addon1">Registration Complete Message</span>
<input type="text" class="form-control" placeholder="Welcome Message" name="upgradeamt" value="'.vp_getoption('resc').'">
</div>

<div class="input-group mb-2">
<span class="input-group-text" id="basic-addon1">Logout Redirection [without starting /]</span>
<input type="text" class="form-control" value="'.get_site_url().'/" readOnly>
<input type="text" class="form-control" placeholder="Redirect to e.g vpaccount" name="vpredirect" value="'.vp_getoption("vp_redirect").'">
</div>

<div class="input-group mb-2">
<span class="input-group-text" id="basic-addon1">Show Total Amount Of Service Consumed</span>
				   <select name="totcons"  class="form-control">
				   <option value="'.vp_getoption('totcons').'">'.ucfirst(vp_getoption('totcons')).'</option>
				   <option value="yes">Yes</option>
				   <option value="no">No</option>
				   </select>
</div>

';

	
if(is_plugin_active('vprest/vprest.php') && vp_getoption("resell") == "yes" ){

echo'
<div class="input-group mb-2">
<span class="input-group-text" id="basic-addon1">Allow Withdrawal?</span>
				   <select name="allow_withdrawal"  class="form-control">
				   <option value="'.vp_getoption('allow_withdrawal').'">'.vp_getoption('allow_withdrawal').'</option>
				   <option value="yes">Yes</option>
				   <option value="no">No</option>
				   </select>
<span class="input-group-text" id="basic-addon1">Allow Withdrawal To Bank</span>
				   <select name="allow_to_bank"  class="form-control">
				   <option value="'.vp_getoption('allow_to_bank').'">'.vp_getoption('allow_to_bank').'</option>
				   <option value="yes">Yes</option>
				   <option value="no">No</option>
				   </select>

</div>

<div class="input-group mb-2">
<span class="input-group-text" id="basic-addon1">Enable Crypto</span>
				   <select name="allow_crypto"  class="form-control">
				   <option value="'.vp_getoption('allow_crypto').'">'.vp_getoption('allow_crypto').'</option>
				   <option value="yes">Yes</option>
				   <option value="no">No</option>
				   </select>
<span class="input-group-text" id="basic-addon1">Enable Gift Cards</span>
				   <select name="allow_cards"  class="form-control">
				   <option value="'.vp_getoption('allow_cards').'">'.vp_getoption('allow_cards').'</option>
				   <option value="yes">Yes</option>
				   <option value="no">No</option>
				   </select>

</div>
';
}


echo'
<div class="input-group  mb-2">
<span class="input-group-text" id="basic-addon1">Wallet Funding Charge</span>
<select name="charge_method" class="form-control">
<option value="'.vp_getoption("charge_method").'">'.vp_getoption("charge_method").'</option>
<option value="percentage">Percentage</option>
<option value="fixed">Fixed[NGN]</option>
</select>
<input class="form-control" name="chargeback" value="'.vp_getoption("charge_back").'">
<br>
</div>

<div class="input-group  mb-2">
<span class="input-group-text" id="basic-addon1">Allow Wallet To Wallet Transfer</span>
				   <select name="wallettowallet"  class="form-control">
				   <option value="'.vp_getoption('wallet_to_wallet').'">'.vp_getoption('wallet_to_wallet').'</option>
				   <option value="yes">Yes</option>
				   <option value="no">No</option>
				   </select>
<br>
</div>

<div class="mb-2">
<label class="form-label" >Message Your Users</label><br>
<textarea class="form-control" name="message">'.vp_getoption("vpwalm").'</textarea>
<div class="input-group">
<span class="input-group-text">Show Pop-Up</span>
<select name="show_notify" class="show_notify">
<option value="'.vp_getoption("show_notify").'">'.vp_getoption("show_notify").'</option>
<option value="yes">Yes</option>
<option value="no">No</option>
</select>
</div>
<br>
</div>

<div class="mb-2">
<label class="form-label" >Message For Users On Fund Wallet Page</label><br>
<textarea class="form-control" name="fundmessage">'.vp_getoption("manual_funding").'</textarea>
<br>
</div>

<div class="mb-2 visually-hidden">
<label class="form-label">Page url after user successfully Registered e.g/vpaccount (default)</label><br>
<input type="text" class="form-control" value="'.vp_getoption("sucreg").'" name="sucreg"><br>
</div>
<input type="button" class="btn btn-primary fset"  name="fset" value="Save" >
</form>

<script>

jQuery(".fset").click(function(){
	jQuery("#cover-spin").show();
var obj = {};
var toatl_input = jQuery(".fset_form input, .fset_form select, .fset_form textarea ").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".fset_form input, .fset_form select, .fset_form textarea").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}
	
	
}

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/vend.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){
	
		  swal({
  title: "SAVED",
  text: "Update Completed",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error",
  text: "Saving Wasn\"t Successful",
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});
</script>
';

}
else{
	
	echo'
	<div class="bg bg-primary text-white container p-3" >
	Permission Not Granted!
	</div>
	';
}

}
return ob_get_clean();
?>