<?php
if (isset($_GET['txref'])) {
session_start();
$ref = $_GET['txref'];
$name = $_SESSION["name"];
$email = $_SESSION["email"];
$phone = $_SESSION["phone"];
$network = $_SESSION["network"];
$amount = $_SESSION["amounts"]; //Correct Amount from Server
$currency = "NGN"; //Correct Currency from Server
$query = array(
"SECKEY" => "FLWSECK_TEST-2ce0b9ae95f41be6bc8c54c6e565abd0-X",
"txref" => $ref
);

$data_string = json_encode($query);

$ch = curl_init('https://api.ravepay.co/flwv3-pug/getpaidx/api/v2/verify');                                                                      
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                              
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
$response = curl_exec($ch);
$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$header = substr($response, 0, $header_size);
$body = substr($response, $header_size);

curl_close($ch);

$resp = json_decode($response, true);

$paymentStatus = $resp['data']['status'];
$chargeResponsecode = $resp['data']['chargecode'];
$chargeAmount = $resp['data']['amount'];
$chargeCurrency = $resp['data']['currency'];

if (($chargeResponsecode == "00" || $chargeResponsecode == "0") && ($chargeAmount == $amount)  && ($chargeCurrency == $currency)) {


$ch = curl_init();
$url = "http://mobilemila.com/user/api/airtime?username=07049626922&password=9jaboard&network=mtn&amount=50&phone=07030237966";
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$resp = curl_exec($ch);

if($e = curl_error($ch)){
echo $e;
}else{
$en = json_decode($resp);
echo "<b style='text-align: left;'>".$en -> msg."</b>";
echo "<br>";
curl_close($ch);
}

switch($en -> status){
case 3:
echo "<h6>We received your order but we've run out of Credit. Contact us at summusuniversity@gmail.com for refund</h6>";
echo "NAME= ".$name."<br>";
echo "PHONE NUMBER= ". $phone."<br>";
echo "EMAIl=".$email. "<br>";
echo "NETWORK =".$network. "<br>";
echo "AMOUNT= ".$amount. "<br>";
break;

default:echo "Request Sent successfully! Transaction in progress";
}

} else {
header("location: /failed.php");
}
}
else {
die('No reference supplied');}
?>