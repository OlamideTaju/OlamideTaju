<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
if(WP_DEBUG == false){
error_reporting(0);	
}
ob_start();

include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');
function vtusettings(){
	if(vp_getoption('siteurl') != "https://vtupress.com" || vp_getoption('siteurl') != "vtupress.com" ){
	vp_addoption("separate_charges",0);
	if(vp_getoption("separate_charges") == 0){
vp_addoption("9airtime_to_cash_charge",0);
vp_addoption("gairtime_to_cash_charge",0);
vp_addoption("aairtime_to_cash_charge",0);
vp_addoption("aairtime_to_wallet_charge",0);
vp_addoption("9airtime_to_wallet_charge",0);
vp_addoption("gairtime_to_wallet_charge",0);
vp_updateoption("separate_charges",1);
	}
	
vtupress_js_css_user();
?>


<style>

 #cover-spin {
        position:fixed;
        width:100%;
        left:0;right:0;top:0;bottom:0;
        background-color: rgba(255,255,255,0.7);
        z-index:9999;
        /*display:none;*/
    }
	 #cover-spin::after {
        content:"";
        display:block;
        position:absolute;
        left:48%;top:40%;
        width:40px;height:40px;
        border-style:solid;
        border-color:black;
        border-top-color:transparent;
        border-width: 4px;
        border-radius:50%;
        -webkit-animation: spin .8s linear infinite;
        animation: spin .8s linear infinite;
    }
.swal-button.swal-button--confirm {
    width: fit-content;
    padding: 10px !important;
}
</style>
 <div id="cover-spin" >

</div>
<script>
jQuery("body").ready(function(){
	jQuery("#cover-spin").hide();
	jQuery("#wpfooter").hide();
});
</script>






<?php

$url = 'https://vtupress.com/wp-content/plugins/vtuadmin?id='.vp_getoption('vpid').'&actkey='.vp_getoption('actkey');
$request_url = $url;

$curl = curl_init($request_url);
$agent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)";

curl_setopt($curl, CURLOPT_USERAGENT, $agent);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, [
  'Content-Type: application/json'
]);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
// Check if initialization had gone wrong*    
    if ($curl === false) {
        throw new Exception('failed to initialize');
    }
$resp = curl_exec($curl);


if($e = curl_error($curl)){
echo'<script>alert("'.$e.'");</script>';
}
elseif($curl === false){
        throw new Exception('failed to initialize');
}
else{
$en = json_decode($resp, true);
curl_close($curl);

#echo vp_getoption('vpid');
#echo vp_getoption('actid');

$mkey = vp_getoption('actkey');

if(!empty($response)){
if(!empty($en["actkey"])){
	if($en["actkey"] == $mkey){
$check_key = "yes";
	}else{	
$check_key = "no";
	}
}
else{
$check_key = "no";
}

//$_SERVER['SERVER_NAME'];

if(!empty($en["url"])){
	if(preg_match("/".$_SERVER['HTTP_HOST']."/i",$en["url"]) != 0 || strpos($en["url"],$_SERVER['HTTP_HOST']) != false || strpos($en["url"],$_SERVER['SERVER_NAME']) != false || strpos($en["url"],vp_getoption('siteurl')) != false || is_numeric(strpos($en["url"],$_SERVER['HTTP_HOST'])) != false || is_numeric(strpos($en["url"],$_SERVER['SERVER_NAME'])) != false){
$murl = "yes";
	}else{
$murl = "no";	
	}
//echo strpos($en["url"],$_SERVER['HTTP_HOST']);
//echo strpos($en["url"],$_SERVER['SERVER_NAME']);
}
else{
$murl = "no";

}

if($check_key == "yes" ){

$status = $en["status"];

$url = $en["url"];

$plan = $en["plan"];

$security = $en["security"];


    
    if( $murl == "yes"){
        
        if($status == "active"){
            
            if($plan){
if($security == "yes"){
	vp_updateoption("vp_security","yes");
}
else{
	vp_updateoption("vp_security","no");	
}
			/////////////////////////////////
	
if($plan == "demo"){
vp_updateoption('mlm','no');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
vp_updateoption('vprun','none');
vp_updateoption('resell','no');
}
elseif($plan == "unlimited"){
vp_updateoption('mlm','yes');
vp_updateoption('resell','yes');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
}
elseif($plan == "verified"){
vp_updateoption('resell','yes');
vp_updateoption('mlm','no');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
}
elseif($plan == "personal-y"){
vp_updateoption('resell','no');
vp_updateoption('mlm','no');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
}
elseif($plan == "premium-y"){
vp_updateoption('mlm','yes');
vp_updateoption('vprun','none');
vp_updateoption('resell','yes');
vp_updateoption('frmad','none');
}
elseif($plan == "premium"){
vp_updateoption('mlm','yes');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
vp_updateoption('resell','yes');
}
elseif($plan == "personal"){
vp_updateoption('mlm','no');
vp_updateoption('vprun','none');
vp_updateoption('resell','no');
vp_updateoption('frmad','none');
}
else{
vp_updateoption('mlm','no');
vp_updateoption('resell','no');
vp_updateoption("showlicense","hide");
vp_updateoption('vprun','block');
vp_updateoption('frmad','block');
}	
			////////////////////////////
            }
            
        }
		else{
//echo '{"status":"200","message":"Status Is '.$status.'"}';
vp_updateoption('mlm','no');
vp_updateoption('resell','no');
vp_updateoption("showlicense","hide");
vp_updateoption('vprun','block');
vp_updateoption('frmad','block');
vp_updateoption('vp_security','no');
        }
    }
	else{
		
//echo '{"status":"200","message":"URL Doesn\'t Match or is not contained in the Url Directory in vtupress official site"}';
vp_updateoption('mlm','no');
vp_updateoption('resell','no');
vp_updateoption("showlicense","hide");
vp_updateoption('vprun','block');
vp_updateoption('frmad','block');
vp_updateoption('vp_security','no');
    }
    
}
else{
}	


}

}


if(vp_getoption('vprun') != 'none'){
 echo '
<b class="showdiv" id="div" style="width:100vw; height:100vh; background-color:#020317D9; color:white;">
You need to visit the license page to active your Accessibility<br>
 <p><b>Note:*</b> You get this message box if you are new using vtupress or if your plan has expired. Please contact us @ tech@vtupress.com or chat us via 07049626922 for assistance</p>
 </b>

<style>

.showdiv{display:'.vp_getoption('vprun').';position:fixed;  width:100%; background-color:#AAAAAA;z-index:1; height:50%; top:50px; text-align:center;}

</style>
<!-- DASHBOARD CONTAINER BEGINS -->
<h3>VTUPRESS Settings

';

}



if(vp_getoption("vprun") == "block"){
  echo '<script>
jQuery(".btn-nav-head").hide();
  </script>
  ';
  }

/*THE DASHBOARD*/
echo '
<div class="container-fluid">  Page</h3><br>

<div class="btn-group btn-nav-head" role="group" aria-label="styles" style="max-width:100%; overflow:scroll;">
';

if(current_user_can("vtupress_access_general")){
	echo'
<a href="#general" role="button" id="bbtn" class="btn btn-primary ">General</a> 
';
}
if(current_user_can("vtupress_access_payment")){
	echo'
<a href="#gateway" role="button" class="btn btn-primary" id="bbtn1" > Payment </a>
';
}
if(current_user_can("vtupress_access_history")){
	echo'
<a href="#transactions" role="button" class="btn btn-primary" id="bbtn2" >Histories</a>
';
}
if(current_user_can("vtupress_access_users")){
	echo'
<a href="#users" role="button" id="bbtn3" class="btn btn-primary" > Users </a>
';
}
if(current_user_can("vtupress_access_withdrawal")){
	echo'
<a href="#withdrawal" role="button" id="bbtn5" class="btn btn-primary" > Withdrawals </a>
';
}
if(current_user_can("vtupress_access_mlm")){
	echo'
<a href="#mlm" role="button" id="bbtn4" class="btn btn-primary" >MLM </a>
';
}
if(current_user_can("vtupress_access_push")){
	echo'
<a href="#push" role="button" id="bbtn6" class="btn btn-primary" >PUSH </a>
';
}
echo'
</div>

';

if(current_user_can("vtupress_access_push")){
echo "
<div class='push' id='push'>";
if (version_compare(phpversion(), '7.4.0') >= 0 && version_compare(phpversion(), '8.0.0') == -1) {
	
$apikey = vp_getoption("server_apikey");
$authdomain = vp_getoption("server_authdomain");
$project = vp_getoption("server_project");
$sender = vp_getoption("server_sender");
$gcm = vp_getoption("server_gcm");
$ena = vp_getoption("fcm");
$url = esc_url(plugins_url('vtupress/message.php'));

$display = <<<HERE
<div class="container">

<div class="alert alert-primary mb-2" role="alert">
<b>NOTE:</b><br>
This section is a vital section. 
If you are not techy or know nothing about Firebase, Kindly desist or watch any youtube video on FCM(Firebase Cloud Messaging).
<br>
Some message may be sent to a user if they did not allow notification, If browser or phone blocks notification and other devices probs' may cause message failure.
</div>

<div class="mb-2 mt-2>

<div class="input-group mb-2">
<span class="input-group-text">ENABLE FCM PUSH</span>
<select class="fcm_enable form-control">
<option value="$ena">$ena</option>
<option value="yes">YES</option>
<option value="no">NO</option>
</select>
</div>

<div class="input-group">
<span class="input-group-text">APIKey</span>
<input class="form-control apikey" type="password" value="$apikey">
<span class="input-group-text view_api">View</span>
<script>
jQuery('.view_api').on('click', function(){
      var passInput = jQuery(".apikey");
      if(passInput.attr('type')==='password'){
          passInput.attr('type','text');
      }else{
         passInput.attr('type','password');
      }
});
</script>
</div>

<div class="input-group">
<span class="input-group-text">AuthDomain</span>
<input class="form-control authdomain" value="$authdomain">
</div>

<div class="input-group">
<span class="input-group-text">Project ID</span>
<input class="form-control project" value="$project">
</div>

<div class="input-group">
<span class="input-group-text">Messaging Sender ID</span>
<input class="form-control sender_id" type="password" value="$sender">
<span class="input-group-text view_sender">View</span>
<script>
jQuery('.view_sender').on('click', function(){
      var passInput = jQuery(".sender_id");
      if(passInput.attr('type')==='password'){
          passInput.attr('type','text');
      }else{
         passInput.attr('type','password');
      }
});
</script>
</div>

<div class="input-group">
<span class="input-group-text">Gcm Sender ID</span>
<input class="form-control gcm" type="password" value="$gcm">
<span class="input-group-text view_gcm">View</span>
<script>
jQuery('.view_gcm').on('click', function(){
      var passInput = jQuery(".gcm");
      if(passInput.attr('type')==='password'){
          passInput.attr('type','text');
      }else{
         passInput.attr('type','password');
      }
});
</script>
</div>

<button class="mt-3 create_fcm btn btn-primary">[RE]GENERATE FILE</button>



<script>

jQuery(".create_fcm").on("click",function(){
	jQuery("#cover-spin").show();

var obj = {};
obj["fcm_generate"] = "gen";
obj["apikey"] = jQuery(".apikey").val();
obj["authdomain"] = jQuery(".authdomain").val();
obj["project"] = jQuery(".project").val();
obj["sender"] = jQuery(".sender_id").val();
obj["gcm"] = jQuery(".gcm").val();
jQuery.ajax({
  url: '$url',
  data: obj,
 dataType: 'text',
  'cache': false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data) {
	  jQuery("#cover-spin").hide();
        if(data == "100"){
		  swal({
  title: "Successful",
  text: "FCM FILES CREATED",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Failed",
  text: "Click \'Why\' To See reason",
  icon: "error",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
      break;
    default:
      swal(data, {
      icon: "info",
    });
  }
});
	  }
  },
  type: 'POST'
});
});

jQuery(".fcm_enable").on("change",function(){
	jQuery("#cover-spin").show();
	var val = jQuery(".fcm_enable").val();
var obj = {};
obj["fcm_enable"] = val;
jQuery.ajax({
  url: '$url',
  data: obj,
 dataType: 'text',
  'cache': false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data) {
	  jQuery("#cover-spin").hide();
        if(data == "100"){
		  swal({
  title: "Successful",
  text: "FCM ENABLED",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Failed",
  text: "Click \'Why\' To See reason",
  icon: "error",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
      break;
    default:
      swal(data, {
      icon: "info",
    });
  }
});
	  }
  },
  type: 'POST'
});
});


</script>
</div>

</div>

HERE;

echo $display;
}
else{
?>
<div class="alert alert-primary mb-2" role="alert">
<b>PHP VERSION ERROR:</b><br>
PHP Version must be at least 7.4 but not up to 8.0. Your current version is <?php echo phpversion();?>.
<br>
<b>Contact Your Hosting Company For A Fix Or Solve The Issue From Cpanel</b>
</div>
<?php
}
echo "

<br><br>

</div>

";

}

if(current_user_can("vtupress_access_general")){
echo "
<!-- BBTN -- [ID - VTU] -- [CLASS -- VTUACCOUNT] -->

<div class='vtuaccount'>

General Settings
<br>";

global $wpdb;
$choice = 'custom';
$choice_name = $wpdb->prefix.'vtuchoice';
$wpdb->update($choice_name, array(
'vtuchoice' => $choice
), array( 'id' => 1));
if (version_compare(phpversion(), '7.4.0') >= 0 && version_compare(phpversion(), '8.0.0') == -1) {
general();
}
else{
?>
<div class="alert alert-primary mb-2" role="alert">
<b>PHP VERSION ERROR:</b><br>
PHP Version must be at least 7.4 but not up to 8.0. Your current version is <?php echo phpversion();?>.
<br>
<b>Contact Your Hosting Company For A Fix Or Solve The Issue From Cpanel</b>
</div>
<?php
}
echo "

</div>

<!-- END [ VTUACCOUNT] -->
";
}

if(current_user_can("vtupress_access_payment")){
//Flutterwave
echo "

<!-- BBTN1 -- [ID - FLT] -- [CLASS -- FLUTTERWAVE] -->

<div class='flutterwave' id='flt'>

<button class='btn btn-primary payment_gateway'>PAYMENT GATEWAY</button>
";
if(vp_getoption("resell") == "yes"){
	echo"
<button class='btn btn-primary airtime_gateway'>AIRTIME CONVERSION</button>
<button class='btn btn-primary coupon_gateway'>COUPON</button> 
";
}
echo"

<div class='payment_gateway'>
settings page for your Preferred Payment Gateway<br>";
global $wpdb;
$fltable_name = $wpdb->prefix.'flutterwave';
$flresults =$wpdb->get_row("SELECT * FROM $fltable_name WHERE ID = 1");
$fp = $flresults->public_key; 
$fs = $flresults->secret_key;

echo "
<form method='post' target='_SELF' class='updatefl'>
<div class='mb-3'>
<label for='publickey' class='form-label'>Flutterwave Public Key</label><br>
<input type='text' class='form-control' name='public'value='".$fp."'><br>
<label for='secretkey' class='form-label'>Flutterwave SecretKey</label><br>
<input type='text' class='form-control' name='secret' value='".$fs."'><br>
</div>

<div class='mb-3'>
<label for='ppublickey' class='form-label'>PayStack Public Key</label><br>
<input type='text' class='form-control' name='ppublic'value='".vp_getoption('ppub')."'><br>
<label for='secretkey'>PayStack SecretKey</label><br>
<input type='text' class='form-control' name='psecret' value='".vp_getoption('psec')."'><br>
</div>

<div class='mb-3'>
<label for='ppublickey' class='form-label'>Monnify Api Key</label><br>
<input type='text' class='form-control' name='mapi'value='".vp_getoption('monnifyapikey')."'><br>

<label for='psecretkey' class='form-label'>Monnify Secret Key</label><br>
<input type='text' class='form-control' name='msec'value='".vp_getoption('monnifysecretkey')."'><br>

<label for='secretkey' class='form-label' >Monnify ContractCode</label><br>
<input type='text' class='form-control' name='mcontract' value='".vp_getoption('monnifycontractcode')."'><br>

<label for='secretkey' class='form-label'>Monnify Test Mode</label><br>
Please Do Not Choose 'True' To This When You Entered A Live Secret Api Key & Api Key<br>

<div class='form-group'>
<select name='monnifytest' class='form-select group-text'>
<option value='".vp_getoption('monnifytestmode')."'>".vp_getoption('monnifytestmode')."</option>
<option value='true'>True</option>
<option value='false'>False</option>
</select>
";

if(vp_getoption('monnifytestmode') == "false" && (empty(stripos(vp_getoption('monnifyapikey'),"test")) || stripos(vp_getoption('monnifyapikey'),"test") === false ) && vp_getoption("paychoice") == "monnify"){
	echo"
<input type='button' class='group-text run-dan btn btn-primary' value='Run Dedicated Account Number'>
";
}
?>
<script>
jQuery(".run-dan").click(function(){

jQuery("#cover-spin").show();
	
var obj = {};
obj["rundan"] = "run";
jQuery.ajax({
  url: '<?php echo esc_url(plugins_url('vtupress/rundan.php'));?>',
  data: obj,
 dataType: 'text',
  'cache': false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  
  success: function(data) {
	  jQuery("#cover-spin").hide();
        if(data == "100"){
		  swal({
  title: "Successful",
  text: "Users Without A DAN Has Successfully Goten A Virtual Account Number",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		 jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Failed",
  text: "Click \'Why\' To See reason",
  icon: "error",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
      break;
    default:
      swal(data, {
      icon: "info",
    });
  }
});
	  }
  },
  type: 'POST'
});

});
 
</script>
<?php
echo"
</div>

</div>

<div class='mb-3'>
<label>Select Your Prefered Payment Gateway</label>
<select name='paychoice' class='form-select' >
<option value='".vp_getoption('paychoice')."'>".vp_getoption('paychoice')."</option>
<option value='paystack'>PayStack</option>
<option value='flutterwave'>FlutterWave</option>
<option value='monnify'>Monnify</option>
</select>
</div>


<div class='mb-3'>
<label>Allow Card Funding Payment Method [Only Monnify Users Should Use This]</label>
<select name='allow_card_method' class='form-select' >
<option value='".vp_getoption('allow_card_method')."'>".vp_getoption('allow_card_method')."</option>
<option value='yes'>YES</option>
<option value='no'>No</option>
</select>
</div>

<div class='input-group mb-3'>
<span class='input-group-text'>Webhook</span>
<input type='text' name='webhook' value='".vp_getoption('siteurl')."/wp-content/plugins/vtupress/index.php' readOnly>
</select>
</div>

";


echo '
<input type="button" name="updatefl" value="Save" class="btn btn-primary updatef2">
</form>
</div>
<!--End of Payment Gateway-->

<div class="airtime_gateway update1">
<form method="post">
<div class="enable_conversion mb-2">
<label class="form-label">Enable Conversions</label><br>
<div class="input-group">
<span class="input-group-text">Enable Airtime To Wallet</span>
<select class="airtime_to_wallet" name="airtime_to_wallet">
<option value="'.vp_getoption("airtime_to_wallet").'">'.vp_getoption("airtime_to_wallet").'</option>
<option value="yes">YES</option>
<option value="no">NO</option>
</select>
</div>

<div class="input-group">
<span class="input-group-text">Enable Airtime To Cash [Manual]</span>
<select class="airtime_to_cash" name="airtime_to_cash">
<option value="'.vp_getoption("airtime_to_cash").'">'.vp_getoption("airtime_to_cash").'</option>
<option value="yes">YES</option>
<option value="no">NO</option>
</select>
</div>
</div>
<!-- End of Conversion -->

<div class="to_pay_to md-2">
<label class="form-label">Enter Numbers To Pay To</label>
<div class="input-group">
<span class="input-group-text">MTN</span>
<input class="form-control mtn_airtime" type="number" name="mtn_airtime" value="'.vp_getoption("mtn_airtime").'">
</div>

<div class="input-group">
<span class="input-group-text">GLO</span>
<input class="form-control glo_airtime" type="number" name="glo_airtime" value="'.vp_getoption("glo_airtime").'">
</div>

<div class="input-group">
<span class="input-group-text">AIRTEL</span>
<input class="form-control airtel_airtime" type="number" name="airtel_airtime" value="'.vp_getoption("airtel_airtime").'">
</div>

<div class="input-group">
<span class="input-group-text">9MOBILE</span>
<input class="form-control 9mobile_airtime" type="number" name="9mobile_airtime" value="'.vp_getoption("9mobile_airtime").'">
</div>
</div>
<!--End Of Numbers To Pay To-->

<div class="conversion_charge mt-2 mb-2">
<label class="form-label">MTN Charges</label>
<div class="input-group">
<span class="input-group-text">Airtime To Wallet</span>
<input type="number" class="airtime_to_wallet_charge" value="'.vp_getoption("airtime_to_wallet_charge").'" name="airtime_to_wallet_charge">
<span class="input-group-text">%</span>
<span class="input-group-text">Airtime To Cash</span>
<input type="number" class="airtime_to_cash_charge" value="'.vp_getoption("airtime_to_cash_charge").'" name="airtime_to_cash_charge">
<span class="input-group-text">%</span>
</div>
</div>


<div class="conversion_charge mt-2 mb-2">
<label class="form-label">GLO Charges</label>
<div class="input-group">
<span class="input-group-text">Airtime To Wallet</span>
<input type="number" class="gairtime_to_wallet_charge" value="'.vp_getoption("gairtime_to_wallet_charge").'" name="gairtime_to_wallet_charge">
<span class="input-group-text">%</span>
<span class="input-group-text">Airtime To Cash</span>
<input type="number" class="gairtime_to_cash_charge" value="'.vp_getoption("gairtime_to_cash_charge").'" name="gairtime_to_cash_charge">
<span class="input-group-text">%</span>
</div>
</div>

<div class="conversion_charge mt-2 mb-2">
<label class="form-label">AIRTEL Charges</label>
<div class="input-group">
<span class="input-group-text">Airtime To Wallet</span>
<input type="number" class="aairtime_to_wallet_charge" value="'.vp_getoption("aairtime_to_wallet_charge").'" name="aairtime_to_wallet_charge">
<span class="input-group-text">%</span>
<span class="input-group-text">Airtime To Cash</span>
<input type="number" class="aairtime_to_cash_charge" value="'.vp_getoption("aairtime_to_cash_charge").'" name="aairtime_to_cash_charge">
<span class="input-group-text">%</span>
</div>
</div>

<div class="conversion_charge mt-2 mb-2">
<label class="form-label">9MOBILE Charges</label>
<div class="input-group">
<span class="input-group-text">Airtime To Wallet</span>
<input type="number" class="9airtime_to_wallet_charge" value="'.vp_getoption("9airtime_to_wallet_charge").'" name="9airtime_to_wallet_charge">
<span class="input-group-text">%</span>
<span class="input-group-text">Airtime To Cash</span>
<input type="number" class="9airtime_to_cash_charge" value="'.vp_getoption("9airtime_to_cash_charge").'" name="9airtime_to_cash_charge">
<span class="input-group-text">%</span>
</div>
</div>

<input type="button" name="update1" value="Save Coversion" class="btn btn-primary update22">
</form>
</div>
<!-- End Of Airtime Conversion-->

<div class="coupon_div">


<div class="input-group mb-2 mt-2">
<span class="input-group-text">Enable Coupon System</span>
<select name="enable_coupon" class="enable_coupon">
<option value="'.vp_getoption("enable_coupon").'">'.vp_getoption("enable_coupon").'</option>
<option value="yes">YES</option>
<option value="no">NO</option>
</select>

<script>
jQuery("select.enable_coupon").on("change",function(){
jQuery("#cover-spin").show();

var change = jQuery("select.enable_coupon").val();

var obj = {};

obj["enable_coupon"] = jQuery("select.enable_coupon").val();
jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/coupon.php')).'",
  data: obj,
  dataType: "text",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data == "100" ){
	
		  swal({
  title: "SAVED",
  text: "Coupon set to "+change,
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	 else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error",
  text: data,
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

	
});

</script>
</div>

<div class="coupon_form mb-2 mt-2">
<div class="input-group">
<span class="input-group-text">CODE</span>
<input class="form-control coupon_code" type="text" name="">
<span class="input-group-text">Applicable To [USER IDS]</span>
<input class="applicable_to form-control" type="text" name="">
<span class="input-group-text">Amount</span>
<input class="form-control coupon_amount">

<input type="button" class="btn btn-success form-control coupon_generate1" value="Generate">
</div>
<script>
jQuery(".applicable_to").on("click",function(){
	alert("Separate each User Id\'s by comma [,]");
});
jQuery("input.coupon_generate1").on("click",function(){
jQuery("#cover-spin").show();
var obj = {};

obj["coupon_generate"] = "update";
obj["coupon_code"] = jQuery(".coupon_code").val();
obj["applicable_to"] = jQuery(".applicable_to").val();
obj["coupon_amount"] = jQuery(".coupon_amount").val();

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/coupon.php')).'",
  data: obj,
  dataType: "text",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data == "100" ){
	
		  swal({
  title: "SUCCESS",
  text: "Coupon Generated",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	 else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error",
  text: data,
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});

</script>
</div>
<!-- End of form group -->
';
global $wpdb;
$table_name = $wpdb->prefix.'vp_coupon';
$results = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY ID DESC");
 
echo"
<table class='table table-striped table-hover table-bordered table-responsive'>
<thead>
<tr>
<th scope='col'>Id</th>
<th scope='col'>Code</th>
<th scope='col'>Applicable To [ID's]</th>
<th scope='col'>Used By [ID's]</th>
<th scope='col'>Amount</th>
<th scope='col'>Status</th>
<th scope='col'>Action</th>
</tr>
</thead>
";
foreach($results as $coupon){
$id = $coupon->id;
$code = $coupon->code;
$app = $coupon->applicable_to;
$used = $coupon->used_by;
$status = $coupon->status;
$amount = $coupon->amount;
echo"

<tr>
<td scope='col'>$id</td>
<td scope='col'>$code</td>
<td scope='col'>$app</td>
<td scope='col'>$used</td>
<td scope='col'>$amount</td>
<td scope='col'>$status</td>
<td scope='col'>
<select class='set_coupon_status_to$id'>
<option value='none'>--Select--</option>
<option value='close'>CLOSE</option>
<option value='open'>OPEN</option>
<option value='delete'>DELETE</option>
<option value='edit'>Edit Users ID</option>
</select>


<script>
jQuery('.set_coupon_status_to$id').on('change',function(){
	
var edit_value = jQuery('.set_coupon_status_to$id').val();
switch(edit_value){
	case'close':
	if(confirm('Want To Close This Coupon?') == true){
	";
echo'
  jQuery("#cover-spin").show();
obj["coupon_close_edit"] = "close";
obj["coupon_id"] = "'.$id.'";

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/coupon.php')).'",
  data: obj,
  dataType: "text",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data == "100" ){
	
		  swal({
  title: "CLOSED",
  text: "Coupon Closed Successfully",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	 else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error",
  text: data,
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

';

echo"	
	}
	break;
	case'open':
		if(confirm('Want To Open This Coupon?') == true){
	";
echo'
  jQuery("#cover-spin").show();
obj["coupon_open_edit"] = "close";
obj["coupon_id"] = "'.$id.'";

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/coupon.php')).'",
  data: obj,
  dataType: "text",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data == "100" ){
	
		  swal({
  title: "OPENED",
  text: "Coupon Opened Successfully",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	 else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error",
  text: data,
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

';

echo"	
	}
	break;
	case'delete':
			if(confirm('Want To Delete This Coupon?') == true){
	";
echo'
  jQuery("#cover-spin").show();
obj["coupon_delete_edit"] = "close";
obj["coupon_id"] = "'.$id.'";

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/coupon.php')).'",
  data: obj,
  dataType: "text",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data == "100" ){
	
		  swal({
  title: "DELETED",
  text: "Coupon Deleted Successfully",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	 else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error",
  text: data,
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

';

echo"	
	}
	break;
	case'edit':
	let ids = prompt('EDIT USERS ID', '$app');

if (ids != null && ids != '$app') {
	
	";
echo'
  jQuery("#cover-spin").show();
obj["coupon_edit"] = "edit";
obj["coupon_user_edit"] = ids;
obj["coupon_id"] = "'.$id.'";

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/coupon.php')).'",
  data: obj,
  dataType: "text",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data == "100" ){
	
		  swal({
  title: "EDITED",
  text: "Coupon Users Editted",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	 else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error",
  text: data,
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

';

echo"	
}
	break;
	
	
}

});
</script>

</td>
</tr>
";	
	
	
}

echo'
</table>
</div>
<!-- END OF COUPON DIV-->


<script>


jQuery(".update22").on("click",function(){
	jQuery("#cover-spin").show();
var obj = {};

obj["update1"] = "update";
obj["airtime_to_cash"] = jQuery(".airtime_to_cash").val();
obj["airtime_to_wallet"] = jQuery(".airtime_to_wallet").val();
obj["mtn_airtime"] = jQuery(".mtn_airtime").val();
obj["glo_airtime"] = jQuery(".glo_airtime").val();
obj["airtel_airtime"] = jQuery(".airtel_airtime").val();
obj["9mobile_airtime"] = jQuery(".9mobile_airtime").val();
obj["airtime_to_wallet_charge"] = jQuery(".airtime_to_wallet_charge").val();
obj["9airtime_to_wallet_charge"] = jQuery(".9airtime_to_wallet_charge").val();
obj["aairtime_to_wallet_charge"] = jQuery(".aairtime_to_wallet_charge").val();
obj["gairtime_to_wallet_charge"] = jQuery(".gairtime_to_wallet_charge").val();
obj["airtime_to_cash_charge"] = jQuery(".airtime_to_cash_charge").val();
obj["aairtime_to_cash_charge"] = jQuery(".aairtime_to_cash_charge").val();
obj["9airtime_to_cash_charge"] = jQuery(".9airtime_to_cash_charge").val();
obj["gairtime_to_cash_charge"] = jQuery(".gairtime_to_cash_charge").val();

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/atc.php')).'",
  data: obj,
  dataType: "text",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data == "100" ){
	
		  swal({
  title: "SAVED",
  text: "Update Completed",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	 else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error",
  text: data,
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});

jQuery(".updatef2").on("click",function(){
	jQuery("#cover-spin").show();
var obj = {};
var toatl_input = jQuery(".updatefl input, .updatefl select, .updatefl textarea").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".updatefl input, .updatefl select, .updatefl textarea").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}
	
	
}

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/vend.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection. Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error." + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){
	
		  swal({
  title: "SAVED",
  text: "Update Completed",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error",
  text: "Saving Wasn\"t Successful",
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});


</script>


</div>

<!-- END [CLASS -- FLUTTERWAVE] -->

';
}


if(current_user_can("vtupress_access_history")){
echo "
<div class='productid' id='prd'>";
if (version_compare(phpversion(), '7.4.0') >= 0 && version_compare(phpversion(), '8.0.0') == -1) {
transactions();
}
else{
?>
<div class="alert alert-primary mb-2" role="alert">
<b>PHP VERSION ERROR:</b><br>
PHP Version must be at least 7.4 but not up to 8.0. Your current version is <?php echo phpversion();?>.
<br>
<b>Contact Your Hosting Company For A Fix Or Solve The Issue From Cpanel</b>
</div>
<?php
}
echo "

<br><br>

</div>

";

}


if(current_user_can("vtupress_access_users")){
//for vdatset
echo "<div class='vdatset' id='vdatset'>";
if (version_compare(phpversion(), '7.4.0') >= 0 && version_compare(phpversion(), '8.0.0') == -1) {
vpusers();
}
else{
?>
<div class="alert alert-primary mb-2" role="alert">
<b>PHP VERSION ERROR:</b><br>
PHP Version must be at least 7.4 but not up to 8.0. Your current version is <?php echo phpversion();?>.
<br>
<b>Contact Your Hosting Company For A Fix Or Solve The Issue From Cpanel</b>
</div>
<?php
}

echo "

<br><br>
</div>
";
}

if(current_user_can("vtupress_access_withdrawal")){
echo"

<div class='withs' id='withs'>
";
if (version_compare(phpversion(), '7.4.0') >= 0 && version_compare(phpversion(), '8.0.0') == -1) {
withdrawals();
}
else{
?>
<div class="alert alert-primary mb-2" role="alert">
<b>PHP VERSION ERROR:</b><br>
PHP Version must be at least 7.4 but not up to 8.0. Your current version is <?php echo phpversion();?>.
<br>
<b>Contact Your Hosting Company For A Fix Or Solve The Issue From Cpanel</b>
</div>
<?php
}
echo"
</div>
";
}


if(current_user_can("vtupress_access_mlm")){
//for vdatset
echo "<div class='mdatset' id='mdatset'>";
if (version_compare(phpversion(), '7.4.0') >= 0 && version_compare(phpversion(), '8.0.0') == -1) {
if(is_plugin_active("vpmlm/vpmlm.php")){
include_once(ABSPATH .'wp-content/plugins/vpmlm/vpmlm.php');
mlm_set();
}
else{

  echo"
  <h5>You Need To Be Premium User and VP MLM Installed</h5>
  ";
}
}
else{
?>
<div class="alert alert-primary mb-2" role="alert">
<b>PHP VERSION ERROR:</b><br>
PHP Version must be at least 7.4 but not up to 8.0. Your current version is <?php echo phpversion();?>.
<br>
<b>Contact Your Hosting Company For A Fix Or Solve The Issue From Cpanel</b>
</div>
<?php
}
echo '

<br><br>
</div>
';
}

echo'

<script>
jQuery("div.airtime_gateway").hide();
jQuery("div.coupon_div").hide();

jQuery("#withs").hide();
  var hash = jQuery(location).prop("hash").substr(1);
  if(hash  == "general"){
jQuery(".vtuaccount").show();
jQuery("#flt").hide();
jQuery("#prd").hide();
jQuery("#vdatset").hide();
jQuery("#mdatset").hide();
jQuery("#withs").hide();
jQuery("#push").hide();
  }

 else if(hash  == "gateway"){
    jQuery(".vtuaccount").hide();
    jQuery("#flt").show();
    jQuery("#prd").hide();
    jQuery("#vdatset").hide();
    jQuery("#mdatset").hide();
	jQuery("#withs").hide();
	jQuery("#push").hide();
  }
  
 else if(hash  == "transactions"){
    jQuery(".vtuaccount").hide();
    jQuery("#flt").hide();
    jQuery("#prd").show();
    jQuery("#vdatset").hide();
    jQuery("#mdatset").hide();
	jQuery("#withs").hide();
	jQuery("#push").hide();
  }

 else if(hash  == "users"){
    jQuery(".vtuaccount").hide();
    jQuery("#flt").hide();
    jQuery("#prd").hide();
    jQuery("#vdatset").show();
    jQuery("#mdatset").hide();
	jQuery("#withs").hide();
	jQuery("#push").hide();
  }

 else if(hash  == "mlm"){
    jQuery(".vtuaccount").hide();
    jQuery("#flt").hide();
    jQuery("#prd").hide();
    jQuery("#vdatset").hide();
    jQuery("#mdatset").show();
	jQuery("#withs").hide();
	jQuery("#push").hide();
  }
  else if(hash  == "withdrawal"){
    jQuery(".vtuaccount").hide();
    jQuery("#flt").hide();
    jQuery("#prd").hide();
    jQuery("#vdatset").hide();
    jQuery("#mdatset").hide();
	jQuery("#withs").show();
	jQuery("#push").hide();
  }
    else if(hash  == "push"){
    jQuery(".vtuaccount").hide();
    jQuery("#flt").hide();
    jQuery("#prd").hide();
    jQuery("#vdatset").hide();
    jQuery("#mdatset").hide();
	jQuery("#withs").hide();
	jQuery("#push").show();
  }

  else{
    jQuery(".vtuaccount").show();
    jQuery("#flt").hide();
    jQuery("#prd").hide();
    jQuery("#vdatset").hide();
    jQuery("#mdatset").hide();
	jQuery("#withs").hide();
	jQuery("#push").hide();
  }


jQuery("#bbtn").on("click", function(){
  jQuery(".vtuaccount").show();
  jQuery("#flt").hide();
  jQuery("#prd").hide();
  jQuery("#vdatset").hide();
  jQuery("#mdatset").hide();
  jQuery("#withs").hide();
  jQuery("#push").hide();
});


  jQuery("#bbtn1").on("click", function(){
    jQuery(".vtuaccount").hide();
    jQuery(".flutterwave").show();
    jQuery("div.airtime_gateway").hide();
    jQuery("div.payment_gateway").show();
    jQuery("#prd").hide();
    jQuery("#vdatset").hide();
    jQuery("#mdatset").hide();
	jQuery("#withs").hide();
	jQuery("#push").hide();
  });

    jQuery("#bbtn2").on("click", function(){
      jQuery(".vtuaccount").hide();
      jQuery("#flt").hide();
      jQuery("#prd").show();
      jQuery("#vdatset").hide();
      jQuery("#mdatset").hide();
	  jQuery("#withs").hide();
	  jQuery("#push").hide();
    });
 
      jQuery("#bbtn3").on("click", function(){
        jQuery(".vtuaccount").hide();
        jQuery("#flt").hide();
        jQuery("#prd").hide();
        jQuery("#vdatset").show();
        jQuery("#mdatset").hide();
		jQuery("#withs").hide();
		jQuery("#push").hide();
      });

        jQuery("#bbtn4").on("click", function(){
          jQuery(".vtuaccount").hide();
          jQuery("#flt").hide();
          jQuery("#prd").hide();
          jQuery("#vdatset").hide();
          jQuery("#mdatset").show();
          jQuery("#withs").hide();
		  jQuery("#push").hide();
          });
		  
		 jQuery("#bbtn5").on("click", function(){
          jQuery(".vtuaccount").hide();
          jQuery("#flt").hide();
          jQuery("#prd").hide();
          jQuery("#vdatset").hide();
          jQuery("#mdatset").hide();
		  jQuery("#withs").show();
		  jQuery("#push").hide();
          });
		  
		  jQuery("#bbtn6").on("click", function(){
          jQuery(".vtuaccount").hide();
          jQuery("#flt").hide();
          jQuery("#prd").hide();
          jQuery("#vdatset").hide();
          jQuery("#mdatset").hide();
		  jQuery("#withs").hide();
		  jQuery("#push").show();
          });
		  
		  
   
 jQuery("button.airtime_gateway").on("click", function(){
    jQuery("div.airtime_gateway").show();
    jQuery("div.payment_gateway").hide();
	jQuery("div.coupon_div").hide();
  });
     
 jQuery("button.payment_gateway").on("click", function(){
    jQuery("div.airtime_gateway").hide();
    jQuery("div.payment_gateway").show();
	jQuery("div.coupon_div").hide();
  });
  
  jQuery("button.coupon_gateway").on("click", function(){
    jQuery("div.airtime_gateway").hide();
    jQuery("div.payment_gateway").hide();
    jQuery("div.coupon_div").show();
  });

</script>

</div><!--DASHBOARD CONTAINER END -->
';

if(vp_getoption("vprun") == "block"){
echo '<script>
document.getElementsByTagName("button").disabled = true;
</script>
';
}
}
}
return ob_get_clean();
?>