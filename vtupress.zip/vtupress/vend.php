<?php

header("Access-Control-Allow-Origin: *");
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH ."wp-load.php");
include_once(ABSPATH.'wp-admin/includes/plugin.php');
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');

clearstatcache();
wp_cache_flush();

 extract(vtupress_user_details());
$add_total = "maybe";
global $tcode;
function sendMessage($regid,$message){
	$web_name = get_option("blogname");
global $wpdb;
$table = $wpdb->prefix."vp_message";
$rest = $wpdb->get_results("SELECT * FROM $table");

	foreach ($rest as $token) {
		if($token->user_id == $regid){
			$registrationId[] = $token->user_token;
	$header = [
		'Authorization: Key=' .vp_getoption("server_apikey"),
		'Content-Type: Application/json'
	];
$user_name = get_userdata($regid)->user_login;
	$msg = [
		'title' => "New Message From $web_name To $user_name",
		'body' => $message,
		'icon' => esc_url(plugins_url("vtupress/images/vtupress.png")),
		'image' => '',
	];

	$payload = [
		'registration_ids' 	=> $registrationId,
		'data'				=> $msg
	];

	$curl = curl_init();

	curl_setopt_array($curl, array(
	  CURLOPT_URL => "https://fcm.googleapis.com/fcm/send",
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_CUSTOMREQUEST => "POST",
	  CURLOPT_POSTFIELDS => json_encode( $payload ),
	  CURLOPT_HTTPHEADER => $header
	));

	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);

	if ($err) {
	 return "false";
	} else {
	  return "true";
	}
		}
	}

	// $tokens = ['cCLA1_8Inic:APA91bGhuCksjWEETYWVOh04scsZInxdWmXekEr5F9-1zJuTDZDw3It_tNmpA__PmoxDTISZzplD_ciXvsuw2pMtYSzdfIUAUfcTLnghvJS0CVkYW9sVx2HnF1rqnxsFgSdYmcXpHKLs'];
	

	
	
}

$vpdebug = vp_getoption("vpdebug");
$headers = array('Content-Type: text/html; charset=UTF-8');


function harray_key_first($arr) {
	$arg = json_decode($arr);
	if(is_array($arg)){
		$response  = array("him"=>"me", "them"=>"you");
        foreach($resp as $key => $value) {
            if(!is_array($value)){
                return $arr[$key];
            }else{
                return "error";
            }
        }
		
	}else{
		return $arr;
	}
        
}


function validate_response($response, $key, $value, $alter="nothing_to_find"){
    $array = array_change_key_case(json_decode($response,true),CASE_LOWER);


function search_Key($array,$key){
   $results = array();

  if (is_array($array)){
    if (isset($array[strtolower($key)])){
        $results[] =$array[strtolower($key)];
    }

    foreach ($array as $sub_array ){
        $results = array_merge($results, search_Key($sub_array, $key));
    }
  }
return array_change_key_case($results,CASE_LOWER);
}

function search_val($results, $the_value, $alt = "nothing"){
    $status = "FALSE";
    foreach($results as $dvalue){
        if(!is_array($dvalue)){
            if(strtolower($dvalue) === strtolower($the_value)){
                $status = "TRUE";
            }
            elseif(strtolower($dvalue) === strtolower( $alt)){
                 $status = "TRUE";
            }
            
        }
    }
    return $status;
}

$result = search_Key($array,$key);
//print_r($result);
$status_from_result_val = search_val($result,$value,$alter);

return $status_from_result_val;
    

}

function search_bill_token($array,$key){
   $results = array();

  if (is_array($array)){
    if (isset($array[strtolower($key)])){
        $results[] = $array[strtolower($key)];
    }

    foreach ($array as $sub_array ){
        $results = array_merge($results, search_bill_token($sub_array, $key));
    }
  }
return $results;
}


if(isset($_REQUEST["vend"])){
	//GLOBALS
global $wpdb, $level, $plan, $amount, $id, $amountv, $sec;

if(is_plugin_active("vpmlm/vpmlm.php")){
$discount_method = vp_getoption("discount_method");
}
else{
$discount_method = "null";	
}


if($_REQUEST['tcode'] == "cdat"){
$dplan = $_REQUEST['cplan'];
}

if(isset($_REQUEST['phone'])){
$phone = $_REQUEST['phone'];
}
else{
	if(empty(vp_getuser($id,"vp_phone",true))){
		$phone = "0800000001";
	}
	else{
	$phone = vp_getuser($id,"vp_phone",true);
	}
}


$uniqidvalue =  date('Ymd').(date('H')+1).date("i").date("s").uniqid("vtu-",false);

if(isset($_REQUEST['network'])){
$network = $_REQUEST['network'];
}

if(isset($_REQUEST['url'])){
$url = $_REQUEST['url'];
}
$tcode = $_REQUEST['tcode'];

if(isset($_REQUEST['id'])){
$id = $_REQUEST['id'];
}else{
$id = get_current_user_id();	
}


do_action("vppay");


$id = get_current_user_id();
$bal = vp_getuser($id, "vp_bal", true);

$tcode = $_REQUEST['tcode'];
$vpdebug = vp_getoption("vpdebug");


$name = $_REQUEST['vpname'];
$email = $_REQUEST['vpemail'];


$id = get_current_user_id();

if($_REQUEST['tcode'] == "cdat"){
$dplan = $_REQUEST['cplan'];
}

if(isset($_REQUEST['phone'])){
$phone = $_REQUEST['phone'];
}
else{
	if(empty(vp_getuser($id,"vp_phone",true))){
		$phone = "0800000001";
	}
	else{
	$phone = vp_getuser($id,"vp_phone",true);
	}
}

if(isset($_REQUEST['uniqidvalue'])){
$uniqidvalue =  date('Ymd').(date('H')+1).date("i").date("s");
}

if(isset($_REQUEST['network'])){
$network = $_REQUEST['network'];
}

if(isset($_REQUEST['url'])){
$url = $_REQUEST['url'];
}

$tcode = $_REQUEST['tcode'];

if(isset($_REQUEST['id'])){
$id = $_REQUEST['id'];
}

$id = get_current_user_id();
$bal = vp_getuser($id, "vp_bal", true);

if($_REQUEST['tcode'] == "ccab"){
$ccable = $_REQUEST["ccable"];
$iuc = $_REQUEST["iuc"];
$cabtype = $_REQUEST["cabtype"];
}
if($_REQUEST['tcode'] == "cbill"){
$cbill = $_REQUEST["cbill"];
$type = $_REQUEST["type"];
$meterno = $_REQUEST["meterno"];
$bamount = $_REQUEST["amount"];
}

$pattern = "/[-\s:]/";
$curr = current_time('mysql', 1);
$cur = preg_split($pattern, $curr);
$sca = $cur[2];

$check_bal = vp_getoption("checkbal");

if(isset($_REQUEST['datatcode'])){
$datatcode = $_REQUEST['datatcode'];
}






	if(isset($_REQUEST['tcode'])){
	$tcode = $_REQUEST['tcode'];
	}

	if(isset($_REQUEST['datatcode'])){
$datatcode = $_REQUEST['datatcode'];
	}
	
	if(isset($_REQUEST['thatnetwork'])){
$datnetwork = $_REQUEST['thatnetwork'];
	}
	
	if(isset($_REQUEST['airtimechoice'])){
$airtimechoice = $_REQUEST['airtimechoice'];
	}
	
	if(isset($_REQUEST['thisnetwork'])){	
$disnetwork = $_REQUEST['thisnetwork'];
	}
	
	
	

$id = get_current_user_id();
	
$plan = vp_getuser($id, "vr_plan", true);


$table_name = $wpdb->prefix."vp_levels";
$level = $wpdb->get_results("SELECT * FROM  $table_name WHERE name = '$plan'");

if(strtolower($plan) != "custome"  && isset($level) && isset($level[0]->total_level)){
switch($tcode){
case "cair":
if($airtimechoice == "vtu"){
switch($disnetwork){
	case"MTN":
$fir = $_REQUEST['amount'] * floatval($level[0]->mtn_vtu);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"GLO":
$fir = $_REQUEST['amount'] * floatval($level[0]->glo_vtu);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"9MOBILE":
$fir = $_REQUEST['amount'] * floatval($level[0]->mobile_vtu);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"AIRTEL":
$fir = $_REQUEST['amount'] * floatval($level[0]->airtel_vtu);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	};
}
elseif($airtimechoice == "share"){
switch($disnetwork){
	case"MTN":
$fir = $_REQUEST['amount'] * floatval($level[0]->mtn_share);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"GLO":
$fir = $_REQUEST['amount'] * floatval($level[0]->glo_share);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"9MOBILE":
$fir = $_REQUEST['amount'] * floatval($level[0]->mobile_share);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"AIRTEL":
$fir = $_REQUEST['amount'] * floatval($level[0]->airtel_share);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	};

}	
elseif($airtimechoice == "awuf"){
switch($disnetwork){
	case"MTN":
$fir = $_REQUEST['amount'] * floatval($level[0]->mtn_awuf);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"GLO":
$fir = $_REQUEST['amount'] * floatval($level[0]->glo_awuf);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"9MOBILE":
$fir = $_REQUEST['amount'] * floatval($level[0]->mobile_awuf);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"AIRTEL":
$fir = $_REQUEST['amount'] * floatval($level[0]->airtel_awuf);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	};

}	
	
break;
case "cdat":
if($datatcode == "sme"){
switch($datnetwork){
	case"MTN":
$fir = intval($_REQUEST['amount']) * floatval($level[0]->mtn_sme);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"GLO":
$fir = $_REQUEST['amount'] * floatval($level[0]->glo_sme);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"9MOBILE":
$fir = $_REQUEST['amount'] * floatval($level[0]->mobile_sme);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"AIRTEL":
$fir = $_REQUEST['amount'] * floatval($level[0]->airtel_sme);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	};

}
elseif($datatcode == "direct"){
switch($datnetwork){
	case"MTN":
$fir = $_REQUEST['amount'] * floatval($level[0]->mtn_gifting);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"GLO":
$fir = $_REQUEST['amount'] * floatval($level[0]->glo_gifting);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"9MOBILE":
$fir = $_REQUEST['amount'] * floatval($level[0]->mobile_gifting);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"AIRTEL":
$fir = $_REQUEST['amount'] * floatval($level[0]->airtel_gifting);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	};

}
elseif($datatcode == "corporate"){
switch($datnetwork){
	case"MTN":
$fir = $_REQUEST['amount'] * floatval($level[0]->mtn_corporate);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"GLO":
$fir = $_REQUEST['amount'] * floatval($level[0]->glo_corporate);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"9MOBILE":
$fir = $_REQUEST['amount'] * floatval($level[0]->mobile_corporate);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	case"AIRTEL":
$fir = $_REQUEST['amount'] * floatval($level[0]->airtel_corporate);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
	break;
	};

}
break;
case "ccab":
$fir = $_REQUEST['amount'] * floatval($level[0]->cable);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
break;
case "cbill":
$fir = $_REQUEST['amount'] * floatval($level[0]->bill_prepaid);
$sec = $fir / 100;
$amountv = $_REQUEST['amount'] - $sec;
$baln =  $bal - $_REQUEST['amount'];
break;
case "cepin":
$amountv = $_REQUEST['amount'];
break;
case "csms":
$amountv = $_REQUEST['amount'];
$baln =  $bal - $_REQUEST['amount'];
break;

}
	}
	else{
	$baln =  $bal - $_REQUEST['amount'];
	$amountv = $_REQUEST['amount'];
		
	}

if($discount_method == "direct"){
	$amount = $amountv;
	$baln =  $bal - $amountv;
}
else{
	$amount = $_REQUEST['amount'];
}


//run kyc
if(vp_option_array($option_array,"resell") == "yes" && isset($kyc_data)){
	if(strtolower($kyc_data[0]->enable) == "yes"){
		
		if($kyc_status != "verified"){
####################################################################
$tb4 = $kyc_total;
$tnow = $amount;
$limitT = $kyc_data[0]->kyc_limit;
$datenow = date("Y-m-d"); #date('Y-m-d',strtotime($date." +3 days"));
$next_end_date = $kyc_end;

if(strtolower($kyc_data[0]->duration) == "total"){
	if((intval($tb4) + intval($tnow)) <= $limitT){
		
		$add_total = "yes";
	//vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
	}
	else{
		die("Verify Account To Perform This Transaction");
	}
}
else{
if($tnow < $limitT){ // check if now is less than b4
	if((intval($tnow) + intval($tb4)) <= intval($limitT)){ //check now plus  and if duration is total den allow once and not do the following cal
		if($datenow < $next_end_date || $next_end_date == "0" || empty($next_end_date)){ //check if current date is less than next or if next is zero
			//echo "Permit Transaction \n";
			//echo "Set tb4 to tnow + tb4";
			//vp_updateuser($id,"vp_kyc_total",($tb4+$tnow));
			$add_total = "yes";
			if($next_end_date == "0" || empty($next_end_date)){
				//echo "set next_end_date to datenow + limit";
				
				if(strtolower($kyc_data[0]->duration) == "day"){
				vp_updateuser($id,"vp_kyc_end",date('Y-m-d',strtotime($datenow." +1 days")));
								vp_updateuser($id,'vp_kyc_total',"0");
				}
				elseif(strtolower($kyc_data[0]->duration) == "month"){
				vp_updateuser($id,"vp_kyc_end",date('Y-m-d',strtotime($datenow." +1 month")));
								vp_updateuser($id,'vp_kyc_total',"0");
				}
				else{
					die("KYC DURATION ERROR");
				}
			}
		}
		elseif($datenow >= $next_end_date){
			if(strtolower($kyc_data[0]->duration) == "day"){
				vp_updateuser($id,"vp_kyc_end",date('Y-m-d',strtotime($datenow." +1 days")));
								vp_updateuser($id,'vp_kyc_total',"0");
				}
				elseif(strtolower($kyc_data[0]->duration) == "month"){
				vp_updateuser($id,"vp_kyc_end",date('Y-m-d',strtotime($datenow." +1 month")));
								vp_updateuser($id,'vp_kyc_total',"0");
				}
				else{
					die("KYC DURATION ERROR");
				}
			//echo "Permit Transaction";
		}
	}
	elseif(($tnow + $tb4) > $limitT){
		
		if($datenow < $next_end_date ){
			
			die("Verify Your Account To Proceed With This Transaction");
		}
		elseif($datenow >= $next_end_date){
			
			if(strtolower($kyc_data[0]->duration) == "day"){
				vp_updateuser($id,"vp_kyc_end",date('Y-m-d',strtotime($datenow." +1 days")));
								vp_updateuser($id,'vp_kyc_total',"0");
				}
				elseif(strtolower($kyc_data[0]->duration) == "month"){
				vp_updateuser($id,"vp_kyc_end",date('Y-m-d',strtotime($datenow." +1 month")));
								vp_updateuser($id,'vp_kyc_total',"0");
				}
				else{
					die("KYC DURATION ERROR");
				}
			
		}
		
	}
}
else{
	die( "verify Account To Perform This Transaction");
}

		}

#########################
		}
	}
}

$id = get_current_user_id();

$balreg = preg_match("/[^0-9\.]/",$bal);
$amountreg = preg_match("/[^0-9\.]/",$amount);
$pin = sanitize_text_field($_REQUEST["pin"]);
$mypin = sanitize_text_field(vp_getuser($id,"vp_pin",true));

$agent = $_SERVER["HTTP_USER_AGENT"];
if( preg_match('/MSIE (\d+\.\d+);/', $agent) ) {
 // echo "You're using Internet Explorer";
 $browser = "IE";
} 
else if (preg_match('/Chrome[\/\s](\d+\.\d+)/', $agent) ) {
//  echo "You're using Chrome";
 $browser = "CHROME";
} 
else if (preg_match('/Edge\/\d+/', $agent) ) {
//  echo "You're using Edge";
 $browser = "EDGE";
} 
else if ( preg_match('/Firefox[\/\s](\d+\.\d+)/', $agent) ) {
//  echo "You're using Firefox";
 $browser = "FIREFOX";
} 
else if ( preg_match('/OPR[\/\s](\d+\.\d+)/', $agent) ) {
//  echo "You're using Opera";
 $browser = "OPERA";
} 
else if (preg_match('/Safari[\/\s](\d+\.\d+)/', $agent) ) {
//  echo "You're using Safari";
 $browser = "SAFARI";
}

if($browser != "none"){
if($pin == $mypin){

if($balreg === 0 && $amountreg === 0){
	if($amount >= 50 && $_REQUEST['amount'] >= 50 || $_REQUEST['tcode'] == "csms"){
if($bal >= $amount && stripos($_REQUEST['amount'],"-") === false ){
		
if(is_plugin_active("vpmlm/vpmlm.php")){
$id = get_current_user_id();
do_action("vp_mlm");

}

switch ($tcode){
case "cair":

$airtimechoice = $_REQUEST['airtimechoice'];
if($airtimechoice == "vtu"){
$vpdebug = vp_getoption("vpdebug");
if(vp_getoption("airtimerequest") == "get"){
	
$http_args = array(
'headers' => array(
'cache-control' => 'no-cache',
'Content-Type' => 'application/json'
),
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false
);
	
	
$urlraw = htmlspecialchars_decode($_REQUEST["url"]);
$base = str_replace("vtubase",vp_option_array($option_array,"airtimebaseurl"),$urlraw);
$postdata1 = str_replace("vtupostdata1",vp_option_array($option_array,"airtimepostdata1"),$base);
$postvalue1 = str_replace("vtupostvalue1",vp_option_array($option_array,"airtimepostvalue1"),$postdata1);
$postdata2 = str_replace("vtupostdata2",vp_option_array($option_array,"airtimepostdata2"),$postvalue1);
$postvalue2 = str_replace("vtupostvalue2",vp_option_array($option_array,"airtimepostvalue2"),$postdata2);
$url = $postvalue2;
$sc = vp_getoption("airtimesuccesscode");

$call =  wp_remote_get($url, $http_args);
$response = wp_remote_retrieve_body($call);


if(is_wp_error( $call )){
$error = $call->get_error_message();
die('{"status":"200","response":"'.$error.'"}');
}
else{
if(vp_getoption("airtime1_response_format") == "JSON" || vp_getoption("airtime1_response_format") == "json"){
$en = validate_response($response,$sc, vp_getoption("airtimesuccessvalue"), vp_getoption("airtimesuccessvalue2"));
}
else{
$en = $response ;
}
}
$vpdebug = vp_getoption("vpdebug");
if($en == "TRUE" || $response  === vp_getoption("airtimesuccessvalue")){

				if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
	$vpdebug = vp_getoption("vpdebug");

		$myemail = get_userdata($id)->user_email;
$content = "Hello!,<br><b> A new user just vended from you</b><br> Name = ".$name."<br> Network = ".$network." <br> Phone = ".$phone."<br> Amount = ".$amount."<br>";
wp_mail($myemail, "New Vend Data [".$name."]", $content, $headers);
global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'network' => $_REQUEST["network_name"],
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Successful",
'the_time' => current_time('mysql', 1)
));
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){
do_action("vp_after");
}

//VTU AIRTIME SUCCESS
die("100");
}
else{

global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'network' => $_REQUEST["network_name"],
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Pending",
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("airtime1_response_format").'"}');


}
}
else{
$url = vp_getoption("airtimebaseurl").vp_getoption("airtimeendpoint");
$num = $phone;
	$cua = vp_getoption("airtimepostdata1");
    $cppa = vp_getoption("airtimepostdata2");
    $c1a = vp_getoption("airtimepostdata3");
    $c2a = vp_getoption("airtimepostdata4");
    $c3a = vp_getoption("airtimepostdata5");
    $cna = vp_getoption("airtimenetworkattribute");
    $caa = vp_getoption("airtimeamountattribute");
    $cpa = vp_getoption("airtimephoneattribute");
	$uniqid = vp_getoption("arequest_id");
    
    $datass = array(
     $cua => vp_getoption("airtimepostvalue1"),
     $cppa => vp_getoption("airtimepostvalue2"),
	$c1a => vp_getoption("airtimepostvalue3"),
	$c2a => vp_getoption("airtimepostvalue4"),
	$c3a => vp_getoption("airtimepostvalue5"),
	$uniqid => $uniqidvalue,
	$cna => $network,
	$caa =>floatval($_REQUEST['amount']),
	$cpa => $phone
	);

$the_head =  vp_getoption("airtime_head");
if($the_head == "not_concatenated"){
	$the_auth = vp_getoption("airtimevalue1");
}
else{
	$the_auth_value = vp_getoption("airtimevalue1");
	$the_auth = base64_encode($the_auth_value);
}
$sc = vp_getoption("airtimesuccesscode");
//echo "<script>alert('url1".$url."');</script>";

$token = vp_getoption("airtimehead1");
$auto = "$token $the_auth";

$vtuairtime_array = [];
$vtuairtime_array["cache-control"] = "no-cache";
$vtuairtime_array["content-type"] = "application/json";
$vtuairtime_array["Authorization"] = $auto;
for($vtuaddheaders=1; $vtuaddheaders<=4; $vtuaddheaders++){
	if(!empty(vp_getoption("vtuaddheaders$vtuaddheaders")) && !empty(vp_getoption("vtuaddvalue$vtuaddheaders"))){
		$vtuairtime_array[vp_getoption("vtuaddheaders$vtuaddheaders")] = vp_getoption("vtuaddvalue$vtuaddheaders");
	}
}



$http_args = array(
'headers' => $vtuairtime_array,
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'blocking'=> true,
'body' => json_encode($datass)
);
	


$call =  wp_remote_post($url, $http_args);
$response = wp_remote_retrieve_body($call);



if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = "$error";
die(json_encode($obj));
}
else{
if(vp_getoption("airtime1_response_format") == "JSON" || vp_getoption("airtime1_response_format") == "json"){
$en = validate_response($response,$sc, vp_getoption("airtimesuccessvalue"), vp_getoption("airtimesuccessvalue2"));
}
else{
$en = $response ;
}
}


if($en == "TRUE"  || $response  === vp_getoption("airtimesuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
		$myemail = get_userdata($id)->user_email;
$content = "Hello!,<br><b> A new user just vended from you</b><br> Name = ".$name."<br> Network = ".$network." <br> Phone = ".$phone."<br> Amount = ".$amount."<br>";
wp_mail($myemail, "New Vend Data [".$name."]", $content, $headers);
  
global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'network' => $_REQUEST["network_name"],
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Successful",
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;

vp_updateuser($id, 'vp_bal', $tot);


if(is_plugin_active("vpmlm/vpmlm.php")){	
do_action("vp_after");
}

//POST VTU AIRTIME SUCCESS
die("100");

}
else{

global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'network' => $_REQUEST["network_name"],
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Pending",
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("airtime1_response_format").'"}');


}
}

}
elseif($airtimechoice == "share"){


$vpdebug = vp_getoption("vpdebug");
if(vp_getoption("sairtimerequest") == "get"){
	
$http_args = array(
'headers' => array(
'cache-control' => 'no-cache',
'Content-Type' => 'application/json'
),
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false);

//$ch = curl_init($url);
$urlraw = htmlspecialchars_decode($_REQUEST["url"]);
$base = str_replace("sharebase",vp_option_array($option_array,"sairtimebaseurl"),$urlraw);
$postdata1 = str_replace("sharepostdata1",vp_option_array($option_array,"sairtimepostdata1"),$base);
$postvalue1 = str_replace("sharepostvalue1",vp_option_array($option_array,"sairtimepostvalue1"),$postdata1);
$postdata2 = str_replace("sharepostdata2",vp_option_array($option_array,"sairtimepostdata2"),$postvalue1);
$postvalue2 = str_replace("sharepostvalue2",vp_option_array($option_array,"sairtimepostvalue2"),$postdata2);
$url = $postvalue2;

$sc = vp_getoption("sairtimesuccesscode");


$call =  wp_remote_get($url, $http_args);
$response =wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));

}
else{
if(vp_getoption("airtime2_response_format") == "JSON" || vp_getoption("airtime2_response_format") == "json"){
$en = validate_response($response,$sc, vp_getoption("sairtimesuccessvalue"), vp_getoption("sairtimesuccessvalue2") );
}
else{
$en = $response ;
}
}
$vpdebug = vp_getoption("vpdebug");
if($en == "TRUE"  || $response  === vp_getoption("sairtimesuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
	$vpdebug = vp_getoption("vpdebug");

		$myemail = get_userdata($id)->user_email;
$content = "Hello!,<br><b> A new user just vended from you</b><br> Name = ".$name."<br> Network = ".$network." <br> Phone = ".$phone."<br> Amount = ".$amount."<br>";
wp_mail($myemail, "New Vend Data [".$name."]", $content, $headers);
global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'network' => $_REQUEST["network_name"],
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Successful",
'the_time' => current_time('mysql', 1)
));
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){	
do_action("vp_after");
}

die("100");
}
else{

global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'network' => $_REQUEST["network_name"],
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Pending",
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("airtime2_response_format").'"}');

}
}
else{

$url = vp_getoption("sairtimebaseurl").vp_getoption("sairtimeendpoint");
$num = $phone;
	$cua = vp_getoption("sairtimepostdata1");
    $cppa = vp_getoption("sairtimepostdata2");
    $c1a = vp_getoption("sairtimepostdata3");
    $c2a = vp_getoption("sairtimepostdata4");
    $c3a = vp_getoption("sairtimepostdata5");
    $cna = vp_getoption("sairtimenetworkattribute");
    $caa = vp_getoption("sairtimeamountattribute");
    $cpa = vp_getoption("sairtimephoneattribute");
	$uniqid = vp_getoption("sarequest_id");
    
    $datass = array(
     $cua => vp_getoption("sairtimepostvalue1"),
     $cppa => vp_getoption("sairtimepostvalue2"),
	$c1a => vp_getoption("sairtimepostvalue3"),
	$c2a => vp_getoption("sairtimepostvalue4"),
	$c3a => vp_getoption("sairtimepostvalue5"),
	$uniqid => $uniqidvalue,
	$cna => $network,
	$caa =>floatval($_REQUEST['amount']),
	$cpa => $phone
	);


$the_head =  vp_getoption("airtime_head2");
if($the_head == "not_concatenated"){
	$the_auth = vp_getoption("sairtimevalue1");
}
else{
	$the_auth_value = vp_getoption("sairtimevalue1");
	$the_auth = base64_encode($the_auth_value);
}

$auto = vp_getoption("sairtimehead1").' '.$the_auth;

$shareairtime_array = [];
$shareairtime_array["Content-Type"] = "application/json";
$shareairtime_array["cache-control"] = "no-cache";
$shareairtime_array["Authorization"] = $auto;
for($shareaddheaders=1; $shareaddheaders<=4; $shareaddheaders++){
	if(!empty(vp_getoption("shareaddheaders$shareaddheaders")) && !empty(vp_getoption("shareaddvalue$shareaddheaders"))){
		$shareairtime_array[vp_getoption("shareaddheaders$shareaddheaders")] = vp_getoption("shareaddvalue$shareaddheaders");
	}
}

$http_args = array(
'headers' => $shareairtime_array,
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false,
'body' => json_encode($datass)
);

$sc = vp_getoption("sairtimesuccesscode");

$call =  wp_remote_post($url, $http_args);
$response =wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));

}
else{
if(vp_getoption("airtime2_response_format") == "JSON" || vp_getoption("airtime2_response_format") == "json"){
$en = validate_response($response,$sc, vp_getoption("sairtimesuccessvalue"), vp_getoption("sairtimesuccessvalue2"));
}
else{
$en = $response ;
}
}

if($en == "TRUE"  || $response  === vp_getoption("sairtimesuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
		$myemail = get_userdata($id)->user_email;
$content = "Hello!,<br><b> A new user just vended from you</b><br> Name = ".$name."<br> Network = ".$network." <br> Phone = ".$phone."<br> Amount = ".$amount."<br>";
wp_mail($myemail, "New Vend Data [".$name."]", $content, $headers);
  
global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'network' => $_REQUEST["network_name"],
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Successful",
'the_time' => current_time('mysql', 1)
));
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){	
do_action("vp_after");
}

die("100");
}
else{

global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'network' => $_REQUEST["network_name"],
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Pending",
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("airtime2_response_format").'"}');

}
}
	
	
	
}
else{

$vpdebug = vp_getoption("vpdebug");
if(vp_getoption("wairtimerequest") == "get"){
//$ch = curl_init($url);
$urlraw = htmlspecialchars_decode($_REQUEST["url"]);
$base = str_replace("awufbase",vp_option_array($option_array,"wairtimebaseurl"),$urlraw);
$postdata1 = str_replace("awufpostdata1",vp_option_array($option_array,"wairtimepostdata1"),$base);
$postvalue1 = str_replace("awufpostvalue1",vp_option_array($option_array,"wairtimepostvalue1"),$postdata1);
$postdata2 = str_replace("awufpostdata2",vp_option_array($option_array,"wairtimepostdata2"),$postvalue1);
$postvalue2 = str_replace("awufpostvalue2",vp_option_array($option_array,"wairtimepostvalue2"),$postdata2);
$url = $postvalue2;
$sc = vp_getoption("wairtimesuccesscode");
//echo "<script>alert('url1".$url."');</script>";

$http_args = array(
'headers' => array(
'cache-control' => 'no-cache',
'Content-Type' => 'application/json'
),
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false
);

$call =  wp_remote_get($url, $http_args);
$response = wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));
}
else{
if(vp_getoption("airtime3_response_format") == "JSON" || vp_getoption("airtime3_response_format") == "json"){
$en = validate_response($response,$sc, vp_getoption("wairtimesuccessvalue"), vp_getoption("wairtimesuccessvalue2") );
}
else{
$en = $response ;
}
}
$vpdebug = vp_getoption("vpdebug");
if($en == "TRUE"  || $response  === vp_getoption("wairtimesuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
	$vpdebug = vp_getoption("vpdebug");

		$myemail = get_userdata($id)->user_email;
$content = "Hello!,<br><b> A new user just vended from you</b><br> Name = ".$name."<br> Network = ".$network." <br> Phone = ".$phone."<br> Amount = ".$amount."<br>";
wp_mail($myemail, "New Vend Data [".$name."]", $content, $headers);
global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'network' => $_REQUEST["network_name"],
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Successful",
'the_time' => current_time('mysql', 1)
));
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){	
do_action("vp_after");
}

die("100");
}
else{
	

global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'network' => $_REQUEST["network_name"],
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Pending",
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("airtime3_response_format").'"}');

}
}
else{
$url = vp_getoption("wairtimebaseurl").vp_getoption("wairtimeendpoint");
$num = $phone;
	$cua = vp_getoption("wairtimepostdata1");
    $cppa = vp_getoption("wairtimepostdata2");
    $c1a = vp_getoption("wairtimepostdata3");
    $c2a = vp_getoption("wairtimepostdata4");
    $c3a = vp_getoption("wairtimepostdata5");
    $cna = vp_getoption("wairtimenetworkattribute");
    $caa = vp_getoption("wairtimeamountattribute");
    $cpa = vp_getoption("wairtimephoneattribute");
	$uniqid = vp_getoption("warequest_id");
    
    $datass = array(
     $cua => vp_getoption("wairtimepostvalue1"),
     $cppa => vp_getoption("wairtimepostvalue2"),
	$c1a => vp_getoption("wairtimepostvalue3"),
	$c2a => vp_getoption("wairtimepostvalue4"),
	$c3a => vp_getoption("wairtimepostvalue5"),
	$uniqid => $uniqidvalue,
	$cna => $network,
	$caa =>floatval($_REQUEST['amount']),
	$cpa => $phone
	);

$the_head =  vp_getoption("airtime_head3");
if($the_head == "not_concatenated"){
	$the_auth = vp_getoption("wairtimevalue1");
}
else{
	$the_auth_value = vp_getoption("wairtimevalue1");
	$the_auth = base64_encode($the_auth_value);
}

$sc = vp_getoption("wairtimesuccesscode");
$auto = vp_getoption("wairtimehead1").' '.$the_auth;

$awufairtime_array = [];
$awufairtime_array["Content-Type"] = "application/json";
$awufairtime_array["cache-control"] = "no-cache";
$awufairtime_array["Authorization"] = $auto;
for($awufaddheaders=1; $awufaddheaders<=4; $awufaddheaders++){
	if(!empty(vp_getoption("awufaddheaders$awufaddheaders")) && !empty(vp_getoption("awufaddvalue$awufaddheaders"))){
		$awufairtime_array[vp_getoption("awufaddheaders$awufaddheaders")] = vp_getoption("awufaddvalue$awufaddheaders");
	}
}

$http_args = array(
'headers' => $awufairtime_array,
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false,
'body' => json_encode($datass)
);



$call =  wp_remote_post($url, $http_args);
$response =wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));
}
else{
if(vp_getoption("airtime3_response_format") == "JSON" || vp_getoption("airtime3_response_format") == "json"){
$en = validate_response($response,$sc, vp_getoption("wairtimesuccessvalue"), vp_getoption("wairtimesuccessvalue2") );
}
else{
$en = $response ;
}
}
if($en == "TRUE"  || $response  === vp_getoption("wairtimesuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
		$myemail = get_userdata($id)->user_email;
$content = "Hello!,<br><b> A new user just vended from you</b><br> Name = ".$name."<br> Network = ".$network." <br> Phone = ".$phone."<br> Amount = ".$amount."<br>";
wp_mail($myemail, "New Vend Data [".$name."]", $content, $headers);
  
global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'network' => $_REQUEST["network_name"],
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Successful",
'the_time' => current_time('mysql', 1)
));
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){	
do_action("vp_after");
}

die("100");
}
else{

global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'network' => $_REQUEST["network_name"],
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Pending",
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("airtime3_response_format").'"}');

}
}

}

break;
case "cdat":
$dplan == $_REQUEST['cplan'];
$datatcode = $_REQUEST['datatcode'];
if($datatcode == "sme"){
$vpdebug = vp_getoption("vpdebug");
if(vp_getoption("datarequest") == "get"){


$http_args = array(
'headers' => array(
'cache-control' => 'no-cache',
	'Content-Type' => 'application/json'
),
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false
);


$urlraw = htmlspecialchars_decode($_REQUEST["url"]);
$base = str_replace("smebase",vp_option_array($option_array,"databaseurl"),$urlraw);
$postdata1 = str_replace("smepostdata1",vp_option_array($option_array,"datapostdata1"),$base);
$postvalue1 = str_replace("smepostvalue1",vp_option_array($option_array,"datapostvalue1"),$postdata1);
$postdata2 = str_replace("smepostdata2",vp_option_array($option_array,"datapostdata2"),$postvalue1);
$postvalue2 = str_replace("smepostvalue2",vp_option_array($option_array,"datapostvalue2"),$postdata2);
$url = $postvalue2;

$sc = vp_getoption("datasuccesscode");

$call =  wp_remote_get($url, $http_args);
$response = wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));
}
else{
if(vp_getoption("data1_response_format") == "JSON" || vp_getoption("data1_response_format") == "json"){
$en = validate_response($response,$sc, vp_getoption("datasuccessvalue"), vp_getoption("datasuccessvalue2") );	
}
else{
$en = $response ;
}
}

$vpdebug = vp_getoption("vpdebug");
if($en == "TRUE"  || $response  === vp_getoption("datasuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}

global $wpdb;
$table_name = $wpdb->prefix.'sdata';
$wpdb->insert($table_name, array(
'name'=> $name,
'email' => $email,
'phone' => $phone,
'plan' => $_REQUEST["data_plan"],
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => 'Successful',
'the_time' => current_time('mysql', 1)
));

$myemail = get_userdata($id)->user_email;
$content = "Hello!,<br><b> A new user just vended from you</b><br> Name = ".$name."<br> Plan = ".$dplan." <br> Phone = ".$phone."<br> Amount = ".$amount."<br>";
wp_mail($myemail, "New Vend Data [".$name."]", $content, $headers);
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){
do_action("vp_after");
}

die("100");
}
else{



global $wpdb;
$table_name = $wpdb->prefix.'sdata';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'phone' => $phone,
'plan' => $_REQUEST["data_plan"],
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => 'Pending',
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);
die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("data1_response_format").'"}');
	
}
}
else{
$url = vp_getoption("databaseurl").vp_getoption("dataendpoint");
$num = $phone;
$cua = vp_getoption("datapostdata1");
    $cppa = vp_getoption("datapostdata2");
    $c1a = vp_getoption("datapostdata3");
    $c2a = vp_getoption("datapostdata4");
    $c3a = vp_getoption("datapostdata5");
    $cna = vp_getoption("datanetworkattribute");
    $caa = vp_getoption("dataamountattribute");
    $cpa = vp_getoption("dataphoneattribute");
	$cpla = vp_getoption("cvariationattr");
	$uniqid = vp_getoption("request_id");
    
    $datass = array(
     $cua => vp_getoption("datapostvalue1"),
     $cppa => vp_getoption("datapostvalue2"),
	$c1a => vp_getoption("datapostvalue3"),
	$c2a => vp_getoption("datapostvalue4"),
	$c3a => vp_getoption("datapostvalue5"),
	$uniqid => $uniqidvalue,
	$cna => $network,
	$cpa => $phone,
	$cpla => $dplan
	);

$the_head =  vp_getoption("data_head");
if($the_head == "not_concatenated"){
	$the_auth = vp_getoption("datavalue1");
}
else{
	$the_auth_value = vp_getoption("datavalue1");
	$the_auth = base64_encode($the_auth_value);
}

$auto = vp_getoption("datahead1").' '.$the_auth;

$sme_array = [];
$sme_array["Content-Type"] = "application/json";
$sme_array["cache-control"] = "no-cache";
$sme_array["Authorization"] = $auto;
for($smeaddheaders=1; $smeaddheaders<=4; $smeaddheaders++){
	if(!empty(vp_getoption("smeaddheaders$smeaddheaders")) && !empty(vp_getoption("smeaddvalue$smeaddheaders"))){
		$sme_array[vp_getoption("smeaddheaders$smeaddheaders")] = vp_getoption("smeaddvalue$smeaddheaders");
	}
}

$http_args = array(
'headers' => $sme_array,
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false,
'body' => json_encode($datass)
);

$sc = vp_getoption("datasuccesscode");
//echo "<script>alert('url1".$url."');</script>";


$call =  wp_remote_post($url, $http_args);
$response =wp_remote_retrieve_body($call);


if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));
}
else{
if(vp_getoption("data1_response_format") == "JSON" || vp_getoption("data1_response_format") == "json"){
$en = validate_response($response,$sc,vp_getoption("datasuccessvalue"),vp_getoption("datasuccessvalue2"));
}
else{
$en = $response ;
}
}

if($en == "TRUE"  || $response  === vp_getoption("datasuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
		$myemail = get_userdata($id)->user_email;
$content = "Hello!,<br><b> A new user just vended from you</b><br> Name = ".$name."<br> Network = ".$network." <br> Phone = ".$phone."<br> Amount = ".$amount."<br>";
wp_mail($myemail, "New Vend Data [".$name."]", $content, $headers);
  

global $wpdb;
$table_name = $wpdb->prefix.'sdata';
$wpdb->insert($table_name, array(
'name'=> $name,
'email' => $email,
'phone' => $phone,
'plan' => $_REQUEST["data_plan"],
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => 'Successful',
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){
do_action("vp_after");
}

die("100");
}
else{


global $wpdb;
$table_name = $wpdb->prefix.'sdata';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'phone' => $phone,
'plan' => $_REQUEST["data_plan"],
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => 'Pending',
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);


die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format ":"'.vp_getoption("data1_response_format").'"}');
	

}
	
	
	
}
}
elseif($datatcode == "direct"){

$vpdebug = vp_getoption("vpdebug");
if(vp_getoption("rdatarequest") == "get"){

$urlraw = htmlspecialchars_decode($_REQUEST["url"]);
$base = str_replace("directbase",vp_option_array($option_array,"rdatabaseurl"),$urlraw);
$postdata1 = str_replace("directpostdata1",vp_option_array($option_array,"rdatapostdata1"),$base);
$postvalue1 = str_replace("directpostvalue1",vp_option_array($option_array,"rdatapostvalue1"),$postdata1);
$postdata2 = str_replace("directpostdata2",vp_option_array($option_array,"rdatapostdata2"),$postvalue1);
$postvalue2 = str_replace("directpostvalue2",vp_option_array($option_array,"rdatapostvalue2"),$postdata2);
$url = $postvalue2;

$sc = vp_getoption("rdatasuccesscode");

$http_args = array(
'headers' => array(
'cache-control' => 'no-cache',
	'Content-Type' => 'application/json'
),
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false
);

$call =  wp_remote_get($url, $http_args);
$response =wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));
}
else{
if(vp_getoption("data2_response_format") == "JSON" || vp_getoption("data2_response_format") == "json"){
$en = validate_response($response,$sc,vp_getoption("rdatasuccessvalue"),vp_getoption("rdatasuccessvalue2"));
}
else{
$en = $response ;
}
}
$vpdebug = vp_getoption("vpdebug");
if($en == "TRUE"  || $response  === vp_getoption("rdatasuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}


global $wpdb;
$table_name = $wpdb->prefix.'sdata';
$wpdb->insert($table_name, array(
'name'=> $name,
'email' => $email,
'phone' => $phone,
'plan' => $_REQUEST["data_plan"],
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => 'Successful',
'the_time' => current_time('mysql', 1)
));


$myemail = get_userdata($id)->user_email;
$content = "Hello!,<br><b> A new user just vended from you</b><br> Name = ".$name."<br> Plan = ".$dplan." <br> Phone = ".$phone."<br> Amount = ".$amount."<br>";
wp_mail($myemail, "New Vend Data [".$name."]", $content, $headers);
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){
do_action("vp_after");
}

die("100");
}
else{



global $wpdb;
$table_name = $wpdb->prefix.'sdata';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'phone' => $phone,
'plan' => $_REQUEST["data_plan"],
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => 'Pending',
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);


echo'{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("data2_response_format").'"}';
		
}
}
else{$url = vp_getoption("rdatabaseurl").vp_getoption("rdataendpoint");
$num = $phone;
$cua = vp_getoption("rdatapostdata1");
    $cppa = vp_getoption("rdatapostdata2");
    $c1a = vp_getoption("rdatapostdata3");
    $c2a = vp_getoption("rdatapostdata4");
    $c3a = vp_getoption("rdatapostdata5");
    $cna = vp_getoption("rdatanetworkattribute");
    $caa = vp_getoption("rdataamountattribute");
    $cpa = vp_getoption("rdataphoneattribute");
	$cpla = vp_getoption("rcvariationattr");
	$uniqid = vp_getoption("rrequest_id");
    
    $datass = array(
     $cua => vp_getoption("rdatapostvalue1"),
     $cppa => vp_getoption("rdatapostvalue2"),
	$c1a => vp_getoption("rdatapostvalue3"),
	$c2a => vp_getoption("rdatapostvalue4"),
	$c3a => vp_getoption("rdatapostvalue5"),
	$uniqid => $uniqidvalue,
	$cna => $network,
	$cpa => $phone,
	$cpla => $dplan
	);

$the_head =  vp_getoption("data_head2");
if($the_head == "not_concatenated"){
	$the_auth = vp_getoption("rdatavalue1");
}
else{
	$the_auth_value = vp_getoption("rdatavalue1");
	$the_auth = base64_encode($the_auth_value);
}

$auto = vp_getoption("rdatahead1").' '.$the_auth;

$direct_array = [];
$direct_array["Content-Type"] = "application/json";
$direct_array["cache-control"] = "no-cache";
$direct_array["Authorization"] = $auto;
for($directaddheaders=1; $directaddheaders<=4; $directaddheaders++){
	if(!empty(vp_getoption("directaddheaders$directaddheaders")) && !empty(vp_getoption("directaddvalue$directaddheaders"))){
		$direct_array[vp_getoption("directaddheaders$directaddheaders")] = vp_getoption("directaddvalue$directaddheaders");
	}
}

$http_args = array(
'headers' => $direct_array,
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false,
'body' => json_encode($datass)
);

$sc = vp_getoption("rdatasuccesscode");

$call =  wp_remote_post($url, $http_args);
$response = wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));

}
else{
if(vp_getoption("data2_response_format") == "JSON" || vp_getoption("data2_response_format") == "json"){
$en = validate_response($response,$sc,vp_getoption("rdatasuccessvalue"),vp_getoption("rdatasuccessvalue2"));
}
else{
$en = $response ;
}
}

if($en == "TRUE"  || $response  === vp_getoption("rdatasuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
		$myemail = get_userdata($id)->user_email;
$content = "Hello!,<br><b> A new user just vended from you</b><br> Name = ".$name."<br> Network = ".$network." <br> Phone = ".$phone."<br> Amount = ".$amount."<br>";
wp_mail($myemail, "New Vend Data [".$name."]", $content, $headers);
  

global $wpdb;
$table_name = $wpdb->prefix.'sdata';
$wpdb->insert($table_name, array(
'name'=> $name,
'email' => $email,
'phone' => $phone,
'plan' => $_REQUEST["data_plan"],
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => 'Successful',
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){	
do_action("vp_after");
}

die("100");

}
else{



global $wpdb;
$table_name = $wpdb->prefix.'sdata';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'phone' => $phone,
'plan' => $_REQUEST["data_plan"],
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => 'Pending',
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);


die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("data2_response_format").'"}');
	

}
	
	
	
}

}
else{
$vpdebug = vp_getoption("vpdebug");
if(vp_getoption("r2datarequest") == "get"){

$http_args = array(
'headers' => array(
'cache-control' => 'no-cache',
	'Content-Type' => 'application/json'
),
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false
);


$urlraw = htmlspecialchars_decode($_REQUEST["url"]);
$base = str_replace("corporatebase",vp_option_array($option_array,"r2databaseurl"),$urlraw);
$postdata1 = str_replace("corporatepostdata1",vp_option_array($option_array,"r2datapostdata1"),$base);
$postvalue1 = str_replace("corporatepostvalue1",vp_option_array($option_array,"r2datapostvalue1"),$postdata1);
$postdata2 = str_replace("corporatepostdata2",vp_option_array($option_array,"r2datapostdata2"),$postvalue1);
$postvalue2 = str_replace("corporatepostvalue2",vp_option_array($option_array,"r2datapostvalue2"),$postdata2);
$url = $postvalue2;

$sc = vp_getoption("r2datasuccesscode");

$call =  wp_remote_get($url, $http_args);
$response = wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));
}
else{
if(vp_getoption("data3_response_format") == "JSON" || vp_getoption("data3_response_format") == "json"){
$en = validate_response($response,$sc,vp_getoption("r2datasuccessvalue"),vp_getoption("r2datasuccessvalue2"));
}
else{
$en = $response ;
}
}

$vpdebug = vp_getoption("vpdebug");
if($en == "TRUE"  || $response  === vp_getoption("r2datasuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
//echo"<script>alert('sta 1 ma');</script>";

global $wpdb;
$table_name = $wpdb->prefix.'sdata';
$wpdb->insert($table_name, array(
'name'=> $name,
'email' => $email,
'phone' => $phone,
'plan' => $_REQUEST["data_plan"],
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => 'Successful',
'the_time' => current_time('mysql', 1)
));


$myemail = get_userdata($id)->user_email;
$content = "Hello!,<br><b> A new user just vended from you</b><br> Name = ".$name."<br> Plan = ".$dplan." <br> Phone = ".$phone."<br> Amount = ".$amount."<br>";
wp_mail($myemail, "New Vend Data [".$name."]", $content, $headers);
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){	
do_action("vp_after");
}

die("100");
}
else{


global $wpdb;
$table_name = $wpdb->prefix.'sdata';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'phone' => $phone,
'plan' => $_REQUEST["data_plan"],
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => 'Pending',
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);



echo'{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("data3_response_format").'"}';
		
}
}
else{
$url = vp_getoption("r2databaseurl").vp_getoption("r2dataendpoint");
$num = $phone;
$cua = vp_getoption("r2datapostdata1");
    $cppa = vp_getoption("r2datapostdata2");
    $c1a = vp_getoption("r2datapostdata3");
    $c2a = vp_getoption("r2datapostdata4");
    $c3a = vp_getoption("r2datapostdata5");
    $cna = vp_getoption("r2datanetworkattribute");
    $caa = vp_getoption("r2dataamountattribute");
    $cpa = vp_getoption("r2dataphoneattribute");
	$cpla = vp_getoption("r2cvariationattr");
	$uniqid = vp_getoption("r2request_id");
    
    $datass = array(
     $cua => vp_getoption("r2datapostvalue1"),
     $cppa => vp_getoption("r2datapostvalue2"),
	$c1a => vp_getoption("r2datapostvalue3"),
	$c2a => vp_getoption("r2datapostvalue4"),
	$c3a => vp_getoption("r2datapostvalue5"),
	$uniqid => $uniqidvalue,
	$cna => $network,
	$cpa => $phone,
	$cpla => $dplan
	);

$the_head =  vp_getoption("data_head3");
if($the_head == "not_concatenated"){
	$the_auth = vp_getoption("r2datavalue1");
}
else{
	$the_auth_value = vp_getoption("r2datavalue1");
	$the_auth = base64_encode($the_auth_value);
}

$auto = vp_getoption("r2datahead1").' '.$the_auth;

$corporate_array = [];
$corporate_array["Content-Type"] = "application/json";
$corporate_array["cache-control"] = "no-cache";
$corporate_array["Authorization"] = $auto;
for($corporateaddheaders=1; $corporateaddheaders<=4; $corporateaddheaders++){
	if(!empty(vp_getoption("corporateaddheaders$corporateaddheaders")) && !empty(vp_getoption("corporateaddvalue$corporateaddheaders"))){
		$corporate_array[vp_getoption("corporateaddheaders$corporateaddheaders")] = vp_getoption("corporateaddvalue$corporateaddheaders");
	}
}


$http_args = array(
'headers' => $corporate_array,
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false,
'body' => json_encode($datass)
);

$sc = vp_getoption("r2datasuccesscode");

$call =  wp_remote_post($url, $http_args);
$response = wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));
}
else{
if(vp_getoption("data3_response_format") == "JSON" || vp_getoption("data3_response_format") == "json"){
$en = validate_response($response,$sc,vp_getoption("r2datasuccessvalue"),vp_getoption("r2datasuccessvalue2"));
}
else{
$en = $response ;
}
}

if($en == "TRUE"  || $response  === vp_getoption("r2datasuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
$myemail = get_userdata($id)->user_email;
$content = "Hello!,<br><b> A new user just vended from you</b><br> Name = ".$name."<br> Network = ".$network." <br> Phone = ".$phone."<br> Amount = ".$amount."<br>";
wp_mail($myemail, "New Vend Data [".$name."]", $content, $headers);
  

global $wpdb;
$table_name = $wpdb->prefix.'sdata';
$wpdb->insert($table_name, array(
'name'=> $name,
'email' => $email,
'phone' => $phone,
'plan' => $_REQUEST["data_plan"],
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => 'Successful',
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){	
do_action("vp_after");
}
die("100");

}
else{
	

global $wpdb;
$table_name = $wpdb->prefix.'sdata';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'phone' => $phone,
'plan' => $_REQUEST["data_plan"],
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => 'Pending',
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);



die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("data3_response_format").'"}');
	

}

}

}

break;
case "ccab":
if(vp_getoption("cablerequest") == "get"){
$urlraw = htmlspecialchars_decode($_REQUEST["url"]);
$base = str_replace("cablebase",vp_option_array($option_array,"cablebaseurl"),$urlraw);
$postdata1 = str_replace("cablepostdata1",vp_option_array($option_array,"cablepostdata1"),$base);
$postvalue1 = str_replace("cablepostvalue1",vp_option_array($option_array,"cablepostvalue1"),$postdata1);
$postdata2 = str_replace("cablepostdata2",vp_option_array($option_array,"cablepostdata2"),$postvalue1);
$postvalue2 = str_replace("cablepostvalue2",vp_option_array($option_array,"cablepostvalue2"),$postdata2);
$url = $postvalue2;

$sc = vp_getoption("cablesuccesscode");

$call =  wp_remote_get($url, $http_args);
$response =wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($url));

}
else{
if(vp_getoption("cable_response_format") == "JSON" || vp_getoption("cable_response_format") == "json"){
$en = validate_response($response,$sc,vp_getoption("cablesuccessvalue"),vp_getoption("cablesuccessvalue2"));
}
else{
$en = $response ;
}
}

if($en == "TRUE"  || $response  === vp_getoption("cablesuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
	

global $wpdb;
$table_name = $wpdb->prefix.'scable';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'iucno' => $iuc,
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'product_id' => $ccable,
'type' => $cabtype,
'status' => "Successful",
'user_id' => $id,
'time' => current_time('mysql', 1)
));
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);


if(is_plugin_active("vpmlm/vpmlm.php")){	
do_action("vp_after");
}


//wp_redirect(site_url().apply_filters("spage",vp_getoption("suc")));
die("100");

}
else{


global $wpdb;
$table_name = $wpdb->prefix.'scable';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'iucno' => $iuc,
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'product_id' => $ccable,
'type' => $cabtype,
'user_id' => $id,
'status' => "Pending",
'time' => current_time('mysql', 1)
));
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("cable_response_format").'"}');
		
}
}
else{
$url = vp_getoption("cablebaseurl").vp_getoption("cableendpoint");
$num = $phone;
 $cua = vp_getoption("cablepostdata1");
    $cppa = vp_getoption("cablepostdata2");
    $c1a = vp_getoption("cablepostdata3");
    $c2a = vp_getoption("cablepostdata4");
    $c3a = vp_getoption("cablepostdata5");
    $ctypa = vp_getoption("ctypeattr");
    $caa = vp_getoption("cableamountattribute");
	$ccvaa = vp_getoption("ccvariationattr");
	$ciuc = vp_getoption("ciucattr");
	$uniqid = vp_getoption("crequest_id");
    
    $datass = array(
    $cua => vp_getoption("cablepostvalue1"),
    $cppa => vp_getoption("cablepostvalue2"),
	$c1a => vp_getoption("cablepostvalue3"),
	$c2a => vp_getoption("cablepostvalue4"),
	$c3a => vp_getoption("cablepostvalue5"),
	$uniqid => $uniqidvalue,
	$ctypa => $cabtype,
	$ccvaa => $ccable,
	$ciuc => $iuc
	);

$the_head =  vp_getoption("cable_head");
if($the_head == "not_concatenated"){
	$the_auth = vp_getoption("cablevalue1");
}
else{
	$the_auth_value = vp_getoption("cablevalue1");
	$the_auth = base64_encode($the_auth_value);
}

$sc = vp_getoption("cablesuccesscode");

$auto = vp_getoption("cablehead1").' '.$the_auth;


$cable_array = [];
$cable_array["Content-Type"] = "application/json";
$cable_array["cache-control"] = "no-cache";
$cable_array["Authorization"] = $auto;
for($cableaddheaders=1; $cableaddheaders<=4; $cableaddheaders++){
	if(!empty(vp_getoption("cableaddheaders$cableaddheaders")) && !empty(vp_getoption("cableaddvalue$cableaddheaders"))){
		$cable_array[vp_getoption("cableaddheaders$cableaddheaders")] = vp_getoption("cableaddvalue$cableaddheaders");
	}
}

$http_args = array(
'headers' => $cable_array,
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false,
'body' => json_encode($datass)
);

$call =  wp_remote_post($url, $http_args);
$response =wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));
}
else{
if(vp_getoption("cable_response_format") == "JSON" || vp_getoption("cable_response_format") == "json"){
$en = validate_response($response,$sc,vp_getoption("cablesuccessvalue"),vp_getoption("cablesuccessvalue2") );
}
else{
$en = $response ;
}
}

if($en == "TRUE"  || $response  === vp_getoption("cablesuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
  
global $wpdb;
$table_name = $wpdb->prefix.'scable';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'iucno' => $iuc,
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'product_id' => $ccable,
'type' => $cabtype,
'status' => "Successful",
'user_id' => $id,
'time' => current_time('mysql', 1)
));
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){	
do_action("vp_after");
}

die("100");

}
else{

global $wpdb;
$table_name = $wpdb->prefix.'scable';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'iucno' => $iuc,
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'product_id' => $ccable,
'type' => $cabtype,
'user_id' => $id,
'status' => "Pending",
'time' => current_time('mysql', 1)
));
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("cable_response_format").'"}');

}
	
}
break;
case "cbill":

if(vp_getoption("billrequest") == "get"){

$urlraw = htmlspecialchars_decode($_REQUEST["url"]);
$base = str_replace("billbase",vp_option_array($option_array,"billbaseurl"),$urlraw);
$postdata1 = str_replace("billpostdata1",vp_option_array($option_array,"billpostdata1"),$base);
$postvalue1 = str_replace("billpostvalue1",vp_option_array($option_array,"billpostvalue1"),$postdata1);
$postdata2 = str_replace("billpostdata2",vp_option_array($option_array,"billpostdata2"),$postvalue1);
$postvalue2 = str_replace("billpostvalue2",vp_option_array($option_array,"billpostvalue2"),$postdata2);
$url = $postvalue2;

$sc = vp_getoption("billsuccesscode");

$http_args = array(
'headers' => array(
'cache-control' => 'no-cache',
	'Content-Type' => 'application/json'
),
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false);

$call =  wp_remote_get($url, $http_args);
$response = wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));
}
else{
if(vp_getoption("bill_response_format") == "JSON" || vp_getoption("bill_response_format") == "json"){
$en = validate_response($response,$sc,vp_getoption("billsuccessvalue"),vp_getoption("billsuccessvalue2"));
}
else{
$en = $response ;
}
}

if($en == "TRUE"  || $response  === vp_getoption("billsuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
//echo"<script>alert('sta 1 ma');</script>";

$bill_response = search_bill_token(json_decode($response,true),array_change_key_case(vp_getoption("metertoken")),CASE_LOWER);

if(!empty($bill_response)){
	$meter_token = $bill_response[0];
}
else{
		$meter_token = "Nill";
}


global $wpdb;
$table_name = $wpdb->prefix.'sbill';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'meterno' => $meterno,
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Successful",
'product_id' => $cbill,
'meter_token' => $meter_token,
'type' => $type,
'time' => current_time('mysql', 1)
));
$tot = $bal - $amount;


vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){	
do_action("vp_after");
}

die("100");
}
else{

//echo"<script>alert('mae');</script>";
global $wpdb;
$table_name = $wpdb->prefix.'sbill';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'meterno' => $meterno,
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Pending",
'product_id' => $cbill,
'meter_token' => "No Record",
'type' => $type,
'time' => current_time('mysql', 1)
));
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

echo'{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("bill_response_format").'"}';
		
}
}
else{
$url = vp_getoption("billbaseurl").vp_getoption("billendpoint");
$num = $phone;
	$cua = vp_getoption("billpostdata1");
    $cppa = vp_getoption("billpostdata2");
    $c1a = vp_getoption("billpostdata3");
    $c2a = vp_getoption("billpostdata4");
    $c3a = vp_getoption("billpostdata5");
    $btypa = vp_getoption("btypeattr");
    $caa = vp_getoption("billamountattribute");
	$cbvaa = vp_getoption("cbvariationattr");
	$cmeter = vp_getoption("cmeterattr");
	$uniqid = vp_getoption("brequest_id");
    
    $datass = array(
    $cua => vp_getoption("billpostvalue1"),
    $cppa => vp_getoption("billpostvalue2"),
	$c1a => vp_getoption("billpostvalue3"),
	$c2a => vp_getoption("billpostvalue4"),
	$c3a => vp_getoption("billpostvalue5"),
	$uniqid => $uniqidvalue,
	$btypa => $type,
	$cbvaa => $cbill,
	$cmeter => $meterno,
	$caa => float($bamount)
	);

$the_head =  vp_getoption("bill_head");
if($the_head == "not_concatenated"){
	$the_auth = vp_getoption("billvalue1");
}
else{
	$the_auth_value = vp_getoption("billvalue1");
	$the_auth = base64_encode($the_auth_value);
}

$auto = vp_getoption("billhead1").' '.$the_auth;


$bill_array = [];
$bill_array["Content-Type"] = "application/json";
$bill_array["cache-control"] = "no-cache";
$bill_array["Authorization"] = $auto;
for($billaddheaders=1; $billaddheaders<=4; $billaddheaders++){
	if(!empty(vp_getoption("billaddheaders$billaddheaders")) && !empty(vp_getoption("billaddvalue$billaddheaders"))){
		$bill_array[vp_getoption("billaddheaders$billaddheaders")] = vp_getoption("billaddvalue$billaddheaders");
	}
}

$http_args = array(
'headers' => $bill_array,
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false,
'body' => json_encode($datass)
);

$sc = vp_getoption("billsuccesscode");

$call =  wp_remote_post($url, $http_args);
$response =wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));
}
else{
if(vp_getoption("bill_response_format") == "JSON" || vp_getoption("bill_response_format") == "json"){
$en = validate_response($response,$sc,vp_getoption("billsuccessvalue"),vp_getoption("billsuccessvalue2"));
}
else{
$en = $response ;
}
}

if($en == "TRUE"  || $response  === vp_getoption("billsuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
				

$bill_response = search_bill_token(json_decode($response,true),array_change_key_case(vp_getoption("metertoken")),CASE_LOWER);

if(!empty($bill_response)){
	$meter_token = $bill_response[0];
}
else{
		$meter_token = "Nill";
}

  
global $wpdb;
$table_name = $wpdb->prefix.'sbill';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'meterno' => $meterno,
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Successful",
'product_id' => $cbill,
'type' => $type,
'meter_token' => $meter_token,
'time' => current_time('mysql', 1)
));
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

if(is_plugin_active("vpmlm/vpmlm.php")){	
do_action("vp_after");
}

die("100");

}
else{
	
//echo"<script>alert('mae');</script>";
global $wpdb;
$table_name = $wpdb->prefix.'sbill';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'meterno' => $meterno,
'phone' => $phone,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'user_id' => $id,
'status' => "Pending",
'product_id' => $cbill,
'type' => $type,
'meter_token' => "No Record",
'time' => current_time('mysql', 1)
));
$tot = $bal - $amount;
vp_updateuser($id, 'vp_bal', $tot);

die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("bill_response_format").'"}');


}
	
}
break;
case"csms":
$sender = $_REQUEST["sender"];
$receiver = $_REQUEST["receiver"];
$tid = $id;

if(vp_getoption("smsrequest") == "get"){
$url = htmlspecialchars_decode($_REQUEST["url"]);
$sc = vp_getoption("smssuccesscode");

$the_head =  vp_getoption("sms_head");
if($the_head == "not_concatenated"){
	$the_auth = vp_getoption("smsvalue1");
}
else{
	$the_auth_value = vp_getoption("smsvalue1");
	$the_auth = base64_encode($the_auth_value);
}

$auto = vp_getoption("smshead1").' '.$the_auth;

$sms_array = [];
$sms_array["cache-control"] = "no-cache";
$sms_array["Authorization"] = $auto;
for($smsaddheaders=1; $smsaddheaders<=4; $smsaddheaders++){
	if(!empty(vp_getoption("smsaddheaders$smsaddheaders")) && !empty(vp_getoption("smsaddvalue$smsaddheaders"))){
		$sms_array[vp_getoption("smsaddheaders$smsaddheaders")] = vp_getoption("smsaddvalue$smsaddheaders");
	}
}

$http_args = array(
'headers' => $sms_array,
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false);

$call =  wp_remote_get($url, $http_args);
$response =wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));
}
else{
if(vp_getoption("sms_response_format") == "JSON" || vp_getoption("sms_response_format") == "json"){
$en = validate_response($response,$sc,vp_getoption("smssuccessvalue"),vp_getoption("smssuccessvalue2"));
}
else{

if(stripos($response,vp_getoption("smssuccessvalue")) !== false){
$en = "TRUE" ;
}
else{
$en = "FALSE" ;	
}
}


}

if($en == "TRUE"  || $response  === vp_getoption("smssuccessvalue")){
					if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
//echo"<script>alert('sta 1 ma');</script>";
global $wpdb;
$table_name = $wpdb->prefix.'ssms';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'sender' => $sender,
'receiver' => $receiver,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'user_id' => $tid,
'status' => "Successful",
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;

vp_updateuser($id, 'vp_bal', $tot);

die("100");

}
else{

//echo"<script>alert('mae');</script>";

global $wpdb;
$table_name = $wpdb->prefix.'ssms';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'sender' => $sender,
'receiver' => $receiver,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'user_id' => $tid,
'status' => "Pending",
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;

vp_updateuser($id, 'vp_bal', $tot);


echo'{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("sms_response_format").'"}';
		
}
}
else{
$url = vp_getoption("smsbaseurl").vp_getoption("smsendpoint");
$num = $phone;
	$cua = vp_getoption("smspostdata1");
    $cppa = vp_getoption("smspostdata2");
    $c1a = vp_getoption("smspostdata3");
    $c2a = vp_getoption("smspostdata4");
    $c3a = vp_getoption("smspostdata5");
    $sender = vp_getoption("senderattr");
    $receiver = vp_getoption("receiverattr");
    $message = vp_getoption("messageattr");
    $flash = vp_getoption("flashattr");
	$uniqid = vp_getoption("smsrequest_id");
    
    $datass = array(
    $cua => vp_getoption("smspostvalue1"),
    $cppa => vp_getoption("smspostvalue2"),
	$c1a => vp_getoption("smspostvalue3"),
	$c2a => vp_getoption("smspostvalue4"),
	$c3a => vp_getoption("smspostvalue5"),
	$sender => $_REQUEST["sender"],
	$receiver => $_REQUEST["receiver"],
	$message => $_REQUEST["message"],
	$flash => vp_getoption("flash_value"),
	$uniqid => $uniqidvalue,
	);

$the_head =  vp_getoption("sms_head");
if($the_head == "not_concatenated"){
	$the_auth = vp_getoption("smsvalue1");
}
else{
	$the_auth_value = vp_getoption("smsvalue1");
	$the_auth = base64_encode($the_auth_value);
}


$sms_array = [];
$sms_array["Content-Type"] = "application/json";
$sms_array["cache-control"] = "no-cache";
$sms_array["Authorization"] = $auto;
for($smsaddheaders=1; $smsaddheaders<=4; $smsaddheaders++){
	if(!empty(vp_getoption("smsaddheaders$smsaddheaders")) && !empty(vp_getoption("smsaddvalue$smsaddheaders"))){
		$sms_array[vp_getoption("smsaddheaders$smsaddheaders")] = vp_getoption("smsaddvalue$smsaddheaders");
	}
}

$http_args = array(
'headers' => $sms_array,
'timeout' => '120',
'user-agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
'sslverify' => false,
'body' => json_encode($datass)
);



$call =  wp_remote_post($url, $http_args);
$response =wp_remote_retrieve_body($call);

if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));

}
else{
if(vp_getoption("sms_response_format") == "JSON" || vp_getoption("sms_response_format") == "json"){
$en = validate_response($response,$sc,vp_getoption("smssuccessvalue"),vp_getoption("smssuccessvalue2"));
}
else{
$en = $response ;
}
}

if($en == "TRUE"  || $response  === vp_getoption("smssuccessvalue")){
  				if($add_total == "yes"){
					vp_updateuser($id,"vp_kyc_total",(intval($tb4)+intval($tnow)));	
				}
global $wpdb;
$table_name = $wpdb->prefix.'ssms';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'sender' => $sender,
'receiver' => $receiver,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'user_id' => $tid,
'status' => "Successful",
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;

vp_updateuser($id, 'vp_bal', $tot);

die("100");
}
else{

//echo"<script>alert('mae');</script>";
global $wpdb;
$table_name = $wpdb->prefix.'ssms';
$wpdb->insert($table_name, array(
'name'=> $name,
'email'=> $email,
'sender' => $sender,
'receiver' => $receiver,
'bal_bf' => $bal,
'bal_nw' => $baln,
'amount' => $amount,
'user_id' => $tid,
'status' => "Pending",
'resp_log' => "$browser - ".esc_html(harray_key_first($response))."",
'the_time' => current_time('mysql', 1)
));

$tot = $bal - $amount;

vp_updateuser($id, 'vp_bal', $tot);

die('{"status":"200","response":"'.harray_key_first($response).'","response code":"'.wp_remote_retrieve_response_code( $call ).'","EN":"'.$en.'","response format":"'.vp_getoption("sms_response_format").'"}');
	

}
	
}

	break;

default:
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
die(json_encode($obj));


;
}

//end switch
}
//end if Bal great
else{
$remtot = $amount-$bal;

echo '{"status":"200","message":"'.$remtot.' Needed To Complete Transaction"}';
}

	}
	else{

echo '{"status":"200","message":"You can\'t purchase less than 50"}';
		
	}


}
else{
die('{"status":"200","message":"Amount Or Balance Invalid"');	
}
}
else{
die('pin');	
}
}
else{
	die('browser');		
}




}
//end of post wallet

if(isset($_REQUEST["fund_other"])){
	
	$user_id = $_REQUEST["user_id"];
	$r_name = get_userdata($user_id)->user_login;
	$amount = $_REQUEST["amount"];
	$my_id = get_current_user_id();
	$my_balance = vp_getuser($my_id,'vp_bal', true);
	
if($my_balance >= $amount && $my_id != $user_id && empty(strpos($amount,"-")) && $amount > 0){
	
	//Fund User
	$user_current_balance = vp_getuser($user_id, 'vp_bal', true);
	
	$fund_user = intval($user_current_balance)+intval($amount);
	

if($fund_user > $user_current_balance ){
	
	$update_balance = intval($my_balance)-intval($amount);
		
	
	
	$update_me = vp_updateuser($my_id,'vp_bal', $update_balance);
	
	
	$updated_user = vp_updateuser($user_id,'vp_bal',$fund_user);
	
	if($updated_user == true || $updated_user == "true" || $updated_user == "1" && ($updated_me == true || $updated_me == "true" || $updated_me == "1")){
	
	$my_cur_balance = vp_getuser($my_id,'vp_bal', true);
	
	
	
		//Wallet Summary

global $wpdb;
$name = get_userdata($my_id)->user_login;
$description = "Credited By $name On Transfer";
$fund_amount= $amount;
$before_amount = $user_current_balance;
$now_amount = $fund_user;
$user_id = $user_id;
$the_time = current_time('mysql', 1);

$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $name,
'type'=> "Wallet",
'description'=> $description,
'fund_amount' => $fund_amount,
'before_amount' => $before_amount,
'now_amount' => $now_amount,
'user_id' => $user_id,
'status' => "Approved",
'the_time' => current_time('mysql', 1)
));

$name = get_userdata($user_id)->user_login;
$description = "Transfered $amount to $name";
$fund_amount= $amount;
$before_amount = $my_balance;
$now_amount = $update_balance;
$user_id = $my_id;
$the_time = current_time('mysql', 1);

$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $name,
'type'=> "Wallet",
'description'=> $description,
'fund_amount' => $fund_amount,
'before_amount' => $before_amount,
'now_amount' => $now_amount,
'user_id' => $user_id,
'status' => "Approved",
'the_time' => current_time('mysql', 1)
));

	
	
echo '{"status":"100","balance":"'.$my_cur_balance.'"}';
	
	
	
	
	
}
else{
	
echo '{"status":"200","balance":"'.$my_cur_balance.'"}';
}

}

	


}
else{
	
$obj = new stdClass;
$obj->status = "200";
$obj->balance = "Balance Too Low";
die(json_encode($obj));
}


}


if(isset($_REQUEST["check_balance"])){
	$my_id = get_current_user_id();
	$my_balance = vp_getuser($my_id,'vp_bal', true);
	
	if($my_balance != "0" || $my_balance != false || $my_balance != ""){
	echo '{"status":"100", "balance":"'.$my_balance.'"}';
	}
	else{
		echo '{"status":"200"}';
	}
	
}


if(isset($_REQUEST["verify_user"])){
	$user_id = $_REQUEST["user_id"];
	$user_name = get_userdata($user_id)->user_login;
	
	if($user_name != "0" || $user_name != false || $user_name != ""){
	echo '{"status":"100", "user_name":"'.$user_name.'"}';
	}
	else{
		echo '{"status":"200"}';
	}
}


if(isset($_REQUEST["fset"])){

vp_updateoption("vpdebug", $_REQUEST["vpdebug"]);
vp_updateoption("vp_template", $_REQUEST["template"]);
vp_updateoption("charge_method", $_REQUEST["charge_method"]);

vp_updateoption("show_notify", $_REQUEST["show_notify"]);

vp_updateoption("sucreg",$_REQUEST["sucreg"]);

vp_updateoption("vpwalm", $_REQUEST["message"]);

vp_updateoption("manual_funding", $_REQUEST["fundmessage"]);

vp_updateoption("charge_back", $_REQUEST["chargeback"]);

vp_updateoption("vp_phone_line", $_REQUEST["vpphone"]);
vp_updateoption("vp_redirect", $_REQUEST["vpredirect"]);
vp_updateoption("totcons", $_REQUEST["totcons"]);

vp_updateoption("vp_whatsapp", $_REQUEST["vpwhatsapp"]);
vp_updateoption("vp_whatsapp_group", $_REQUEST["vpwhatsappg"]);

vp_updateoption("wallet_to_wallet", $_REQUEST["wallettowallet"]);



if(is_plugin_active("vprest/vprest.php")){
vp_updateoption("resc", $_REQUEST["upgradeamt"]);
vp_updateoption("allow_withdrawal", $_REQUEST["allow_withdrawal"]);
vp_updateoption("allow_to_bank", $_REQUEST["allow_to_bank"]);

vp_updateoption("allow_crypto", $_REQUEST["allow_crypto"]);

vp_updateoption("allow_cards", $_REQUEST["allow_cards"]);
}

echo '{"status":"100"}';

}

	
if(isset($_REQUEST['setactivation'])){
		vp_updateoption('actkey',$_REQUEST["actkey"]);
		vp_updateoption('vpid',$_REQUEST["actid"]);
		
	$actkey = $_REQUEST["actkey"];

    $id = $_REQUEST['actid'];

	
$http_args = array(
'headers' => array(
'cache-control' => 'no-cache',
'content-type' => 'application/json',
'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:100.0) Gecko/20100101 Firefox/100.0'
),
'sslverify' => false);
    
    $url = 'https://vtupress.com/wp-content/plugins/vtuadmin?id='.$_REQUEST["actid"].'&actkey='.$_REQUEST["actkey"];

$call =  wp_remote_get($url, $http_args);
$response =wp_remote_retrieve_body($call);


if(is_wp_error($call)){
$error = $call->get_error_message();
$obj = new stdClass;
$obj->code = "200";
$obj->response = $error;
$json = json_encode($obj)->response;
echo"
<script>
alert($json);
</script>
";
}
else{
$en = json_decode($response, true);
//$str = implode(",",$en);


//$_SERVER['SERVER_NAME'];
if( ini_get('allow_url_fopen') !== false && !empty(ini_get('allow_url_fopen'))) {
if(!empty($response)){
	
if(!empty($en["url"])){
if(preg_match("/".$_SERVER['HTTP_HOST']."/i",$en["url"]) != 0 || strpos($en["url"],$_SERVER['HTTP_HOST']) != false || strpos($en["url"],$_SERVER['SERVER_NAME']) != false || strpos($en["url"],vp_getoption('siteurl')) != false || is_numeric(strpos($en["url"],$_SERVER['HTTP_HOST'])) != false || is_numeric(strpos($en["url"],$_SERVER['SERVER_NAME'])) != false){
$murl = "yes";
	}
	else{
$murl = "no";	
	}
}
else{
$murl = "no";
}



if(isset($en["actkey"]) && ($en["actkey"] == $_REQUEST["actkey"])){

$status = $en["status"];

$url = $en["url"];

$plan = $en["plan"];

$security = $en["security"];


    
    if( $murl == "yes"){
        
        if($status == "active"){
            
            if($plan){
                
if($security == "yes"){
	vp_updateoption("vp_security","yes");
}
else{
	vp_updateoption("vp_security","no");	
}
			/////////////////////////////////
	
if($plan == "demo"){
vp_updateoption('mlm','no');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
vp_updateoption('vprun','none');
vp_updateoption('resell','no');
vp_updateoption('vpid',$_REQUEST["actid"]);
vp_updateoption('actkey',$_REQUEST["actkey"]);
echo '{"status":"100"}';
}
elseif($plan == "unlimited"){
vp_updateoption('mlm','yes');
vp_updateoption('resell','yes');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
vp_updateoption('vpid',$_REQUEST["actid"]);
vp_updateoption('actkey',$_REQUEST["actkey"]);
echo '{"status":"100"}';
}
elseif($plan == "verified"){
vp_updateoption('resell','yes');
vp_updateoption('mlm','no');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
vp_updateoption('vpid',$_REQUEST["actid"]);
vp_updateoption('actkey',$_REQUEST["actkey"]);
echo '{"status":"100"}';
}
elseif($plan == "personal-y"){
vp_updateoption('resell','no');
vp_updateoption('mlm','no');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
vp_updateoption('vpid',$_REQUEST["actid"]);
vp_updateoption('actkey',$_REQUEST["actkey"]);
echo '{"status":"100"}';
}
elseif($plan == "premium-y"){
vp_updateoption('mlm','yes');
vp_updateoption('vprun','none');
vp_updateoption('resell','yes');
vp_updateoption('frmad','none');
vp_updateoption('vpid',$_REQUEST["actid"]);
vp_updateoption('actkey',$_REQUEST["actkey"]);
echo '{"status":"100"}';
}
elseif($plan == "premium"){
vp_updateoption('mlm','yes');
vp_updateoption('vprun','none');
vp_updateoption('frmad','none');
vp_updateoption('resell','yes');
vp_updateoption('vpid',$_REQUEST["actid"]);
vp_updateoption('actkey',$_REQUEST["actkey"]);
echo '{"status":"100"}';
}
elseif($plan == "personal"){
vp_updateoption('mlm','no');
vp_updateoption('vprun','none');
vp_updateoption('resell','no');
vp_updateoption('frmad','none');
vp_updateoption('vpid',$_REQUEST["actid"]);
vp_updateoption('actkey',$_REQUEST["actkey"]);
echo '{"status":"100"}';
}
else{
vp_updateoption('mlm','no');
vp_updateoption('resell','no');
vp_updateoption("showlicense","hide");
vp_updateoption('vprun','block');
vp_updateoption('frmad','block');
vp_updateoption("vp_security","no");
echo '{"status":"200","message":"Plan Not Found"}';
}	
			////////////////////////////
            }
            
        }else{
vp_updateoption('mlm','no');
vp_updateoption('resell','no');
vp_updateoption("showlicense","hide");
vp_updateoption('vprun','block');
vp_updateoption('frmad','block');
vp_updateoption("vp_security","no");
echo '{"status":"200","message":"Status Is '.$status.'"}';
        }
    }else{
vp_updateoption('mlm','no');
vp_updateoption('resell','no');
vp_updateoption("showlicense","hide");
vp_updateoption('vprun','block');
vp_updateoption('frmad','block');
vp_updateoption("vp_security","no");
		vp_updateoption("vp_security","no");		
echo '{"status":"200","message":"URL Doesn\'t Match or is not contained in the Url Directory in vtupress official site"}';
    }
    
}
else{
vp_updateoption('mlm','no');
vp_updateoption('resell','no');
vp_updateoption("showlicense","hide");
vp_updateoption('vprun','block');
vp_updateoption('frmad','block');
vp_updateoption("vp_security","no");
echo '{"status":"200","message":"Activation Key Or Id Incorrect-> - [URL]'.$url.' - [Response] - '.harray_key_first($response).'"}';

}	

}
else{
	echo '{"status":"200","message":"Empty String"}';

}

}
else{
vp_updateoption('mlm','no');
vp_updateoption('resell','no');
vp_updateoption("showlicense","hide");
vp_updateoption('vprun','block');
vp_updateoption('frmad','block');
vp_updateoption("vp_security","no");
	echo '{"status":"200","message":"ALLOW_URL_FOPEN is off on this server. Contact Hosting Company For A Fix [Response - '.ini_get('allow_url_fopen').' ]"}';
}
}
	
	}

if(isset($_REQUEST['updatefl'])){

$public = $_REQUEST['public'];
$secret = $_REQUEST['secret'];
$ppublic = $_REQUEST['ppublic'];
$psecret = $_REQUEST['psecret'];
$paychoice = $_REQUEST['paychoice'];
$fltable_name = $wpdb->prefix.'flutterwave';
$wpdb->update($fltable_name, array(
'public_key' => $public,
'secret_key' => $secret
), array( 'id' => 1));

vp_updateoption('monnifytestmode', $_REQUEST['monnifytest']);
vp_updateoption('monnifyapikey', $_REQUEST['mapi']);
vp_updateoption('monnifysecretkey', $_REQUEST['msec']);
vp_updateoption('monnifycontractcode', $_REQUEST['mcontract']);
vp_updateoption('allow_card_method', $_REQUEST['allow_card_method']);
vp_updateoption('ppub', $ppublic);
vp_updateoption('psec', $psecret);
vp_updateoption('paychoice', $paychoice);


echo '{"status":"100"}';
}

if(isset($_REQUEST["userid"])){
  //global $wp_query;
  $ddid = intval($_REQUEST["userid"]);
  $amt = intval($_REQUEST["amt"]);
  $doaction = $_REQUEST["doaction"];

  switch($_REQUEST["doaction"]){
  case "addbalance":
           $useramt = vp_getuser(intval($_REQUEST["userid"]), 'vp_bal', true);
            $balsum = intval($useramt ) + intval($_REQUEST["amt"]);
           
		

if($balsum > $useramt){
	
	$updated_user = vp_updateuser(intval($_REQUEST["userid"]),'vp_bal', intval($balsum));
	
	if($updated_user == true || $updated_user == "true" || $updated_user == "1"){
	
	echo '{"status":"100"}';
}
else{
	
	echo '{"status":"200"}';
}

}

 $description = $_REQUEST["balance_reason"];
  if(empty($description)){
$description = $_REQUEST["balance_reason"];	
  }
 else{
$description =  "Credited By Admin"; 
 }

		
global $wpdb;
$name = "Admin";

$fund_amount = $_REQUEST["amt"];
$before_amount = $useramt;
$now_amount = $balsum;
$user_id = $_REQUEST["userid"];
$the_time = current_time('mysql', 1);

$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $name,
'type'=> "Wallet",
'description'=> $description,
'fund_amount' => $fund_amount,
'before_amount' => $before_amount,
'now_amount' => $now_amount,
'user_id' => $user_id,
'status' => "Approved",
'the_time' => current_time('mysql', 1)
));

$message = "$name Funded You With $fund_amount";
if(vp_getoption("fcm") == "yes" && vp_getoption("fcm_generate") == "yes"){
sendMessage($user_id,$message);
}



  break;
  case "removebalance":
            $useramt = vp_getuser(intval($_REQUEST["userid"]), 'vp_bal', true);
    
            $balsum = intval($useramt ) - intval($_REQUEST["amt"]);
            
			
		
if($balsum < $useramt){
	
	$updated_user = vp_updateuser(intval($_REQUEST["userid"]),'vp_bal', intval($balsum));
	
	if($updated_user == true || $updated_user == "true" || $updated_user == "1"){
	
	echo '{"status":"100"}';
}
else{
	
	echo '{"status":"200"}';
}
}


 $description = $_REQUEST["balance_reason"];
  if(empty($description)){
$description = $_REQUEST["balance_reason"];	
  }
 else{
$description =  "Debited By Admin"; 
 }


   	   
global $wpdb;
$name = "Admin";
$fund_amount = $_REQUEST["amt"];
$before_amount = $useramt;
$now_amount = $balsum;
$user_id = $_REQUEST["userid"];
$the_time = current_time('mysql', 1);

$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $name,
'type'=> "Wallet",
'description'=> $description,
'fund_amount' => $fund_amount,
'before_amount' => $before_amount,
'now_amount' => $now_amount,
'user_id' => $user_id,
'status' => "Approved",
'the_time' => current_time('mysql', 1)
));

$message = "$name Deducted your Account With $fund_amount";
if(vp_getoption("fcm") == "yes" && vp_getoption("fcm_generate") == "yes"){
sendMessage($user_id,$message);
}
  break;
  case "setbalance":
            $useramt = vp_getuser(intval($_REQUEST["userid"]), 'vp_bal', true);
 
             
	
	$updated_user = vp_updateuser(intval($_REQUEST["userid"]),'vp_bal', intval($_REQUEST["amt"]));
	
	if($updated_user == true || $updated_user == "true" || $updated_user == "1"){
	
	echo '{"status":"100"}';
}
else{
	
	echo '{"status":"200"}';
}


 $description = $_REQUEST["balance_reason"];
  if(empty($description)){
$description = $_REQUEST["balance_reason"];	
  }
 else{
$description =  "Credited By Admin"; 
 }


global $wpdb;
$name = "Admin";
$fund_amount = $_REQUEST["amt"];
$before_amount = $useramt;
$now_amount = $_REQUEST["amt"];
$user_id = $_REQUEST["userid"];
$the_time = current_time('mysql', 1);

$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $name,
'type'=> "Wallet",
'description'=> $description,
'fund_amount' => $fund_amount,
'before_amount' => $before_amount,
'now_amount' => $now_amount,
'user_id' => $user_id,
'status' => "Approved",
'the_time' => current_time('mysql', 1)
));

	 $message = "Your Balance has Been Set To ".$_REQUEST["amt"]."";
if(vp_getoption("fcm") == "yes" && vp_getoption("fcm_generate") == "yes"){
sendMessage($_REQUEST["userid"],$message);
}
  break;
  case "setplan":

      $plan = $_REQUEST["rplan"];
      $vrid = $_REQUEST["vrid"];

     $updated_user = vp_updateuser(intval($_REQUEST["userid"]),'vr_plan', $_REQUEST["rplan"]);
	 
$apikey = vp_getuser($_REQUEST["userid"],'vr_id',true);
if( empty($apikey) || strtolower($apikey) == "null" || $apikey === "0" || $apikey != $_REQUEST["vrid"] ){
$updated_user1 = vp_updateuser($_REQUEST["userid"], 'vr_id',$_REQUEST["vrid"]);
}
else{
	$updated_user1 = true;
}

     if($updated_user == true || $updated_user == "true" || $updated_user == "1" && ($updated_user1 == true || $updated_user1 == "true" || $updated_user1 == "1")){
	
	echo '{"status":"100"}';
}
else{
	
	echo '{"status":"200"}';
} 
	 $message = "Your Plan has Been Set To $plan";
if(vp_getoption("fcm") == "yes" && vp_getoption("fcm_generate") == "yes"){
sendMessage($_REQUEST["userid"],$message);
}
    break;
  case "switchto":
$admin_id = get_current_user_id();
$id = $_REQUEST["userid"];
$cookie_name = "switchto";
//$cookie_value = get_userdata($id)->user_login;
//$cookie_id = $id;
setcookie($cookie_name, $admin_id, time() + (86400 * 30), "/"); // + 30 Days

		 wp_clear_auth_cookie();
         wp_set_current_user($id);
         wp_set_auth_cookie($id, true);
//$redirect_to = $_SERVER['REQUEST_URI'];

echo '{"status":"101"}';

  break;
  case "none":

  break;

    }

  }


if(isset($_REQUEST["withdrawit"])){
			$source = $_REQUEST["source"];
			$current_withdrawal_balance = $_REQUEST["withamt"];
			$withdrawal_amount = $_REQUEST["withamt"];
			$id = get_current_user_id();
			$withdrawal_option = $_REQUEST["withto"];
			
			
		switch($source){
			case"bonus":
			if($current_withdrawal_balance > $total_bal_with){
				die('{"status":"400"}');
			}
			elseif($current_withdrawal_balance < $total_bal_with){
				die('{"status":"410"}');
			}
			
			break;
			case"wallet":
			if($current_withdrawal_balance > $bal){
				die('{"status":"400"}');
			}
			elseif(strtolower($withdrawal_option) == "wallet"){
				die('{"status":"450"}');
			}
			break;
			
			
		}
			
			$name =  get_userdata($id)->user_login;
			

			$bankdetails = $_REQUEST["bankdetails"];
			$date = current_time('mysql', 1);
			$phone = vp_getoption("vp_phone_line");
			$whatsapp = vp_getoption("vp_whatsapp");
	
			if($withdrawal_option == "wallet" && strtolower($source) == "bonus"){
				$id = get_current_user_id();
				$get_total_withdraws = vp_getuser($id, "vp_tot_withdraws",true);
				$set_total_withdraws =  $get_total_withdraws + 1;
				vp_updateuser($id, "vp_tot_withdraws", $set_total_withdraws);
				vp_updateuser($id, "vp_tot_ref_earn", 0);
				vp_updateuser($id, "vp_tot_in_ref_earn", 0);
				vp_updateuser($id, "vp_tot_in_ref_earn3", 0);
								
vp_updateuser($id, "vp_tot_dir_trans",0);
vp_updateuser($id, "vp_tot_indir_trans",0);
vp_updateuser($id, "vp_tot_indir_trans3",0);
vp_updateuser($id, "vp_tot_trans_bonus",0);
				
				$cal_wall_bal = floatval(vp_getuser($id, "vp_bal", true)) + floatval($withdrawal_amount);
				

$before_amount = vp_getuser($id, "vp_bal", true);
$now_amount = 	$cal_wall_bal ;

vp_updateuser($id, "vp_bal", $cal_wall_bal);
	
$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $name,
'type'=> "Withdrawal",
'description'=> "Bonus Withdrawal",
'fund_amount' => $withdrawal_amount,
'before_amount' => $before_amount,
'now_amount' => $now_amount,
'user_id' => $id,
'status' => "Approved",
'the_time' => current_time('mysql', 1)
));
				
			die('{"status":"100"}');
$message = "Your Withdrawal of $withdrawal_amount Has Been Approved";
if(vp_getoption("fcm") == "yes" && vp_getoption("fcm_generate") == "yes"){
sendMessage($id,$message);
}
			}
		elseif($withdrawal_option == "bank" && strtolower($source) == "bonus"){
				$id = get_current_user_id();
				$get_total_withdraws = vp_getuser($id, "vp_tot_withdraws",true);
				$set_total_withdraws =  $get_total_withdraws + 1;
				vp_updateuser($id, "vp_tot_withdraws", $set_total_withdraws);
				vp_updateuser($id, "vp_tot_ref_earn", 0);
				vp_updateuser($id, "vp_tot_in_ref_earn", 0);
				vp_updateuser($id, "vp_tot_in_ref_earn3", 0);
								
vp_updateuser($id, "vp_tot_dir_trans",0);
vp_updateuser($id, "vp_tot_indir_trans",0);
vp_updateuser($id, "vp_tot_indir_trans3",0);
vp_updateuser($id, "vp_tot_trans_bonus",0);

				$dname = get_userdata($id)->user_login;
				$demail = get_userdata($id)->user_email;
				
				
				
				
				$admin_email = vp_getoption("admin_email");
				wp_mail($admin_email, "New Withdrawal Request From ID[$id]", "New User With Id [$id] made a withdrawal request of $withdrawal_amount to [details--[$bankdetails]] on $date", $headers);
				
global $wpdb;
$name = $dname;
$description = $bankdetails;
$amount= $withdrawal_amount;
$status = 'Pending';
$user_id = $id;
$table_name = $wpdb->prefix.'vp_withdrawal';
$wpdb->insert($table_name, array(
'name'=> $name,
'description'=> $bankdetails,
'amount' => $amount,
'status' => $status,
'user_id' => $id,
'the_time' => current_time('mysql', 1)
));

$message = "Your Withdrawal of $withdrawal_amount Is Pending";
if(vp_getoption("fcm") == "yes" && vp_getoption("fcm_generate") == "yes"){
sendMessage($id,$message);
}

				die('{"status":"101"}');
				
				
			}
		elseif($withdrawal_option == "bank" && strtolower($source) == "wallet"){
				$id = get_current_user_id();
				$get_total_withdraws = vp_getuser($id, "vp_tot_withdraws",true);
				$set_total_withdraws =  $get_total_withdraws + 1;
				vp_updateuser($id, "vp_tot_withdraws", $set_total_withdraws);
				$dname = get_userdata($id)->user_login;
				$demail = get_userdata($id)->user_email;
				
$tot = $bal - 	$withdrawal_amount;
vp_updateuser($id, "vp_bal", $tot);			
				
				$admin_email = vp_getoption("admin_email");
				wp_mail($admin_email, "New Withdrawal Request From ID[$id]", "New User With Id [$id] made a withdrawal request of $withdrawal_amount to [details--[$bankdetails]] on $date", $headers);
				
global $wpdb;
$name = $dname;
$description = $bankdetails;
$amount= $withdrawal_amount;
$status = 'Pending';
$user_id = $id;
$table_name = $wpdb->prefix.'vp_withdrawal';
$wpdb->insert($table_name, array(
'name'=> $name,
'description'=> $bankdetails,
'amount' => $amount,
'status' => $status,
'user_id' => $id,
'the_time' => current_time('mysql', 1)
));

$message = "Your Withdrawal of $withdrawal_amount Is Pending";
if(vp_getoption("fcm") == "yes" && vp_getoption("fcm_generate") == "yes"){
sendMessage($id,$message);
}

				die('{"status":"101"}');
				
				
			}
	
			
			
}


if(isset($_REQUEST["process_with"])){
	
	global $wpdb;
	
	$dothis = $_REQUEST["process_with"];
	$forthis = $_REQUEST["with_user_id"];
	$amount = $_REQUEST["with_amount"];
	$row = $_REQUEST["the_row_id"];
	
	if($dothis == "Approve"){
		$update = "Approved";
	}
	elseif($dothis == "Fail"){
		$update = "failed";
		$cur = vp_getuser($forthis,'vp_bal',true);
		$tot = $cur + $amount;
		vp_updateuser($forthis,'vp_bal',$tot);
	}
	else{
		$update = "Processing";
	}
	
$data = [ 'status' => $update ];
$where = [ 'id' => $row ];
$updated = $wpdb->update( $wpdb->prefix.'vp_withdrawal', $data, $where);

$message = "Withdrawal Is $update";
if(vp_getoption("fcm") == "yes" && vp_getoption("fcm_generate") == "yes"){
sendMessage($forthis,$message);
}


if($updated !== false){
echo'{"status":"100"}';
}
else{
echo'{"status":"200"}';	
}

}

if(isset($_REQUEST["airtime_control"])){
	$vtuvalue = $_REQUEST["vtuvalue"];
	$sharevalue = $_REQUEST["sharevalue"];
	$awufvalue = $_REQUEST["awufvalue"];

vp_updateoption("vtucontrol",$vtuvalue);
vp_updateoption("sharecontrol",$sharevalue);
vp_updateoption("awufcontrol",$awufvalue);

	echo '{"status":"100"}';	
}

if(isset($_REQUEST["data_control"])){
	$smevalue = $_REQUEST["smevalue"];
	$directvalue = $_REQUEST["directvalue"];
	$corporatevalue = $_REQUEST["corporatevalue"];

vp_updateoption("smecontrol",$smevalue);
vp_updateoption("directcontrol",$directvalue);
vp_updateoption("corporatecontrol",$corporatevalue);

	echo '{"status":"100"}';	
}

if(isset($_REQUEST["set_control"])){
	$set_airtime = $_REQUEST["setairtime"];
	$set_data = $_REQUEST["setdata"];
	$set_cable = $_REQUEST["setcable"];
	$set_bill = $_REQUEST["setbill"];

vp_updateoption("setairtime",$set_airtime);
vp_updateoption("setdata",$set_data);
vp_updateoption("setcable",$set_cable);
vp_updateoption("setbill",$set_bill);

do_action("set_control_post");

	echo '{"status":"100"}';	
}

if(isset($_REQUEST['setmlm'])){
		
vp_updateoption("vp_min_withdrawal",$_REQUEST['minwith']);
vp_updateoption("vp_trans_min", $_REQUEST['mintrans']);
vp_updateoption("discount_method", $_REQUEST['discountmethod']);

echo '{"status":"100"}';	
}
	
	
if(isset($_REQUEST["paywall"])){
	
$id = get_current_user_id();
$bal = vp_getuser($id, "vp_bal", true);
$level_name = $_REQUEST["level_name"];
$level_id = $_REQUEST["level_id"];

$user_data = get_userdata($id);
$pname = $user_data->user_login;
$pdescription = "Upgraded To $level_name";

global $wpdb;
$table_name = $wpdb->prefix."vp_levels";
$data = $wpdb->get_results("SELECT * FROM  $table_name WHERE id = $level_id");

$level_amount = $data[0]->upgrade;
	
if($bal >= $level_amount){
vp_updateuser($id, 'vr_plan', $level_name);

$apikey = vp_getuser($id,'vr_id',true);
if( empty($apikey) || strtolower($apikey) == "null" || $apikey === "0" ){
vp_updateuser($id, 'vr_id', uniqid());
}

$tot = $bal - $level_amount;
vp_updateuser($id, "vp_bal", $tot);


$message = "You'be Been Upgraded To A $level_name";
if(vp_getoption("fcm") == "yes" && vp_getoption("fcm_generate") == "yes"){
sendMessage($id,$message);
}

//notify user about the update
$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $pname,
'type'=> "Wallet",
'description'=> $pdescription,
'fund_amount' => $level_amount,
'before_amount' => $bal,
'now_amount' => $tot,
'user_id' => $id,
'status' => "Approved",
'the_time' => current_time('mysql', 1)
));



if(is_plugin_active("vpmlm/vpmlm.php")){
/*	
	////////////DIRECT//////////////////
	$my_d_ref = vp_getuser($id, "vp_who_ref", true); //get my ref id
	$dir_ref_bonus = vp_getoption("vp_first_level_bonus"); //get bonus amount for my direct ref
	
	

	
	/////////////////INDIR/////////////
	
	//credit grand ref
	$my_ind_ref = vp_getuser($my_d_ref, "vp_who_ref", true); //who ref my ref
	$indir_ref_bonus = vp_getoption("vp_second_level_bonus"); //get bonus amount for who ref my ref
		
		
	$cur_indir_bonus = vp_getuser($my_ind_ref, "vp_tot_in_ref_earn",true); // amt of my indirect ref like me
	$credit_indir_ref = intval($cur_indir_bonus) + intval($indir_ref_bonus); //cal total of bonus. current bal plus bonus
	vp_updateuser($my_ind_ref, "vp_tot_in_ref_earn", $credit_indir_ref); //add bonus to my ref
	
	//credit my great grand ref
*/
	
	
if(strtolower($level_name) != "custome"  && isset($data) && isset($data[0]->upgrade)){
$my_dir_ref = vp_getuser($id, "vp_who_ref", true);//get direct refer id

$total_level = $data[0]->total_level;

$the_user = $my_dir_ref;


for($lev = 1; $lev <= $total_level; $lev++){

$current_level = "level_".$lev."_upgrade";
$discount = floatval($data[0]->$current_level);

$give_away = (intval($data[0]->upgrade) * $discount) / 100;


if(vp_getuser($the_user,"vr_plan",true) != "custome" && $lev == 1 && $the_user != "0" && $the_user != "false"){

	$cur_dir_bonus = vp_getuser($the_user, "vp_tot_ref_earn",true);
	$credit_dir_ref = intval($cur_dir_bonus) + intval($give_away); //cal total of bonus. current bal plus bonus
	vp_updateuser($the_user, "vp_tot_ref_earn", $credit_dir_ref); //add bonus to my ref
	
}
elseif(vp_getuser($the_user,"vr_plan",true) != "custome" && $lev == 2 && $the_user != "0" && $the_user != "false"){
$cur_indir_bonus = vp_getuser($the_user, "vp_tot_in_ref_earn",true); // amt of my indirect ref like me
$credit_indir_ref = intval($cur_indir_bonus) + intval($give_away); //cal total of bonus. current bal plus bonus
vp_updateuser($the_user, "vp_tot_in_ref_earn", $credit_indir_ref); //add bonus to my ref
}
elseif(vp_getuser($the_user,"vr_plan",true) != "custome" && $lev == 3  && $the_user != "0" && $the_user != "false"){
$curr_indir_trans_bonus3 = vp_getuser($the_user, "vp_tot_in_ref_earn3", true);
$add_to_indirect_transb3 = intval($curr_indir_trans_bonus3) + intval($give_away);
vp_updateuser($the_user, "vp_tot_in_ref_earn3", $add_to_indirect_transb3);
}
elseif(vp_getuser($the_user,"vr_plan",true) != "custome" && $lev != 3 && $lev != 2 && $lev != 1  && $the_user != "0" && $the_user != "false"){
$cur_indir_bonus3 = vp_getuser($the_user, "vp_tot_in_ref_earn3",true); // amt of my gg ref like me
$credit_indir_ref3 = intval($cur_indir_bonus3) + intval($give_away); //cal total of bonus. current bal plus bonus
vp_updateuser($the_user, "vp_tot_in_ref_earn3", $credit_indir_ref3); //add bonus to my gg
}
else{
	$lev = 90000000000;
}
	
	
$next_user = vp_getuser($the_user, "vp_who_ref", true);

$the_user = $next_user;
	
}


}

}


die('100');

}
else{
die('101');
		
	}



}

if(isset($_REQUEST["set_pin"])){
	$id = get_current_user_id();
	$pin = $_REQUEST["pin"];

if(strlen($pin) >= 4){
	$verify_pin = preg_match("/[^0-9]/",$pin);
	if($verify_pin === 0){
		$verify_zero = preg_match("/^0\d+$/",$pin);
		if($verify_zero === 0){
vp_updateuser($id,"vp_pin",$pin);
vp_updateuser($id,"vp_pin_set","yes");

$obj = new stdClass;
$obj->code = "100";
$obj->message = "Pin Set To $pin";
die(json_encode($obj));
		}
		else{
$obj = new stdClass;
$obj->code = "200";
$obj->message = "Do Not Start Your Pin With Zero";
die(json_encode($obj));
		}
	}
	else{
$obj = new stdClass;
$obj->code = "200";
$obj->message = "Only Numbers Are Allowed For Pin";
die(json_encode($obj));
		}


}
else{
$obj = new stdClass;
$obj->code = "200";
$obj->message = "Pin Must Be At Least 4 Digits";
die(json_encode($obj));
		}
	
}

if(isset($_REQUEST["flush_transactions"])){
	$flush = $_REQUEST["flush_transactions"];
	
switch($flush){
	case"success":
$num = 0;
global $wpdb;
$table_name = $wpdb->prefix.'sairtime';
$array = $wpdb->get_results("SELECT * FROM $table_name");
foreach($array as $arr){
if(!empty($arr)){
$num = $num+1;
$wpdb->delete($table_name , array( 'id' => $arr->id ));

}
}

$table_name = $wpdb->prefix.'sdata';
$array = $wpdb->get_results("SELECT * FROM $table_name");
foreach($array as $arr){
if(!empty($arr)){
$num = $num+1;
$wpdb->delete($table_name , array( 'id' => $arr->id ));

}
}

if(is_plugin_active("vpmlm/vpmlm.php")){
	
$table_name = $wpdb->prefix.'sbill';
$array = $wpdb->get_results("SELECT * FROM $table_name");
foreach($array as $arr){
if(!empty($arr)){
$num = $num+1;
$wpdb->delete($table_name , array( 'id' => $arr->id ));

}
}

$table_name = $wpdb->prefix.'scable';
$array = $wpdb->get_results("SELECT * FROM $table_name");
foreach($array as $arr){
if(!empty($arr)){
$num = $num+1;
$wpdb->delete($table_name , array( 'id' => $arr->id ));

}
}	
}


if(is_plugin_active("vpsms/vpsms.php")){
	
$table_name = $wpdb->prefix.'ssms';
$array = $wpdb->get_results("SELECT * FROM $table_name");
foreach($array as $arr){
if(!empty($arr)){
$num = $num+1;
$wpdb->delete($table_name , array( 'id' => $arr->id ));

}
}

}

if(is_plugin_active("vpcards/vpcards.php")){
	
$table_name = $wpdb->prefix.'scards';
$array = $wpdb->get_results("SELECT * FROM $table_name");
foreach($array as $arr){
if(!empty($arr)){
$num = $num+1;
$wpdb->delete($table_name , array( 'id' => $arr->id ));

}
}

}

if(is_plugin_active("vpepin/vpepin.php")){
	
$table_name = $wpdb->prefix.'sepins';
$array = $wpdb->get_results("SELECT * FROM $table_name");
foreach($array as $arr){
if(!empty($arr)){
$num = $num+1;
$wpdb->delete($table_name , array( 'id' => $arr->id ));

}
}

}

$obj = new stdClass;
$obj->code = "100";
$obj->message = "$num Failed Transactions Deleted";
die(json_encode($obj));
break;
case"failed":
$num = 0;


if(is_plugin_active("vpcards/vpcards.php")){
	
$table_name = $wpdb->prefix.'fcards';
$array = $wpdb->get_results("SELECT * FROM $table_name");
foreach($array as $arr){
if(!empty($arr)){
$num = $num+1;
$wpdb->delete($table_name , array( 'id' => $arr->id ));

}
}

}

if(is_plugin_active("vpepin/vpepin.php")){
	
$table_name = $wpdb->prefix.'fepins';
$array = $wpdb->get_results("SELECT * FROM $table_name");
foreach($array as $arr){
if(!empty($arr)){
$num = $num+1;
$wpdb->delete($table_name , array( 'id' => $arr->id ));

}
}

}


$obj = new stdClass;
$obj->code = "100";
$obj->message = "$num Failed Transactions Deleted";
die(json_encode($obj));
break;

}

}


if(isset($_REQUEST["convert_it"])){
	$conversion = $_REQUEST["conversion"];
	$network = $_REQUEST["network"];
	$payto = $_REQUEST["pay_to"];
	$paycharge = $_REQUEST["pay_charge"];
	$amount = $_REQUEST["amount"];
	$get = $_REQUEST["pay_get"];
	$from = $_REQUEST["from"];

if($conversion == "wallet"){	
	$id = get_current_user_id();
	$name = get_userdata($id)->user_login;
	$description = "To Pay The Sum Of #$amount For #$get Conversion Rate Charged @ $paycharge% From $from";
	$fund_amount = $get;
	$before_amount = vp_getuser($id, "vp_bal", true);
	$now_amount = $before_amount + $get;
	
	
$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $name,
'type'=> "Airtime_To_Wallet",
'description'=> $description,
'fund_amount' => $fund_amount,
'before_amount' => $before_amount,
'now_amount' => $now_amount,
'user_id' => $id,
'status' => "Pending",
'the_time' => current_time('mysql', 1)
));


$message = "Airtime To Wallet Conversion Is Pending";
if(vp_getoption("fcm") == "yes" && vp_getoption("fcm_generate") == "yes"){
sendMessage($id,$message);
}

die("100");
}


if($conversion == "cash"){	
	$id = get_current_user_id();
	$name = get_userdata($id)->user_login;
	$bank = $_REQUEST["bank"];
	$description = "To Pay The Sum Of #$amount For #$get Conversion Rate Charged @ $paycharge% From $from To Details $bank";
	$fund_amount = $get;
	$before_amount = vp_getuser($id, "vp_bal", true);
	$now_amount = "Not Applicable";

	
	
$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $name,
'type'=> "Airtime_To_Cash",
'description'=> $description,
'fund_amount' => $fund_amount,
'before_amount' => $before_amount,
'now_amount' => $now_amount,
'user_id' => $id,
'status' => "Pending",
'the_time' => current_time('mysql', 1)
));

$message = "Airtime To Cash Conversion Is Pending";
if(vp_getoption("fcm") == "yes" && vp_getoption("fcm_generate") == "yes"){
sendMessage($id,$message);
}


die("100");
}

}


if(isset($_REQUEST['convert_to'])){
	$convert_to = $_REQUEST["convert_to"];
	$convert_id = $_REQUEST["convert_id"];
	$convert_user_id = $_REQUEST["convert_user_id"];
	$convert_amount = $_REQUEST["convert_amount"];
	$convert_type = $_REQUEST["convert_type"];
	

		global $wpdb;
if(strtolower($convert_to) == "approve"){
		$update = "Approved";
	}
	else{
		$update = "Failed";
	}
	
$data = [ 'status' => $update ];
$where = [ 'id' => $convert_id ];
$updated = $wpdb->update( $wpdb->prefix.'vp_wallet', $data, $where);

$before_amount = vp_getuser($convert_user_id,"vp_bal",true);
$now_amount = $before_amount + $convert_amount;

vp_updateuser($convert_user_id, "vp_bal", $now_amount);

$message = "Conversion Is $update";
if(vp_getoption("fcm") == "yes" && vp_getoption("fcm_generate") == "yes"){
sendMessage($convert_user_id,$message);
}


if($updated !== false){
die("100");
}
else{
die("Error!!!");
}

	
	
}

if(isset($_REQUEST["test_fcm"])){
    $id = $_REQUEST["id"];
    $message = "VTUPRESS FCM TEST SUCCESSFUL!";
echo sendMessage($id,$message);
}



if(isset($_REQUEST["tune_status"])){
global $wpdb;

$id = $_REQUEST["user_id"];
$sid = $_REQUEST["service_id"];
$table = $_REQUEST["table"];
$amount = $_REQUEST["amount"];
$description = $_REQUEST["description"];
$name = get_userdata($id)->user_login;

switch($_REQUEST["status"]){
		case"reverse":

//set status to failed
$data = [ 'status' => 'Failed' ];
$where = [ 'id' => $sid ];
$updated = $wpdb->update( $wpdb->prefix.$table, $data, $where);

//credit the user
$before_amount = vp_getuser($id,"vp_bal",true);
$now_amount = $before_amount + $amount;

vp_updateuser($id, "vp_bal", $now_amount);


//notify user about the update
$table_name = $wpdb->prefix.'vp_wallet';
$wpdb->insert($table_name, array(
'name'=> $name,
'type'=> "Wallet",
'description'=> $description,
'fund_amount' => $amount,
'before_amount' => $before_amount,
'now_amount' => $now_amount,
'user_id' => $id,
'status' => "Approved",
'the_time' => current_time('mysql', 1)
));


		break;
		case"success":
		
//set status to failed
$data = [ 'status' => 'Successful' ];
$where = [ 'id' => $sid ];
$updated = $wpdb->update( $wpdb->prefix.$table, $data, $where);

		
		break;	
}
	

die("100");
}



?>