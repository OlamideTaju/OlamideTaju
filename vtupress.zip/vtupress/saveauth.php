<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH ."wp-load.php");
include_once(ABSPATH.'wp-admin/includes/plugin.php');
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');
$vpdebug = vp_getoption("vpdebug");
if(isset($_POST)){

do_action("gateway_post");

do_action("gateway_post1");


///////////////////////////////AIRTIME UPDATE////////////////////////////////
vp_updateoption("sme_visible_networks",$_REQUEST["sme_visible_networks"]);
vp_updateoption("corporate_visible_networks",$_REQUEST["corporate_visible_networks"]);
vp_updateoption("direct_visible_networks",$_REQUEST["direct_visible_networks"]);

vp_updateoption("cable_charge",$_REQUEST["cable_charge"]);
vp_updateoption("bill_charge",$_REQUEST["bill_charge"]);

vp_updateoption("airtimebaseurl",$_REQUEST["airtimebaseurl"]);
vp_updateoption("airtimeendpoint",$_REQUEST["airtimeendpoint"]);
vp_updateoption("airtimerequest",$_REQUEST["airtimerequest"]);
vp_updateoption("airtimerequesttext",$_REQUEST["airtimerequesttext"]);
vp_updateoption("airtimesuccesscode",$_REQUEST["airtimesuccesscode"]);
vp_updateoption("airtimesuccessvalue",$_REQUEST["airtimesuccessvalue"]);
vp_updateoption("airtimesuccessvalue2",$_REQUEST["airtimesuccessvalue2"]);

vp_updateoption("arequest_id",$_REQUEST["arequest_id"]);

for($cheaders=1; $cheaders<=1; $cheaders++){
vp_updateoption("airtimehead".$cheaders,$_REQUEST["airtimehead".$cheaders]);
vp_updateoption("airtimevalue".$cheaders,$_REQUEST["airtimevalue".$cheaders]);
}

vp_updateoption("airtimeaddpost",$_REQUEST["airtimeaddpost"]);


for($cpost=1; $cpost<=5; $cpost++){
vp_updateoption("airtimepostdata".$cpost,$_REQUEST["airtimepostdata".$cpost]);
vp_updateoption("airtimepostvalue".$cpost,$_REQUEST["airtimepostvalue".$cpost]);
}

vp_updateoption("airtimeamountattribute",$_REQUEST["airtimeamountattribute"]);
vp_updateoption("airtimephoneattribute",$_REQUEST["airtimephoneattribute"]);
vp_updateoption("airtimenetworkattribute",$_REQUEST["airtimenetworkattribute"]);
vp_updateoption("airtimemtn",$_REQUEST["airtimemtn"]);
vp_updateoption("airtimeglo",$_REQUEST["airtimeglo"]);
vp_updateoption("airtime9mobile",$_REQUEST["airtime9mobile"]);
vp_updateoption("airtimeairtel",$_REQUEST["airtimeairtel"]);

/////////////////////////////////////////////////////////////////////////////



///////////////////////////////SHARED AIRTIME UPDATE////////////////////////////////
vp_updateoption("sairtimebaseurl",$_REQUEST["sairtimebaseurl"]);
vp_updateoption("sairtimeendpoint",$_REQUEST["sairtimeendpoint"]);
vp_updateoption("sairtimerequest",$_REQUEST["sairtimerequest"]);
vp_updateoption("sairtimerequesttext",$_REQUEST["sairtimerequesttext"]);
vp_updateoption("sairtimesuccesscode",$_REQUEST["sairtimesuccesscode"]);
vp_updateoption("sairtimesuccessvalue",$_REQUEST["sairtimesuccessvalue"]);
vp_updateoption("sairtimesuccessvalue2",$_REQUEST["sairtimesuccessvalue2"]);

vp_updateoption("sarequest_id",$_REQUEST["sarequest_id"]);

for($cheaders=1; $cheaders<=1; $cheaders++){
vp_updateoption("sairtimehead".$cheaders,$_REQUEST["sairtimehead".$cheaders]);
vp_updateoption("sairtimevalue".$cheaders,$_REQUEST["sairtimevalue".$cheaders]);
}

vp_updateoption("sairtimeaddpost",$_REQUEST["sairtimeaddpost"]);


for($cpost=1; $cpost<=5; $cpost++){
vp_updateoption("sairtimepostdata".$cpost,$_REQUEST["sairtimepostdata".$cpost]);
vp_updateoption("sairtimepostvalue".$cpost,$_REQUEST["sairtimepostvalue".$cpost]);
}

vp_updateoption("sairtimeamountattribute",$_REQUEST["sairtimeamountattribute"]);
vp_updateoption("sairtimephoneattribute",$_REQUEST["sairtimephoneattribute"]);
vp_updateoption("sairtimenetworkattribute",$_REQUEST["sairtimenetworkattribute"]);
vp_updateoption("sairtimemtn",$_REQUEST["sairtimemtn"]);
vp_updateoption("sairtimeglo",$_REQUEST["sairtimeglo"]);
vp_updateoption("sairtime9mobile",$_REQUEST["sairtime9mobile"]);
vp_updateoption("sairtimeairtel",$_REQUEST["sairtimeairtel"]);

/////////////////////////////////////////////////////////////////////////////



///////////////////////////////AWUF AIRTIME UPDATE////////////////////////////////
vp_updateoption("wairtimebaseurl",$_REQUEST["wairtimebaseurl"]);
vp_updateoption("wairtimeendpoint",$_REQUEST["wairtimeendpoint"]);
vp_updateoption("wairtimerequest",$_REQUEST["wairtimerequest"]);
vp_updateoption("wairtimerequesttext",$_REQUEST["wairtimerequesttext"]);
vp_updateoption("wairtimesuccesscode",$_REQUEST["wairtimesuccesscode"]);
vp_updateoption("wairtimesuccessvalue",$_REQUEST["wairtimesuccessvalue"]);
vp_updateoption("wairtimesuccessvalue2",$_REQUEST["wairtimesuccessvalue2"]);

vp_updateoption("warequest_id",$_REQUEST["warequest_id"]);

for($cheaders=1; $cheaders<=1; $cheaders++){
vp_updateoption("wairtimehead".$cheaders,$_REQUEST["wairtimehead".$cheaders]);
vp_updateoption("wairtimevalue".$cheaders,$_REQUEST["wairtimevalue".$cheaders]);
}

vp_updateoption("wairtimeaddpost",$_REQUEST["wairtimeaddpost"]);


for($cpost=1; $cpost<=5; $cpost++){
vp_updateoption("wairtimepostdata".$cpost,$_REQUEST["wairtimepostdata".$cpost]);
vp_updateoption("wairtimepostvalue".$cpost,$_REQUEST["wairtimepostvalue".$cpost]);
}

vp_updateoption("wairtimeamountattribute",$_REQUEST["wairtimeamountattribute"]);
vp_updateoption("wairtimephoneattribute",$_REQUEST["wairtimephoneattribute"]);
vp_updateoption("wairtimenetworkattribute",$_REQUEST["wairtimenetworkattribute"]);
vp_updateoption("wairtimemtn",$_REQUEST["wairtimemtn"]);
vp_updateoption("wairtimeglo",$_REQUEST["wairtimeglo"]);
vp_updateoption("wairtime9mobile",$_REQUEST["wairtime9mobile"]);
vp_updateoption("wairtimeairtel",$_REQUEST["wairtimeairtel"]);

/////////////////////////////////////////////////////////////////////////////


///////////////////////////////VTU DATA UPDATE////////////////////////////////

vp_updateoption("databaseurl",$_REQUEST["databaseurl"]);
vp_updateoption("dataendpoint",$_REQUEST["dataendpoint"]);
vp_updateoption("datarequest",$_REQUEST["datarequest"]);
vp_updateoption("datarequesttext",$_REQUEST["datarequesttext"]);
vp_updateoption("datasuccesscode",$_REQUEST["datasuccesscode"]);
vp_updateoption("datasuccessvalue",$_REQUEST["datasuccessvalue"]);
vp_updateoption("datasuccessvalue2",$_REQUEST["datasuccessvalue2"]);

vp_updateoption("request_id",$_REQUEST["request_id"]);


for($cheaders=1; $cheaders<=1; $cheaders++){
vp_updateoption("datahead".$cheaders,$_REQUEST["datahead".$cheaders]);
vp_updateoption("datavalue".$cheaders,$_REQUEST["datavalue".$cheaders]);
}


vp_updateoption("dataaddpost",$_REQUEST["dataaddpost"]);

for($cpost=1; $cpost<=5; $cpost++){
vp_updateoption("datapostdata".$cpost,$_REQUEST["datapostdata".$cpost]);
vp_updateoption("datapostvalue".$cpost,$_REQUEST["datapostvalue".$cpost]);
}

vp_updateoption("dataamountattribute",$_REQUEST["dataamountattribute"]);
vp_updateoption("cvariationattr",$_REQUEST["cvariationattr"]);
vp_updateoption("dataphoneattribute",$_REQUEST["dataphoneattribute"]);
vp_updateoption("datanetworkattribute",$_REQUEST["datanetworkattribute"]);

for($i=0; $i<=10; $i++){
vp_updateoption("cdata".$i,$_REQUEST["cdata".$i]);
vp_updateoption("cdatan".$i,$_REQUEST["cdatan".$i]);
vp_updateoption("cdatap".$i,$_REQUEST["cdatap".$i]);

}

for($i=0; $i<=10; $i++){
vp_updateoption("acdata".$i,$_REQUEST["acdata".$i]);
vp_updateoption("acdatan".$i,$_REQUEST["acdatan".$i]);
vp_updateoption("acdatap".$i,$_REQUEST["acdatap".$i]);
}

for($i=0; $i<=10; $i++){
vp_updateoption("9cdata".$i,$_REQUEST["9cdata".$i]);
vp_updateoption("9cdatan".$i,$_REQUEST["9cdatan".$i]);
vp_updateoption("9cdatap".$i,$_REQUEST["9cdatap".$i]);
}

for($i=0; $i<=10; $i++){
vp_updateoption("gcdata".$i,$_REQUEST["gcdata".$i]);
vp_updateoption("gcdatan".$i,$_REQUEST["gcdatan".$i]);
vp_updateoption("gcdatap".$i,$_REQUEST["gcdatap".$i]);
}



vp_updateoption("datamtn",$_REQUEST["datamtn"]);
vp_updateoption("dataglo",$_REQUEST["dataglo"]);
vp_updateoption("data9mobile",$_REQUEST["data9mobile"]);
vp_updateoption("dataairtel",$_REQUEST["dataairtel"]);
/////////////////////////////////////////////////////////////////////////////



///////////////////////////////DIRECT DATA UPDATE////////////////////////////////

vp_updateoption("rdatabaseurl",$_REQUEST["rdatabaseurl"]);
vp_updateoption("rdataendpoint",$_REQUEST["rdataendpoint"]);
vp_updateoption("rdatarequest",$_REQUEST["rdatarequest"]);
vp_updateoption("rdatarequesttext",$_REQUEST["rdatarequesttext"]);
vp_updateoption("rdatasuccesscode",$_REQUEST["rdatasuccesscode"]);
vp_updateoption("rdatasuccessvalue",$_REQUEST["rdatasuccessvalue"]);
vp_updateoption("rdatasuccessvalue2",$_REQUEST["rdatasuccessvalue2"]);

vp_updateoption("rrequest_id",$_REQUEST["rrequest_id"]);


for($cheaders=1; $cheaders<=1; $cheaders++){
vp_updateoption("rdatahead".$cheaders,$_REQUEST["rdatahead".$cheaders]);
vp_updateoption("rdatavalue".$cheaders,$_REQUEST["rdatavalue".$cheaders]);
}


vp_updateoption("rdataaddpost",$_REQUEST["rdataaddpost"]);

for($cpost=1; $cpost<=5; $cpost++){
vp_updateoption("rdatapostdata".$cpost,$_REQUEST["rdatapostdata".$cpost]);
vp_updateoption("rdatapostvalue".$cpost,$_REQUEST["rdatapostvalue".$cpost]);
}

vp_updateoption("rdataamountattribute",$_REQUEST["rdataamountattribute"]);
vp_updateoption("rcvariationattr",$_REQUEST["rcvariationattr"]);
vp_updateoption("rdataphoneattribute",$_REQUEST["rdataphoneattribute"]);
vp_updateoption("rdatanetworkattribute",$_REQUEST["rdatanetworkattribute"]);

for($i=0; $i<=10; $i++){
vp_updateoption("rcdata".$i,$_REQUEST["rcdata".$i]);
vp_updateoption("rcdatan".$i,$_REQUEST["rcdatan".$i]);
vp_updateoption("rcdatap".$i,$_REQUEST["rcdatap".$i]);
}

for($i=0; $i<=10; $i++){
vp_updateoption("racdata".$i,$_REQUEST["racdata".$i]);
vp_updateoption("racdatan".$i,$_REQUEST["racdatan".$i]);
vp_updateoption("racdatap".$i,$_REQUEST["racdatap".$i]);
}

for($i=0; $i<=10; $i++){
vp_updateoption("r9cdata".$i,$_REQUEST["r9cdata".$i]);
vp_updateoption("r9cdatan".$i,$_REQUEST["r9cdatan".$i]);
vp_updateoption("r9cdatap".$i,$_REQUEST["r9cdatap".$i]);
}

for($i=0; $i<=10; $i++){
vp_updateoption("rgcdata".$i,$_REQUEST["rgcdata".$i]);
vp_updateoption("rgcdatan".$i,$_REQUEST["rgcdatan".$i]);
vp_updateoption("rgcdatap".$i,$_REQUEST["rgcdatap".$i]);
}


vp_updateoption("rdatamtn",$_REQUEST["rdatamtn"]);
vp_updateoption("rdataglo",$_REQUEST["rdataglo"]);
vp_updateoption("rdata9mobile",$_REQUEST["rdata9mobile"]);
vp_updateoption("rdataairtel",$_REQUEST["rdataairtel"]);

/////////////////////////////////////////////////////////////////////////////





///////////////////////////////CORPORATE DATA UPDATE////////////////////////////////

vp_updateoption("r2databaseurl",$_REQUEST["r2databaseurl"]);
vp_updateoption("r2dataendpoint",$_REQUEST["r2dataendpoint"]);
vp_updateoption("r2datarequest",$_REQUEST["r2datarequest"]);
vp_updateoption("r2datarequesttext",$_REQUEST["r2datarequesttext"]);
vp_updateoption("r2datasuccesscode",$_REQUEST["r2datasuccesscode"]);
vp_updateoption("r2datasuccessvalue",$_REQUEST["r2datasuccessvalue"]);
vp_updateoption("r2datasuccessvalue2",$_REQUEST["r2datasuccessvalue2"]);

vp_updateoption("r2request_id",$_REQUEST["r2request_id"]);


for($cheaders=1; $cheaders<=1; $cheaders++){
vp_updateoption("r2datahead".$cheaders,$_REQUEST["r2datahead".$cheaders]);
vp_updateoption("r2datavalue".$cheaders,$_REQUEST["r2datavalue".$cheaders]);
}


vp_updateoption("r2dataaddpost",$_REQUEST["r2dataaddpost"]);

for($cpost=1; $cpost<=5; $cpost++){
vp_updateoption("r2datapostdata".$cpost,$_REQUEST["r2datapostdata".$cpost]);
vp_updateoption("r2datapostvalue".$cpost,$_REQUEST["r2datapostvalue".$cpost]);
}

vp_updateoption("r2dataamountattribute",$_REQUEST["r2dataamountattribute"]);
vp_updateoption("r2cvariationattr",$_REQUEST["r2cvariationattr"]);
vp_updateoption("r2dataphoneattribute",$_REQUEST["r2dataphoneattribute"]);
vp_updateoption("r2datanetworkattribute",$_REQUEST["r2datanetworkattribute"]);

for($i=0; $i<=10; $i++){
vp_updateoption("r2cdata".$i,$_REQUEST["r2cdata".$i]);
vp_updateoption("r2cdatan".$i,$_REQUEST["r2cdatan".$i]);
vp_updateoption("r2cdatap".$i,$_REQUEST["r2cdatap".$i]);
}

for($i=0; $i<=10; $i++){
vp_updateoption("r2acdata".$i,$_REQUEST["r2acdata".$i]);
vp_updateoption("r2acdatan".$i,$_REQUEST["r2acdatan".$i]);
vp_updateoption("r2acdatap".$i,$_REQUEST["r2acdatap".$i]);
}

for($i=0; $i<=10; $i++){
vp_updateoption("r29cdata".$i,$_REQUEST["r29cdata".$i]);
vp_updateoption("r29cdatan".$i,$_REQUEST["r29cdatan".$i]);
vp_updateoption("r29cdatap".$i,$_REQUEST["r29cdatap".$i]);
}

for($i=0; $i<=10; $i++){
vp_updateoption("r2gcdata".$i,$_REQUEST["r2gcdata".$i]);
vp_updateoption("r2gcdatan".$i,$_REQUEST["r2gcdatan".$i]);
vp_updateoption("r2gcdatap".$i,$_REQUEST["r2gcdatap".$i]);
}

vp_updateoption("r2datamtn",$_REQUEST["r2datamtn"]);
vp_updateoption("r2dataglo",$_REQUEST["r2dataglo"]);
vp_updateoption("r2data9mobile",$_REQUEST["r2data9mobile"]);
vp_updateoption("r2dataairtel",$_REQUEST["r2dataairtel"]);

/////////////////////////////////////////////////////////////

vp_updateoption("sme_mtn_balance",$_REQUEST["sme_mtn_balance"]);
vp_updateoption("sme_airtel_balance",$_REQUEST["sme_airtel_balance"]);
vp_updateoption("sme_glo_balance",$_REQUEST["sme_glo_balance"]);
vp_updateoption("sme_9mobile_balance",$_REQUEST["sme_9mobile_balance"]);


vp_updateoption("corporate_mtn_balance",$_REQUEST["corporate_mtn_balance"]);
vp_updateoption("corporate_airtel_balance",$_REQUEST["corporate_airtel_balance"]);
vp_updateoption("corporate_glo_balance",$_REQUEST["corporate_glo_balance"]);
vp_updateoption("corporate_9mobile_balance",$_REQUEST["corporate_9mobile_balance"]);


vp_updateoption("direct_mtn_balance",$_REQUEST["direct_mtn_balance"]);
vp_updateoption("direct_airtel_balance",$_REQUEST["direct_airtel_balance"]);
vp_updateoption("direct_glo_balance",$_REQUEST["direct_glo_balance"]);
vp_updateoption("direct_9mobile_balance",$_REQUEST["direct_9mobile_balance"]);

/////////////////////////////////////////////////////////////////////////////





////////////////////////////////////////////////CABLE////////////////////////////////////
vp_updateoption("cablebaseurl",$_REQUEST["cablebaseurl"]);
vp_updateoption("cableendpoint",$_REQUEST["cableendpoint"]);
vp_updateoption("cablerequest",$_REQUEST["cablerequest"]);
vp_updateoption("cablerequesttext",$_REQUEST["cablerequesttext"]);
vp_updateoption("cablesuccesscode",$_REQUEST["cablesuccesscode"]);
vp_updateoption("cablesuccessvalue",$_REQUEST["cablesuccessvalue"]);
vp_updateoption("cablesuccessvalue2",$_REQUEST["cablesuccessvalue2"]);

vp_updateoption("crequest_id",$_REQUEST["crequest_id"]);

for($cheaders=1; $cheaders<=1; $cheaders++){
vp_updateoption("cablehead".$cheaders,$_REQUEST["cablehead".$cheaders]);
vp_updateoption("cablevalue".$cheaders,$_REQUEST["cablevalue".$cheaders]);
}


vp_updateoption("cableaddpost",$_REQUEST["cableaddpost"]);

for($cpost=1; $cpost<=5; $cpost++){
vp_updateoption("cablepostdata".$cpost,$_REQUEST["cablepostdata".$cpost]);
vp_updateoption("cablepostvalue".$cpost,$_REQUEST["cablepostvalue".$cpost]);
}


vp_updateoption("ccvariationattr",$_REQUEST["ccvariationattr"]);
vp_updateoption("ctypeattr",$_REQUEST["ctypeattr"]);
vp_updateoption("ciucattr",$_REQUEST["ciucattr"]);


for($j=0; $j<=3; $j++){
vp_updateoption("cablename".$j,$_REQUEST["cablename".$j]);
vp_updateoption("cableid".$j,$_REQUEST["cableid".$j]);
}
for($i=0; $i<=35; $i++){
vp_updateoption("ccable".$i,$_REQUEST["ccable".$i]);
vp_updateoption("ccablen".$i,$_REQUEST["ccablen".$i]);
vp_updateoption("ccablep".$i,$_REQUEST["ccablep".$i]);
}


//////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////BILL////////////////////////////////////
vp_updateoption("billbaseurl",$_REQUEST["billbaseurl"]);
vp_updateoption("billendpoint",$_REQUEST["billendpoint"]);
vp_updateoption("billrequest",$_REQUEST["billrequest"]);
vp_updateoption("billrequesttext",$_REQUEST["billrequesttext"]);
vp_updateoption("billsuccesscode",$_REQUEST["billsuccesscode"]);
vp_updateoption("billsuccessvalue",$_REQUEST["billsuccessvalue"]);
vp_updateoption("billsuccessvalue2",$_REQUEST["billsuccessvalue2"]);
vp_updateoption("metertoken",$_REQUEST["metertoken"]);

vp_updateoption("brequest_id",$_REQUEST["brequest_id"]);


for($cheaders=1; $cheaders<=1; $cheaders++){
vp_updateoption("billhead".$cheaders,$_REQUEST["billhead".$cheaders]);
vp_updateoption("billvalue".$cheaders,$_REQUEST["billvalue".$cheaders]);
}




vp_updateoption("billaddpost",$_REQUEST["billaddpost"]);


for($cpost=1; $cpost<=5; $cpost++){
vp_updateoption("billpostdata".$cpost,$_REQUEST["billpostdata".$cpost]);
vp_updateoption("billpostvalue".$cpost,$_REQUEST["billpostvalue".$cpost]);
}

vp_updateoption("billamountattribute",$_REQUEST["billamountattribute"]);
vp_updateoption("billphoneattribute",$_REQUEST["billphoneattribute"]);
vp_updateoption("cbvariationattr",$_REQUEST["cbvariationattr"]);
vp_updateoption("btypeattr",$_REQUEST["btypeattr"]);
vp_updateoption("cmeterattr",$_REQUEST["cmeterattr"]);

for($j=0; $j<=3; $j++){
vp_updateoption("billname".$j,$_REQUEST["billname".$j]);
vp_updateoption("billid".$j,$_REQUEST["billid".$j]);
}

for($vtuaddheaders=1; $vtuaddheaders<=4; $vtuaddheaders++){
vp_updateoption("vtuaddheaders".$vtuaddheaders,$_REQUEST["vtuaddheaders".$vtuaddheaders]);
vp_updateoption("vtuaddvalue".$vtuaddheaders,$_REQUEST["vtuaddvalue".$vtuaddheaders]);
}
for($shareaddheaders=1; $shareaddheaders<=4; $shareaddheaders++){
vp_updateoption("shareaddheaders".$shareaddheaders,$_REQUEST["shareaddheaders".$shareaddheaders]);
vp_updateoption("shareaddvalue".$shareaddheaders,$_REQUEST["shareaddvalue".$shareaddheaders]);
}
for($awufaddheaders=1; $awufaddheaders<=4; $awufaddheaders++){
vp_updateoption("awufaddheaders".$awufaddheaders,$_REQUEST["awufaddheaders".$awufaddheaders]);
vp_updateoption("awufaddvalue".$awufaddheaders,$_REQUEST["awufaddvalue".$awufaddheaders]);
}
for($smeaddheaders=1; $smeaddheaders<=4; $smeaddheaders++){
vp_updateoption("smeaddheaders".$smeaddheaders,$_REQUEST["smeaddheaders".$smeaddheaders]);
vp_updateoption("smeaddvalue".$smeaddheaders,$_REQUEST["smeaddvalue".$smeaddheaders]);
}
for($directaddheaders=1; $directaddheaders<=4; $directaddheaders++){
vp_updateoption("directaddheaders".$directaddheaders,$_REQUEST["directaddheaders".$directaddheaders]);
vp_updateoption("directaddvalue".$directaddheaders,$_REQUEST["directaddvalue".$directaddheaders]);
}
for($corporateaddheaders=1; $corporateaddheaders<=4; $corporateaddheaders++){
vp_updateoption("corporateaddheaders".$corporateaddheaders,$_REQUEST["corporateaddheaders".$corporateaddheaders]);
vp_updateoption("corporateaddvalue".$corporateaddheaders,$_REQUEST["corporateaddvalue".$corporateaddheaders]);
}
for($cableaddheaders=1; $cableaddheaders<=4; $cableaddheaders++){
vp_updateoption("cableaddheaders".$cableaddheaders,$_REQUEST["cableaddheaders".$cableaddheaders]);
vp_updateoption("cableaddvalue".$cableaddheaders,$_REQUEST["cableaddvalue".$cableaddheaders]);
}
for($billaddheaders=1; $billaddheaders<=4; $billaddheaders++){
vp_updateoption("billaddheaders".$billaddheaders,$_REQUEST["billaddheaders".$billaddheaders]);
vp_updateoption("billaddvalue".$billaddheaders,$_REQUEST["billaddvalue".$billaddheaders]);
}






vp_updateoption("airtime1_response_format_text",$_REQUEST["airtimeresponsetext"]);
vp_updateoption("airtime2_response_format_text",$_REQUEST["airtimeresponsetext2"]);
vp_updateoption("airtime3_response_format_text",$_REQUEST["airtimeresponsetext3"]);
vp_updateoption("data1_response_format_text",$_REQUEST["dataresponsetext"]);
vp_updateoption("data2_response_format_text",$_REQUEST["dataresponsetext2"]);
vp_updateoption("data3_response_format_text",$_REQUEST["dataresponsetext3"]);
vp_updateoption("cable_response_format_text",$_REQUEST["cableresponsetext"]);
vp_updateoption("bill_response_format_text",$_REQUEST["billresponsetext"]);
vp_updateoption("airtime1_response_format",$_REQUEST["airtimeresponse"]);
vp_updateoption("airtime2_response_format",$_REQUEST["airtimeresponse2"]);
vp_updateoption("airtime3_response_format",$_REQUEST["airtimeresponse3"]);
vp_updateoption("data1_response_format",$_REQUEST["dataresponse"]);
vp_updateoption("data2_response_format",$_REQUEST["dataresponse2"]);
vp_updateoption("data3_response_format",$_REQUEST["dataresponse3"]);
vp_updateoption("cable_response_format",$_REQUEST["cableresponse"]);
vp_updateoption("bill_response_format",$_REQUEST["billresponse"]);


vp_updateoption("airtime_head",$_REQUEST["airtimehead"]);
vp_updateoption("airtime_head2",$_REQUEST["airtimehead2"]);
vp_updateoption("airtime_head3",$_REQUEST["airtimehead3"]);
vp_updateoption("data_head",$_REQUEST["datahead"]);
vp_updateoption("data_head2",$_REQUEST["datahead2"]);
vp_updateoption("data_head3",$_REQUEST["datahead3"]);
vp_updateoption("cable_head",$_REQUEST["cablehead"]);
vp_updateoption("bill_head",$_REQUEST["billhead"]);



//////////////////////////////////////////////////////////////////////////////////////////

die("100");
}

?>