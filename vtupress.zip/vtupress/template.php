<?php
the_content();

?>