<?php
//ob_start();
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH ."wp-load.php");
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');
if (!function_exists('is_plugin_active')) {
    include_once(ABSPATH . 'wp-admin/includes/plugin.php');
}

$option_array = json_decode(get_option("vp_options"),true);


if(vp_option_array($option_array,'siteurl') != "https://vtupress.com" || vp_option_array($option_array,'siteurl') != "vtupress.com" ){
add_action('wp_footer',"modalmedia");
function modalmedia(){
	echo'
	<style>
	@media only screen and (max-width: 800px) {
.modal-content{
	 width: 60%; margin-left:15%; /* Could be more or less, depending on screen size */
	}
.modal{
z-index:999999;
}	
	
.myModal{
	width: auto;
	
}
.nav li a {
    background-color: #fff;
}

}
	</style>
	';

}

add_action( 'login_form_middle', 'add_lost_password_link' );
function add_lost_password_link() {
	return '<a href="'.wp_lostpassword_url( home_url() ).'"  style="color:blue;" >Lost Password?</a>';
}





$current_user = get_current_user_id();
vp_adduser( $current_user, 'vp_bal' , 0);
vp_adduser( $current_user, 'vp_ref' , 0);
vp_adduser( $current_user, 'vr_plan' , "customer");



vp_addoption('manual_funding', "no message");
vp_addoption("show_services_bonus", "yes");
vp_addoption("refbo",0);
vp_addoption("cb",0);

add_action('wp_head', 'gglfonts');
function gglfonts(){
	echo'
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
	';
	
}


add_filter( 'authenticate', 'custom_authenticate_username_password', 30, 3);
function custom_authenticate_username_password( $user, $username, $password ){
    if ( is_a($user, 'WP_User') ) { return $user; }

    if ( empty($username) || empty($password) )
    {
        $error = new WP_Error();
        $user  = new WP_Error('authentication_failed', __('<strong>ERROR</strong>: Invalid username or incorrect password.'));

        return $error;
    }
}








$id = get_current_user_id();

add_shortcode("vpaccount","vpaccount");



function vpusers(){

$option_array = json_decode(get_option("vp_options"),true);

vtupress_js_css_user();

 

	//get_users('orderby=meta_value&meta_key=id');
	
vtupress_js_css_user();
if(!isset($_GET["user_id"])){
pagination_before("users","user","users","resultfad");
}
else{
	$id = $_GET["user_id"];
pagination_before("users","user","users","resultfad","WHERE id = $id");	
}
?>


<div class="input-group">
<span class="input-group-text">Enter User ID</span>
<input type="number" class="user-id" placeholder="User ID">
<input type="button" class="btn btn-primary btn-sm search-id" value="search">
<script>
jQuery(".search-id").on("click",function(){
	var user_id = jQuery(".user-id").val();
	
window.location = "<?php echo $_SERVER['PHP_SELF'].'?page=vtu-settings';?>&user_id="+user_id+"#users";
	
	
	
});


</script>
</div>

<?php

pagination_after('users',"user");
echo"



<div class='container mx-auto'>

<div class='row my-4 '>
<div class='col-12 mx-sm-2 py-3 px-2 my-2 my-sm-1 shadow bg-white rounded col-md border'>
<div class='row'>
<div class='col'>
Total User Balance On Current Column
</div>
<div class='col'>
<span class='current_amt'></span>
</div>
</div>
</div>

<div class='col-12 mx-sm-2  py-3 px-2 my-2 my-sm-1 shadow bg-white rounded col-md border'>
<div class='row'>
<div class='col'>
Total User Balance On All Columns
</div>
<div class='col'>
<span class='total_amt'></span>
</div>
</div>
</div>
</div>
</div>


";
global $wpdb;
	$table_name = $wpdb->prefix."vp_levels";
	$level = $wpdb->get_results("SELECT * FROM  $table_name");

global $wpdb;
 $total_table = $wpdb->prefix."users";
 $amt_array = $wpdb->get_results("SELECT * FROM  $total_table ");
 $total_amt = 0;

foreach ($amt_array as $tot){
	$id = $tot->ID;
	$user_array = json_decode(get_user_meta($id,"vp_user_data",true),true);
$balance = vp_user_array($user_array,$id, "vp_bal", true);
	
	$total_amt  += $balance;
	
	echo "
<script>
jQuery('.total_amt').text($total_amt);
</script>
";

}

$current_amt = 0;

echo"
<style>
.swal-button.swal-button--confirm {
    width: fit-content;
    padding: 10px !important;
}
table.table th{
  font-size:0.9em;
  font-style:bold;
  }
  
  table.table td{
      font-size:0.7em;
      font-style:normal;
      }
  
      .dtable{
        max-width:100%;
        overflow:auto;
      }
  
</style>
	<div class='container dtable' >
  <table class='table table-striped table-hover table-bordered table-responsive'>
	<thead>
	<tr>
	<th scope='col'>Id</th>
	<th scope='col'>Name</th>
	<th scope='col'>Email</th>
	<th scope='col'>Phone</th>
	<th scope='col'>Pin</th>
	<th scope='col'>Balance</th>
	<th scope='col'>Plan</th>
  <th scope='col'>API KEY</th>
	<th scope='col'>Total Transactions Attempted</th>
	<th scope='col'>Total Successful Transaction</th>
	<th scope='col'>Total Transaction Bonus</th>
	<th scope='col'>Referer</th>
	<th scope='col'>1st Level Referee</th>
	<th scope='col'>2nd Level Referee</th>
	<th scope='col'>3rd Level Referee</th>
	<th scope='col'>Ref. Bonus Earned From 1st Level</th>
	<th scope='col'>Ref. Bonus Earned From 2nd Level</th>
	<th scope='col'>Ref. Bonus Earned From 3rd Level</th>
	<th scope='col'>Transaction Bonus Earned From 1st Level</th>
	<th scope='col'>Transaction Bonus Earned From 2nd Level</th>
	<th scope='col'>Transaction Bonus Earned From 3rd Level</th>
	<th scope='col'>Total Withdrawals</th>
	<th scope='col'>Balance Withdrawable</th>
  <th scope='col'>Action</th>
	</tr>
	</thead>
	<tbody>
	
	";
global $resultfad;
foreach($resultfad as $users){
	
	
	$id = $users->ID;
	
	$user_array = json_decode(get_user_meta($id,"vp_user_data",true),true);
	
	$email = get_userdata($id)->user_email;
	$name = get_userdata($id)->user_login;
	$balance = vp_user_array($user_array,$id, "vp_bal", true);
	
	$current_amt += $balance;
	
	
	$phone = vp_user_array($user_array,$id, "vp_phone", true);
	$pin = vp_user_array($user_array,$id, "vp_pin", true);
	vp_adduser($id, 'vr_id', 0);

if(is_plugin_active("vpmlm/vpmlm.php") && vp_option_array($option_array,'mlm') == "yes" ){
	$user_array = json_decode(get_user_meta($id,"vp_user_data",true),true);
$plan = vp_user_array($user_array,$id,'vr_plan', true);

$vrid = vp_user_array($user_array,$id, 'vr_id', true);
		
$ref = vp_user_array($user_array,$id, "vp_ref", true);

$total_refered = vp_user_array($user_array,$id, "vp_tot_ref",true); // first level refered

$total_inrefered = vp_user_array($user_array,$id, "vp_tot_in_ref",true);//second level refered

$total_inrefered3 = vp_user_array($user_array,$id, "vp_tot_in_ref3",true);//third level refered


$total_dir_earn = vp_user_array($user_array,$id, "vp_tot_ref_earn",true);//total earned from first level referree


$total_indir_earn = vp_user_array($user_array,$id, "vp_tot_in_ref_earn",true); //total earned from second level referree


$total_indir_earn3 = vp_user_array($user_array,$id, "vp_tot_in_ref_earn3",true); //total earned from third level referree


$total_trans_bonus = vp_user_array($user_array,$id, "vp_tot_trans_bonus",true); //total earned from transactions


$total_dirtrans_bonus = vp_user_array($user_array,$id, "vp_tot_dir_trans",true); //total earned from first level transactions bonus


$total_indirtrans_bonus = vp_user_array($user_array,$id, "vp_tot_indir_trans",true); //total earned from second level transaction bonus


$total_indirtrans_bonus3 = vp_user_array($user_array,$id, "vp_tot_indir_trans3",true); //total earned from third level transaction bonus


$total_trans_attempt = vp_user_array($user_array,$id, "vp_tot_trans",true); //total transaction attempted


$total_suc_trans = vp_user_array($user_array,$id, "vp_tot_suc_trans",true); //total successful transactions


$total_withdraws = vp_user_array($user_array,$id, "vp_tot_withdraws",true); //total withdrawals

$total_bal_with = intval($total_dir_earn) + intval($total_indir_earn) + intval($total_indir_earn3) + intval($total_trans_bonus) + intval($total_dirtrans_bonus) + intval($total_indirtrans_bonus) + intval($total_indirtrans_bonus3); //withdrawable
	
	}
  else{
echo"
<script>
jQuery('.setplan').prop('disabled', true);

</script>
";

$plan = "Premium Plan Required";

$vrid = "Premium Plan Required";
		
$ref = "Premium Plan Required";

$total_refered = "Premium Plan Required";
$total_inrefered = "Premium Plan Required";

$total_inrefered3 = "Premium Plan Required";


$total_dir_earn = "Premium Plan Required";


$total_indir_earn = "Premium Plan Required";


$total_indir_earn3 = "Premium Plan Required";


$total_trans_bonus = "Premium Plan Required";


$total_dirtrans_bonus = "Premium Plan Required";


$total_indirtrans_bonus = "Premium Plan Required";


$total_indirtrans_bonus3 = "Premium Plan Required";

$total_trans_attempt = "Premium Plan Required";

$total_suc_trans = "Premium Plan Required";

$total_withdraws = "Premium Plan Required";

$total_bal_with = "Premium Plan Required";
  }
	
	echo"
	<tr>
	<th scope='row'>$id</th>
	<td>$name</td>
	<td>$email</td>
	<td>$phone</td>
	<td>$pin</td>
	<td>$balance</td>
	<td>$plan</td>
	<td>$vrid</td>
	<td>$total_trans_attempt</td>
	<td>$total_suc_trans</td>
	<td>$total_trans_bonus</td>
	<td>$ref</td>
	<td>$total_refered</td>
	<td>$total_inrefered</td>
	<td>$total_inrefered3</td>
	<td>$total_dir_earn</td>
	<td>$total_indir_earn</td>
	<td>$total_indir_earn3</td>
	<td>$total_dirtrans_bonus</td>
	<td>$total_indirtrans_bonus</td>
	<td>$total_indirtrans_bonus3</td>
	<td>$total_withdraws</td>
	<td>$total_bal_with</td>
  <td>
  <button type='button' class='btn btn-secondary btn-sm do-user-action' data-bs-toggle='modal' data-bs-target='#exampleModal$id' data-bs-whatever='@getbootstrap' id='".$id."' style='width:fit-content  !important;'>Action</button>

<div class='modal fade' id='exampleModal$id' aria-labelledby='exampleModalLabel' aria-hidden='true'>
  <div class='modal-dialog'>
    <div class='modal-content'>
          <div class='modal-header'>
              <h5 class='modal-title' id='exampleModalLabel'>Action</h5>
              <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
          </div>
          <div class='modal-body'>
              <div class='form-body mb-2'>
              <form method='post' target='_self' id='useraction$id' class='action-proceed1'>
              <label class='form-label'>User Id</label>
              <input type='number'  value='$id' name='userid' readonly>
              <label class='form-label'>User Name</label>
              <input  type='text' value='$name' readonly>
              <label class='form-label'>Action</label>
              <select class='do-action$id'  name='doaction' >
              <option value='none'>---Select--- </option>
              <option value='removebalance'>Remove From '$name' Balance </option>
              <option value='addbalance'>Add To '$name' Balance </option>
              <option value='setbalance'> Set '$name' Balance To</option>
              <option value='setplan' class='setplan'> Set'$name' Plan</option>
              <option value='switchto' class='switchto'> Switch To '$name' Account</option>
              </select>

              <div class='do-amount$id mb-2'>
                <label class='form-label'>Amount</label><br>
                <input type='number' name='amt'  value='$balance'><br>
              </div>
			  
			 <div class='do-balances$id mb-2'>
                <label class='form-label'>Description</label><br>
                <textarea class='balance_reason$id' name='balance_reason'></textarea><br>
              </div>

              <div class='do-plan$id mb-2'>
                 <label class='form-label'>Plan</label><br>
                  <select name='rplan' class='chooseplan$id'>
";
foreach($level as $lev){
echo"
<option value='{$lev->name}'>{$lev->name}</option>
";	
}
echo"
                  </select>

                  <div class='do-id$id mb-2'>
                    <label class='form-label'>API KEY</label><br>
                      <input type='text'  name='vrid' value='$vrid'>
                  </div>
            </div>

            </form>
            </div>
          </div>
      <div class='modal-footer'>
        <button type='button' class='btn btn-secondary bill-proceed-cancled' data-bs-dismiss='modal'>Cancel</button>
        <input type='button' name='runaction' id='runaction$id' class='btn btn-primary action-proceed' form='useraction$id' value='Proceed' >
      </div>
    </div>
  </div>
</div>

<script>
jQuery('.do-balances$id').hide();
jQuery('.do-amount$id').hide();
jQuery('.do-plan$id').hide();

jQuery('.do-action$id').on('change',function(){
var action_value = jQuery('.do-action$id').val();

if(action_value == 'addbalance' || action_value == 'removebalance' || action_value == 'setbalance'){
  jQuery('.do-amount$id').show();
  jQuery('.do-plan$id').hide();
  jQuery('.do-balances$id').show();
}

if(action_value == 'none'){
  jQuery('.do-amount$id').hide();
  jQuery('.do-plan$id').hide();
}

if(action_value == 'setplan'){
  jQuery('.do-amount$id').hide();
  jQuery('.do-plan$id').show();
  var chooseplan = jQuery('.chooseplan$id').val();

  jQuery('.do-id$id').show();

}



});




jQuery('.do-user-action').on('click',function(){
jQuery('.modal-backdrop').remove();
});


</script>
";

echo'
<script>

jQuery("#runaction'.$id.'").click(function(){
	jQuery("#cover-spin").show();
var obj'.$id.' = {};
var toatl_input'.$id.' = jQuery("#useraction'.$id.' input, #useraction'.$id.' select, #useraction'.$id.' textarea").length;
var run_obj'.$id.';

for(run_obj'.$id.' = 0; run_obj'.$id.' <= toatl_input'.$id.'; run_obj'.$id.'++){
var current_input'.$id.' = jQuery("#useraction'.$id.' input, #useraction'.$id.' select, #useraction'.$id.' textarea").eq(run_obj'.$id.');


var obj_name'.$id.' = current_input'.$id.'.attr("name");
var obj_value'.$id.' = current_input'.$id.'.val();

if(typeof obj_name'.$id.' !== typeof undefined && obj_name'.$id.' !== false){
obj'.$id.'[obj_name'.$id.'] = obj_value'.$id.';
//alert(obj_name'.$id.');
//alert(obj_value'.$id.');
}
	
	
}

jQuery.ajax({
  url: "'.esc_url(plugins_url("vtupress/vend.php")).'",
  data: obj'.$id.',
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){
	
		  swal({
  title: "SAVED",
  text: "Update Completed",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else if(data.status == "101"){
		  		  swal({
  title: "SWITCHED",
  text: "You\'ll be redirected to the selected user Dashboard",
  icon: "success",
  button: "Okay",
}).then((value) => {
location.href = "'.vp_option_array($option_array,"siteurl").'/vpaccount";
});
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error",
  text: "Saving Wasn\"t Successful",
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});
</script>
';


echo"
</td>
  </tr>
	";
	echo "
<script>
jQuery('.current_amt').text($current_amt);
</script>
";
	
}	
	echo"
	
	</tbody>
</table>
</div>


";





	
}






vp_addoption("vpap","no");
vp_addoption("vpwalm","No message");


//user account





function vpaccount(){

$option_array = json_decode(get_option("vp_options"),true);
if(is_user_logged_in()){
		
include(ABSPATH."wp-content/plugins/vtupress/template/".constant('vtupress_template')."/dashboard.html");
		
}
else{

include(ABSPATH."wp-content/plugins/vtupress/template/".constant('vtupress_template')."/access.php");

}



}



function create_vpaccount(){

$user_ID = 1;
    if( get_page_by_title('VTU DASHBOARD')== NULL && get_page_by_title('VTU Account')== NULL && get_page_by_title('VP Account')== NULL && get_page_by_title('vpaccount')== NULL){
	$new_post = array(
		      'post_title' => 'VTU DASHBOARD',
		      'post_name' => 'vpaccount',
		      'post_content' => '[vpaccount]',
		      'post_status' => 'publish',
		      'post_date' => date('Y-m-d H:i:s'),
		      'post_author' => $user_ID,
		      'post_type' => 'page'
		);
	$post_id = wp_insert_post($new_post);
   }
  

}


add_action("vpformsub", "vpusub");
function vpusub(){
echo '<input name="wallet" id="wallet" type="button" class="subm" value="Pay with Wallet" onclick="res()">
';
}


}
?>