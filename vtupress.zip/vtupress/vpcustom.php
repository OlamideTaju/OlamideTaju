<?php
if(!defined('ABSPATH')){
    $pagePath = explode('/wp-content/', dirname(__FILE__));
    include_once(str_replace('wp-content/' , '', $pagePath[0] . '/wp-load.php'));
};
if(WP_DEBUG == false){
error_reporting(0);	
}
include_once(ABSPATH ."wp-load.php");
include_once(ABSPATH .'wp-content/plugins/vtupress/functions.php');

$option_array = json_decode(get_option("vp_options"),true);
add_action("vtupress_actions","0");
if(get_option("vtupress_actions") == "0"){
vp_addoption("getts","none");
vp_addoption("usernameattr","username");
vp_addoption("passwordattr","password");
vp_addoption("username","");
vp_addoption("password","");
vp_addoption("cpara1attr","");
vp_addoption("cpara1","");
vp_addoption("cpara2attr","");
vp_addoption("cpara2","");
vp_addoption("cpara3attr","");
vp_addoption("cpara3","");
vp_addoption("cpara4attr","");
vp_addoption("cpara4","");
vp_addoption("airend", "");
vp_addoption("dataend", "");
vp_addoption("cableend", "");
vp_addoption("billend", "");
vp_addoption("baseurl","");
vp_addoption("camountattr","amount");
vp_addoption("cnetworkattr", "network");
vp_addoption("cphoneattr","phone");
vp_addoption("cmtnattr", "mtn");
vp_addoption("cgloattr", "glo");
vp_addoption("ciucattr", "iuc");
vp_addoption("cmeterattr", "meterno");
vp_addoption("c9mobileattr","9mobile");
vp_addoption("cairtelattr", "airtel");
vp_addoption("balanceend","");
vp_addoption("successcode","");
vp_addoption("successvalue","");
vp_addoption("balanceattr","");
vp_addoption("cvariationattr","");
vp_addoption("ccvariationattr","");
vp_addoption("ctypeattr","");
vp_addoption("cbvariationattr","");
vp_addoption("btypeattr","");
vp_addoption("bmethod","get");
vp_addoption("billthod","get");
vp_addoption("hvalue","");
vp_addoption("head1","");
vp_addoption("balt","one");
vp_addoption("bdata1","");
vp_addoption("bdata2","");
vp_addoption("airdis",0);
vp_addoption("addpost","");
vp_addoption("baddpost","");
vp_addoption("sme_mtn_balance","*131*4#");
vp_addoption("sme_glo_balance","*127*0#");
vp_addoption("sme_airtel_balance","*140#");
vp_addoption("sme_9mobile_balance","*232#");
vp_addoption("direct_mtn_balance","*131*4#");
vp_addoption("direct_glo_balance","*127*0#");
vp_addoption("direct_airtel_balance","*140#");
vp_addoption("direct_9mobile_balance","*232#");
vp_addoption("corporate_mtn_balance","*131*4#");
vp_addoption("corporate_glo_balance","*127*0#");
vp_addoption("corporate_airtel_balance","*140#");
vp_addoption("corporate_9mobile_balance","*232#");
vp_addoption("sme_visible_networks","mtn,glo,9mobile,airtel");
vp_addoption("corporate_visible_networks","mtn,glo,9mobile,airtel");
vp_addoption("direct_visible_networks","mtn,glo,9mobile,airtel");
vp_addoption("cable_charge","0");
vp_addoption("bill_charge","0");
for($i=0; $i<=3; $i++){
vp_addoption("cablename".$i, "");
vp_addoption("cableid".$i, "");
}

for($i=0; $i<=1; $i++){
vp_addoption("billname".$i, "");
vp_addoption("billid".$i, "");
}

for($i=0; $i<=35; $i++){
vp_addoption("cbill".$i, "");
vp_addoption("cbilln".$i, "");
}


for($i=0; $i<=10; $i++){
vp_addoption("cdata".$i, "");
vp_addoption("cdatan".$i, "");
vp_addoption("cdatap".$i, "");
}

for($i=0; $i<=10; $i++){
vp_addoption("acdata".$i, "");
vp_addoption("acdatan".$i, "");
vp_addoption("acdatap".$i, "");
}

for($i=0; $i<=10; $i++){
vp_addoption("9cdata".$i, "");
vp_addoption("9cdatan".$i, "");
vp_addoption("9cdatap".$i, "");
}

for($i=0; $i<=10; $i++){
vp_addoption("gcdata".$i, "");
vp_addoption("gcdatan".$i, "");
vp_addoption("gcdatap".$i, "");
}

for($i=0; $i<=35; $i++){
vp_addoption("ccable".$i, "");
vp_addoption("ccablen".$i, "");
vp_addoption("ccablep".$i, "");
}
for($vtuaddheaders=1; $vtuaddheaders<=4; $vtuaddheaders++){
vp_addoption("vtuaddheaders".$vtuaddheaders," ");
vp_addoption("vtuaddvalue".$vtuaddheaders," ");
}
for($shareaddheaders=1; $shareaddheaders<=4; $shareaddheaders++){
vp_addoption("shareaddheaders".$shareaddheaders," ");
vp_addoption("shareaddvalue".$shareaddheaders," ");
}
for($awufaddheaders=1; $awufaddheaders<=4; $awufaddheaders++){
vp_addoption("awufaddheaders".$awufaddheaders," ");
vp_addoption("awufaddvalue".$awufaddheaders," ");
}
for($smeaddheaders=1; $smeaddheaders<=4; $smeaddheaders++){
vp_addoption("smeaddheaders".$smeaddheaders," ");
vp_addoption("smeaddvalue".$smeaddheaders," ");
}
for($directaddheaders=1; $directaddheaders<=4; $directaddheaders++){
vp_addoption("directaddheaders".$directaddheaders," ");
vp_addoption("directaddvalue".$directaddheaders," ");
}
for($corporateaddheaders=1; $corporateaddheaders<=4; $corporateaddheaders++){
vp_addoption("corporateaddheaders".$corporateaddheaders," ");
vp_addoption("corporateaddvalue".$corporateaddheaders," ");
}
for($cableaddheaders=1; $cableaddheaders<=4; $cableaddheaders++){
vp_addoption("cableaddheaders".$cableaddheaders," ");
vp_addoption("cableaddvalue".$cableaddheaders," ");
}
for($billaddheaders=1; $billaddheaders<=4; $billaddheaders++){
vp_addoption("billaddheaders".$billaddheaders," ");
vp_addoption("billaddvalue".$billaddheaders," ");
}
vp_addoption("vtu_airtime_platform","Select");
vp_addoption("share_airtime_platform","Select");
vp_addoption("awuf_airtime_platform","Select");
vp_addoption("sme_data_platform","Select");
vp_addoption("direct_data_platform","Select");
vp_addoption("corporate_data_platform","Select");
vp_addoption("cable_platform","Select");
vp_addoption("bill_platform","Select");
vp_addoption("sms_platform","Select");
vp_addoption("epin_platform","Select");
vp_addoption("airtimebaseurl","");
vp_addoption("airtimeendpoint","");
vp_addoption("airtimerequest","");
vp_addoption("airtimerequesttext","");
vp_addoption("airtimesuccesscode","");
vp_addoption("airtimesuccessvalue","");
vp_addoption("airtimesuccessvalue2","");
for($cheaders=1; $cheaders<=4; $cheaders++){
vp_addoption("airtimehead".$cheaders,"");
vp_addoption("airtimevalue".$cheaders,"");
}

vp_addoption("airtimeaddpost","");

for($cpost=1; $cpost<=5; $cpost++){
vp_addoption("airtimepostdata".$cpost,"");
vp_addoption("airtimepostvalue".$cpost,"");
}

vp_addoption("airtimeamountattribute","");
vp_addoption("airtimephoneattribute","");
vp_addoption("airtimenetworkattribute","");
vp_addoption("airtimemtn","");
vp_addoption("airtimeglo","");
vp_addoption("airtime9mobile","");
vp_addoption("airtimeairtel","");
//////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////SHARE AND SELL AIRTIME////////////////////////////////////
vp_addoption("sairtimebaseurl","");
vp_addoption("sairtimeendpoint","");
vp_addoption("sairtimerequest","");
vp_addoption("sairtimerequesttext","");
vp_addoption("sairtimesuccesscode","");
vp_addoption("sairtimesuccessvalue","");
vp_addoption("sairtimesuccessvalue2","");

for($cheaders=1; $cheaders<=4; $cheaders++){
vp_addoption("sairtimehead".$cheaders,"");
vp_addoption("sairtimevalue".$cheaders,"");
}

vp_addoption("sairtimeaddpost","");

for($cpost=1; $cpost<=5; $cpost++){
vp_addoption("sairtimepostdata".$cpost,"");
vp_addoption("sairtimepostvalue".$cpost,"");
}

vp_addoption("sairtimeamountattribute","");
vp_addoption("sairtimephoneattribute","");
vp_addoption("sairtimenetworkattribute","");
vp_addoption("sairtimemtn","");
vp_addoption("sairtimeglo","");
vp_addoption("sairtime9mobile","");
vp_addoption("sairtimeairtel","");
//////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////AWFUF AIRTIME////////////////////////////////////
vp_addoption("wairtimebaseurl","");
vp_addoption("wairtimeendpoint","");
vp_addoption("wairtimerequest","");
vp_addoption("wairtimerequesttext","");
vp_addoption("wairtimesuccesscode","");
vp_addoption("wairtimesuccessvalue","");
vp_addoption("wairtimesuccessvalue2","");




for($cheaders=1; $cheaders<=4; $cheaders++){
vp_addoption("wairtimehead".$cheaders,"");
vp_addoption("wairtimevalue".$cheaders,"");
}

vp_addoption("wairtimeaddpost","");

for($cpost=1; $cpost<=5; $cpost++){
vp_addoption("wairtimepostdata".$cpost,"");
vp_addoption("wairtimepostvalue".$cpost,"");
}

vp_addoption("wairtimeamountattribute","");
vp_addoption("wairtimephoneattribute","");
vp_addoption("wairtimenetworkattribute","");
vp_addoption("wairtimemtn","");
vp_addoption("wairtimeglo","");
vp_addoption("wairtime9mobile","");
vp_addoption("wairtimeairtel","");
//////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////DATA////////////////////////////////////
vp_addoption("databaseurl","");
vp_addoption("dataendpoint","");
vp_addoption("datarequest","");
vp_addoption("datarequesttext","");
vp_addoption("datasuccesscode","");
vp_addoption("datasuccessvalue","");
vp_addoption("datasuccessvalue2","");
for($cheaders=1; $cheaders<=4; $cheaders++){
vp_addoption("datahead".$cheaders,"");
vp_addoption("datavalue".$cheaders,"");
}


vp_addoption("dataaddpost","");

for($cpost=1; $cpost<=5; $cpost++){
vp_addoption("datapostdata".$cpost,"");
vp_addoption("datapostvalue".$cpost,"");
}
vp_addoption("dataamountattribute","");
vp_addoption("cvariationattr","");
vp_addoption("dataphoneattribute","");
vp_addoption("datanetworkattribute","");

vp_addoption("datamtn","");
vp_addoption("dataglo","");
vp_addoption("data9mobile","");
vp_addoption("dataairtel","");



for($i=0; $i<=10; $i++){
vp_addoption("cdata".$i,"");
vp_addoption("cdatan".$i,"");
vp_addoption("cdatap".$i,"");
}

for($i=0; $i<=10; $i++){
vp_addoption("acdata".$i,"");
vp_addoption("acdatan".$i,"");
vp_addoption("acdatap".$i,"");
}

for($i=0; $i<=10; $i++){
vp_addoption("9cdata".$i,"");
vp_addoption("9cdatan".$i,"");
vp_addoption("9cdatap".$i,"");
}

for($i=0; $i<=10; $i++){
vp_addoption("gcdata".$i,"");
vp_addoption("gcdatan".$i,"");
vp_addoption("gcdatap".$i,"");
}
//////////////////////////////////////////////////////////////////////////////////////////





////////////////////////////////////////////////DIRECT R DATA////////////////////////////////////
vp_addoption("rdatabaseurl","");
vp_addoption("rdataendpoint","");
vp_addoption("rdatarequest","");
vp_addoption("rdatarequesttext","");
vp_addoption("rdatasuccesscode","");
vp_addoption("rdatasuccessvalue","");
vp_addoption("rdatasuccessvalue2","");
vp_addoption("rdatamtn","");
vp_addoption("rdataglo","");
vp_addoption("rdata9mobile","");
vp_addoption("rdataairtel","");



for($cheaders=1; $cheaders<=4; $cheaders++){
vp_addoption("rdatahead".$cheaders,"");
vp_addoption("rdatavalue".$cheaders,"");
}


vp_addoption("rdataaddpost","");

for($cpost=1; $cpost<=5; $cpost++){
vp_addoption("rdatapostdata".$cpost,"");
vp_addoption("rdatapostvalue".$cpost,"");
}
vp_addoption("rdataamountattribute","");
vp_addoption("rcvariationattr","");
vp_addoption("rdataphoneattribute","");
vp_addoption("rdatanetworkattribute","");

for($i=0; $i<=10; $i++){
vp_addoption("rcdata".$i,"");
vp_addoption("rcdatan".$i,"");
vp_addoption("rcdatap".$i,"");
}

for($i=0; $i<=10; $i++){
vp_addoption("racdata".$i,"");
vp_addoption("racdatan".$i,"");
vp_addoption("racdatap".$i,"");
}

for($i=0; $i<=10; $i++){
vp_addoption("r9cdata".$i,"");
vp_addoption("r9cdatan".$i,"");
vp_addoption("r9cdatap".$i,"");
}

for($i=0; $i<=10; $i++){
vp_addoption("rgcdata".$i,"");
vp_addoption("rgcdatan".$i,"");
vp_addoption("rgcdatap".$i,"");
}
//////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////CORPORATE R2 DATA////////////////////////////////////
vp_addoption("r2databaseurl","");
vp_addoption("r2dataendpoint","");
vp_addoption("r2datarequest","");
vp_addoption("r2datarequesttext","");
vp_addoption("r2datasuccesscode","");
vp_addoption("r2datasuccessvalue","");
vp_addoption("r2datasuccessvalue2","");

vp_addoption("r2datamtn","");
vp_addoption("r2dataglo","");
vp_addoption("r2data9mobile","");
vp_addoption("r2dataairtel","");



for($cheaders=1; $cheaders<=4; $cheaders++){
vp_addoption("r2datahead".$cheaders,"");
vp_addoption("r2datavalue".$cheaders,"");
}


vp_addoption("r2dataaddpost","");

for($cpost=1; $cpost<=5; $cpost++){
vp_addoption("r2datapostdata".$cpost,"");
vp_addoption("r2datapostvalue".$cpost,"");
}
vp_addoption("r2dataamountattribute","");
vp_addoption("r2cvariationattr","");
vp_addoption("r2dataphoneattribute","");
vp_addoption("r2datanetworkattribute","");

for($i=0; $i<=10; $i++){
vp_addoption("r2cdata".$i,"");
vp_addoption("r2cdatan".$i,"");
vp_addoption("r2cdatap".$i,"");
}

for($i=0; $i<=10; $i++){
vp_addoption("r2acdata".$i,"");
vp_addoption("r2acdatan".$i,"");
vp_addoption("r2acdatap".$i,"");
}
for($i=0; $i<=10; $i++){
vp_addoption("r29cdata".$i,"");
vp_addoption("r29cdatan".$i,"");
vp_addoption("r29cdatap".$i,"");
}
for($i=0; $i<=10; $i++){
vp_addoption("r2gcdata".$i,"");
vp_addoption("r2gcdatan".$i,"");
vp_addoption("r2gcdatap".$i,"");
}
//////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////CABLE////////////////////////////////////
vp_addoption("cablebaseurl","");
vp_addoption("cableendpoint","");
vp_addoption("cablerequest","");
vp_addoption("cablerequesttext","");
vp_addoption("cablesuccesscode","");
vp_addoption("cablesuccessvalue","");
vp_addoption("cablesuccessvalue2","");
for($cheaders=1; $cheaders<=4; $cheaders++){
vp_addoption("cablehead".$cheaders,"");
vp_addoption("cablevalue".$cheaders,"");
}
vp_addoption("cableaddpost","");
for($cpost=1; $cpost<=5; $cpost++){
vp_addoption("cablepostdata".$cpost,"");
vp_addoption("cablepostvalue".$cpost,"");
}
vp_addoption("cableamountattribute","amount");
vp_addoption("cablephoneattribute","phone");
vp_addoption("ccvariationattr","");
vp_addoption("ctypeattr","");
vp_addoption("ciucattr","");
for($j=0; $j<=3; $j++){
vp_addoption("cablename".$j,"");
vp_addoption("cableid".$j,"");
}
for($i=0; $i<=35; $i++){
vp_addoption("ccable".$i,"");
vp_addoption("ccablen".$i,"");
vp_addoption("ccablep".$i,"");
}
//////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////BILL////////////////////////////////////
vp_addoption("billbaseurl","");
vp_addoption("billendpoint","");
vp_addoption("billrequest","");
vp_addoption("billrequesttext","");
vp_addoption("billsuccesscode","");
vp_addoption("billsuccessvalue","");
vp_addoption("billsuccessvalue2","");
for($cheaders=1; $cheaders<=4; $cheaders++){
vp_addoption("billhead".$cheaders,"");
vp_addoption("billvalue".$cheaders,"");
}
vp_addoption("billaddpost","");
for($cpost=1; $cpost<=5; $cpost++){
vp_addoption("billpostdata".$cpost,"");
vp_addoption("billpostvalue".$cpost,"");
}
vp_addoption("billamountattribute","");
vp_addoption("billphoneattribute","");
vp_addoption("cbvariationattr","");
vp_addoption("btypeattr","");
vp_addoption("cmeterattr","");
for($j=0; $j<=3; $j++){
vp_addoption("billname".$j,"");
vp_addoption("billid".$j,"");
}
vp_addoption("vtu_info","Information will appear here after import");
vp_addoption("shared_info","Information Will appear here after import");
vp_addoption("awuf_info","Information will appear here after import");
vp_addoption("sme_info","Information will appear here after import");
vp_addoption("corporate_info","Information will appear here after import");
vp_addoption("direct_info","Information will appear here after import");
vp_addoption("cable_info","Information will appear here after import");
vp_addoption("bill_info","Information will appear here after import");
vp_addoption("setairtime","unchecked");
vp_addoption("setdata","unchecked");
vp_addoption("setcable","unchecked");
vp_addoption("setbill","unchecked");
vp_addoption("vtucontrol","unchecked");
vp_addoption("sharecontrol","unchecked");
vp_addoption("awufcontrol","unchecked");
vp_addoption("smecontrol","unchecked");
vp_addoption("directcontrol","unchecked");
vp_addoption("corporatecontrol","unchecked");
vp_addoption("cablecontrol","unchecked");
vp_addoption("billcontrol","unchecked");
vp_addoption("smscontrol","unchecked");
vp_addoption("epincontrol","unchecked");

update_option("vtupress_actions","1");
}


add_action('brequest_id',"request_id");
add_action('arequest_id',"request_id");
add_action('sarequest_id',"request_id");
add_action('warequest_id',"request_id");
add_action('r2request_id',"r2request_id");
add_action('sarequest_id',"request_id");
add_action('warequest_id',"request_id");
do_action("vpdropins");


vp_updateoption("cablename0","GOTV");
vp_updateoption("cablename1","DSTV");
vp_updateoption("cablename2","STARTIMES");

add_action("vpsubpages", "vtupress_vpcustomsh");
function vtupress_vpcustomsh(){
add_submenu_page("vtu-press","Gateway", "Gateway", "vtupress_access_gateway", "gateway", "vpcustoms");
}
/*
add_filter("customchoice", "vtupress_customchoice");
function vtupress_customchoice($cchoice){
return '
<option value="custom">Custom</option>
';
}
*/



function vtupress_importvp(){
	$option_array = json_decode(get_option("vp_options"),true);

vtupress_js_css_user_plain_admin();

//VTU IMPORTER
echo '
<div class="container">
<div class="row">
<div class="col">
<div class="input-group vtu_airtime mb-3">
<form method="post" target="_self">
<span class="input-group-text">VTU AIRTIME</span>
<select name="vtu_airtime_select" class="vtu_airtime_select" >
<option value="'.vp_option_array($option_array,"vtu_airtime_platform").'">'.vp_option_array($option_array,"vtu_airtime_platform").'</option>
';
$data = file_get_contents("https://vtupress.com/wp-content/plugins/vpimporter/vpimporter.php?vtu_names");
$json = json_decode($data, true);
foreach($json as $key => $value){
	echo"
	<option value='$value'>$key</option>
	";
}
echo'
</select>
<input type="button" name="vtu_airtime_import" class="vtu_airtime_import" value="IMPORT">
<script>

jQuery(".vtu_airtime_import").click(function(){
	jQuery("#cover-spin").show();
var obj = {};
var toatl_input = jQuery(".vtu_airtime select, .vtu_airtime input").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".vtu_airtime select, .vtu_airtime input").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}
	
}

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/importer.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){
	
		  swal({
  title: "Imported!",
  text: "Go To The Service To See Changes",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else if(data.status == "101" ){
jQuery("#cover-spin").hide();
var select = jQuery(".vtu_airtime_select option:selected").text();
	swal({
  title: "Error",
  text: jQuery(".vtu_airtime_select option:selected").text()+" Importer Doesn\'t Exist  For This Service",
  icon: "error",
  button: "Okay",
});	  
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error!",
  text: "Error Importing",
  icon: "warning",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});

</script>
</form>
</div>
';

//SHARE IMPORTER
echo'
<div class="input-group share_airtime mb-3">
<form method="post" target="_self">
<span class="input-group-text">SHARE AIRTIME</span>
<select name="share_airtime_select" class="share_airtime_select" >
<option value="'.vp_option_array($option_array,"share_airtime_platform").'">'.vp_option_array($option_array,"share_airtime_platform").'</option>
';
$data = file_get_contents("https://vtupress.com/wp-content/plugins/vpimporter/vpimporter.php?share_names");
$json = json_decode($data, true);
foreach($json as $key => $value){
	echo"
	<option value='$value'>$key</option>
	";
}
echo'
</select>
<input type="button" name="share_airtime_import" class="share_airtime_import" value="IMPORT">
<script>

jQuery(".share_airtime_import").click(function(){
	jQuery("#cover-spin").show();
var obj = {};
var toatl_input = jQuery(".share_airtime select, .share_airtime input").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".share_airtime select, .share_airtime input").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}
	
}

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/importer.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){
	
		  swal({
  title: "Imported!",
  text: "Go To The Service To See Changes",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else if(data.status == "101" ){
jQuery("#cover-spin").hide();
var select = jQuery(".share_airtime_select option:selected").text();
	swal({
  title: "Error",
  text: jQuery(".share_airtime_select option:selected").text()+" Chosen Importer Doesn\'t Exist",
  icon: "error",
  button: "Okay",
});	  
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error!",
  text: "Error Importing",
  icon: "warning",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});

</script>
</form>
</div>

';

//AWUF IMPORTER
echo'
<div class="input-group awuf_airtime mb-3">
<form method="post" target="_self">
<span class="input-group-text">AWUF AIRTIME</span>
<select name="awuf_airtime_select" class="awuf_airtime_select" >
<option value="'.vp_option_array($option_array,"awuf_airtime_platform").'">'.vp_option_array($option_array,"awuf_airtime_platform").'</option>
';
$data = file_get_contents("https://vtupress.com/wp-content/plugins/vpimporter/vpimporter.php?awuf_names");
$json = json_decode($data, true);
foreach($json as $key => $value){
	echo"
	<option value='$value'>$key</option>
	";
}
echo'
</select>
<input type="button" name="awuf_airtime_import" class="awuf_airtime_import" value="IMPORT">
<script>

jQuery(".awuf_airtime_import").click(function(){
	jQuery("#cover-spin").show();
var obj = {};
var toatl_input = jQuery(".awuf_airtime select, .awuf_airtime input").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".awuf_airtime select, .awuf_airtime input").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}
	
}

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/importer.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){
	
		  swal({
  title: "Imported!",
  text: "Go To The Service To See Changes",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else if(data.status == "101" ){
jQuery("#cover-spin").hide();
var select = jQuery(".awuf_airtime_select option:selected").text();
	swal({
  title: "Error",
  text: jQuery(".awuf_airtime_select option:selected").text()+" Chosen Importer Doesn\'t Exist",
  icon: "error",
  button: "Okay",
});	  
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error!",
  text: "Error Importing",
  icon: "warning",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});

</script>
</form>
</div>
</div><!--COLUMN-->
';
//sme DATA
echo'
<div class="col data">

<div class="input-group sme_data mb-3">
<form method="post" target="_self">
<span class="input-group-text">SME DATA</span>
<select name="sme_data_select" class="sme_data_select" >
<option value="'.vp_option_array($option_array,"sme_data_platform").'">'.vp_option_array($option_array,"sme_data_platform").'</option>
';
$data = file_get_contents("https://vtupress.com/wp-content/plugins/vpimporter/vpimporter.php?sme_names");
$json = json_decode($data, true);
foreach($json as $key => $value){
	echo"
	<option value='$value'>$key</option>
	";
}
echo'
</select>
<input type="button" name="sme_data_import" class="sme_data_import" value="IMPORT">
<script>

jQuery(".sme_data_import").click(function(){
	jQuery("#cover-spin").show();
var obj = {};
var toatl_input = jQuery(".sme_data select, .sme_data input").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".sme_data select, .sme_data input").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}

}

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/importer.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){
	
		  swal({
  title: "Imported!",
  text: "Go To The Service To See Changes",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else if(data.status == "101" ){
jQuery("#cover-spin").hide();
var select = jQuery(".awuf_airtime_select option:selected").text();
	swal({
  title: "Error",
  text: jQuery(".awuf_airtime_select option:selected").text()+" Chosen Importer Doesn\'t Exist",
  icon: "error",
  button: "Okay",
});	  
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error!",
  text: "Error Importing",
  icon: "warning",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});

</script>
</form>
</div>



<div class="input-group corporate_data mb-3">
<form method="post" target="_self">
<span class="input-group-text">CORPORATE DATA</span>
<select name="corporate_data_select" class="corporate_data_select" >
<option value="'.vp_option_array($option_array,"corporate_data_platform").'">'.vp_option_array($option_array,"corporate_data_platform").'</option>
';
$data = file_get_contents("https://vtupress.com/wp-content/plugins/vpimporter/vpimporter.php?corporate_names");
$json = json_decode($data, true);
foreach($json as $key => $value){
	echo"
	<option value='$value'>$key</option>
	";
}
echo'
</select>
<input type="button" name="corporate_data_import" class="corporate_data_import" value="IMPORT">
<script>

jQuery(".corporate_data_import").click(function(){
	jQuery("#cover-spin").show();
var obj = {};
var toatl_input = jQuery(".corporate_data select, .corporate_data input").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".corporate_data select, .corporate_data input").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}

}

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/importer.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){
	
		  swal({
  title: "Imported!",
  text: "Go To The Service To See Changes",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else if(data.status == "101" ){
jQuery("#cover-spin").hide();
var select = jQuery(".awuf_airtime_select option:selected").text();
	swal({
  title: "Error",
  text: jQuery(".awuf_airtime_select option:selected").text()+" Chosen Importer Doesn\'t Exist",
  icon: "error",
  button: "Okay",
});	  
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error!",
  text: "Error Importing",
  icon: "warning",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});

</script>
</form>
</div>



<div class="input-group direct_data mb-3">
<form method="post" target="_self">
<span class="input-group-text">GIFTING DATA</span>
<select name="direct_data_select" class="direct_data_select" >
<option value="'.vp_option_array($option_array,"direct_data_platform").'">'.vp_option_array($option_array,"direct_data_platform").'</option>
';
$data = file_get_contents("https://vtupress.com/wp-content/plugins/vpimporter/vpimporter.php?direct_names");
$json = json_decode($data, true);
foreach($json as $key => $value){
	echo"
	<option value='$value'>$key</option>
	";
}
echo'
</select>
<input type="button" name="direct_data_import" class="direct_data_import" value="IMPORT">
<script>

jQuery(".direct_data_import").click(function(){
	jQuery("#cover-spin").show();
var obj = {};
var toatl_input = jQuery(".direct_data select, .direct_data input").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".direct_data select, .direct_data input").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}

}

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/importer.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){
	
		  swal({
  title: "Imported!",
  text: "Go To The Service To See Changes",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else if(data.status == "101" ){
jQuery("#cover-spin").hide();
var select = jQuery(".awuf_airtime_select option:selected").text();
	swal({
  title: "Error",
  text: jQuery(".awuf_airtime_select option:selected").text()+" Chosen Importer Doesn\'t Exist",
  icon: "error",
  button: "Okay",
});	  
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error!",
  text: "Error Importing",
  icon: "warning",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});

</script>
</form>
</div>

</div>
';


if(is_plugin_active("bcmv/bcmv.php")){
echo'
<div class="col cable">

<div class="input-group cable_plan mb-3">
<form method="post" target="_self">
<span class="input-group-text">CABLE</span>
<select name="cable_select" class="cable_select" >
<option value="'.vp_option_array($option_array,"cable_platform").'">'.vp_option_array($option_array,"cable_platform").'</option>
';
$data = file_get_contents("https://vtupress.com/wp-content/plugins/vpimporter/vpimporter.php?cable_names");
$json = json_decode($data, true);
foreach($json as $key => $value){
	echo"
	<option value='$value'>$key</option>
	";
}
echo'
</select>
<input type="button" name="cable_import" class="cable_import" value="IMPORT">
<script>

jQuery(".cable_import").click(function(){
	jQuery("#cover-spin").show();
var obj = {};
var toatl_input = jQuery(".cable_plan select, .cable_plan input").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".cable_plan select, .cable_plan input").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}

}

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/importer.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){
	
		  swal({
  title: "Imported!",
  text: "Go To The Service To See Changes",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else if(data.status == "101" ){
jQuery("#cover-spin").hide();
var select = jQuery(".awuf_airtime_select option:selected").text();
	swal({
  title: "Error",
  text: jQuery(".awuf_airtime_select option:selected").text()+" Chosen Importer Doesn\'t Exist",
  icon: "error",
  button: "Okay",
});	  
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error!",
  text: "Error Importing",
  icon: "warning",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});

</script>
</form>
</div>


<div class="input-group bill_plan mb-3">
<form method="post" target="_self">
<span class="input-group-text">BILL</span>
<select name="bill_select" class="bill_select" >
<option value="'.vp_option_array($option_array,"bill_platform").'">'.vp_option_array($option_array,"bill_platform").'</option>
';
$data = file_get_contents("https://vtupress.com/wp-content/plugins/vpimporter/vpimporter.php?bill_names");
$json = json_decode($data, true);
foreach($json as $key => $value){
	echo"
	<option value='$value'>$key</option>
	";
}
echo'
</select>
<input type="button" name="bill_import" class="bill_import" value="IMPORT">
<script>

jQuery(".bill_import").click(function(){
	jQuery("#cover-spin").show();
var obj = {};
var toatl_input = jQuery(".bill_plan select, .bill_plan input").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".bill_plan select, .bill_plan input").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}

}

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/importer.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){
	
		  swal({
  title: "Imported!",
  text: "Go To The Service To See Changes",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else if(data.status == "101" ){
jQuery("#cover-spin").hide();
var select = jQuery(".awuf_airtime_select option:selected").text();
	swal({
  title: "Error",
  text: jQuery(".awuf_airtime_select option:selected").text()+" Chosen Importer Doesn\'t Exist",
  icon: "error",
  button: "Okay",
});	  
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error!",
  text: "Error Importing",
  icon: "warning",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});

</script>
</form>
</div>

</div>
';
}

if(is_plugin_active("vpsms/vpsms.php")){
echo'
<div class="col">
<div class="input-group sms_plan mb-3">
<form method="post" target="_self">
<span class="input-group-text">SMS</span>
<select name="sms_select" class="sms_select" >
<option value="'.vp_option_array($option_array,"sms_platform").'">'.vp_option_array($option_array,"sms_platform").'</option>
';
$data = file_get_contents("https://vtupress.com/wp-content/plugins/vpimporter/vpimporter.php?sms_names");
$json = json_decode($data, true);
foreach($json as $key => $value){
	echo"
	<option value='$value'>$key</option>
	";
}
echo'
</select>
<input type="button" name="sms_import" class="sms_import" value="IMPORT">
<script>

jQuery(".sms_import").click(function(){
	jQuery("#cover-spin").show();
var obj = {};
var toatl_input = jQuery(".sms_plan select, .sms_plan input").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".sms_plan select, .sms_plan input").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}

}

jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/importer.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){
	
		  swal({
  title: "Imported!",
  text: "Go To The Service To See Changes",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else if(data.status == "101" ){
jQuery("#cover-spin").hide();
var select = jQuery(".awuf_airtime_select option:selected").text();
	swal({
  title: "Error",
  text: jQuery(".awuf_airtime_select option:selected").text()+" Chosen Importer Doesn\'t Exist",
  icon: "error",
  button: "Okay",
});	  
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error!",
  text: "Error Importing",
  icon: "warning",
  button: "Okay",
});
	  }
  },
  type: "POST"
});

});

</script>
</form>
</div>
</div>
';
}

do_action("vp_add_importer");
echo'
</div><!--ROW-->
</div><!--CONTAINER-->
';
}


////////////////////////////////////////////////AIRTIME////////////////////////////////////

add_action('request_id',"request_id");





add_action('rrequest_id',"rrequest_id");



add_action('crequest_id',"request_id");



//////////////////////////////////////////////////////////////////////////////////////////




function vpcustoms(){
	
	

/*
add_option("vtupress_options2","0");
if(get_option("vtupress_options2") == "0"){
	*/
vp_addoption('allow_crypto','no');
vp_addoption('allow_cards','no');
vp_addoption("allow_withdrawal","no");
vp_addoption("allow_to_bank","no");
vp_addoption("vtu_mad",0);
vp_addoption("vtu_aad",0);
vp_addoption("vtu_9ad",0);
vp_addoption("vtu_gad",0);

vp_addoption("share_mad",0);
vp_addoption("share_aad",0);
vp_addoption("share_9ad",0);
vp_addoption("share_gad",0);

vp_addoption("awuf_mad",0);
vp_addoption("awuf_aad",0);
vp_addoption("awuf_9ad",0);
vp_addoption("awuf_gad",0);


vp_addoption("sme_mdd",0);
vp_addoption("sme_add",0);
vp_addoption("sme_9dd",0);
vp_addoption("sme_gdd",0);

vp_addoption("direct_mdd",0);
vp_addoption("direct_add",0);
vp_addoption("direct_9dd",0);
vp_addoption("direct_gdd",0);

vp_addoption("corporate_mdd",0);
vp_addoption("corporate_add",0);
vp_addoption("corporate_9dd",0);
vp_addoption("corporate_gdd",0);

vp_addoption("enable_coupon", "no");
vp_addoption("airtime_to_wallet", "no");
vp_addoption("airtime_to_cash", "no");
vp_addoption("mtn_airtime", "08012346789");
vp_addoption("glo_airtime", "08012346789");
vp_addoption("airtel_airtime", "08012346789");
vp_addoption("9mobile_airtime", "08012346789");
vp_addoption("airtime_to_wallet_charge", "0");
vp_addoption("airtime_to_cash_charge", "0");


vp_addoption("charge_method", "fixed");
vp_addoption("charge_method", "fixed");
vp_addoption("charge_method", "fixed");
vp_addoption("charge_method", "fixed");
vp_addoption("show_notify", "no");
vp_addoption("http_redirect", "true");
vp_addoption("global_security", "enabled");
vp_addoption("secur_mod", "calm");
vp_addoption("vp_ips_ban", "0.0.0.0,");
vp_addoption("vp_users_ban", "anonymous,hackers,demo");
vp_addoption("access_website", "true");
vp_addoption("access_user_dashboard", "true");
vp_addoption("access_country", "true");


vp_addoption("discount_method","direct");
vp_addoption("charge_back",0);
vp_addoption("wallet_to_wallet","yes");

vp_addoption("showlicense","none");

vp_addoption("manual_funding","No Message");

vp_addoption("reb", "yes");
vp_addoption("ppub", "Your Paystack Public Key");
vp_addoption("psec", "Your Paystack Secret Key");
vp_addoption("paychoice", "flutterwave");
vp_addoption("menucolo", "#cee8b8");
vp_addoption("dashboardcolo", "#ffff00");
vp_addoption("buttoncolo", "#ffff00");
vp_addoption("headcolo", "#4CAF50");
vp_addoption("sucreg", "/vpaccount");
vp_addoption("cairtimeb", "1");
vp_addoption("cdatab", "1");
vp_addoption("cdatabd", "1");
vp_addoption("cdatabc", "1");

vp_addoption("ccableb", "1");
vp_addoption("cbillb", "1");
vp_addoption("rairtimeb", "1");

vp_addoption("rdatab", "1");
vp_addoption("rdatabd", "1");
vp_addoption("rdatabc", "1");

vp_addoption("rcableb", "1");
vp_addoption("rbillb", "1");
vp_addoption("monnifyapikey","Your API KEY");
vp_addoption("monnifysecretkey","Your SECRET KEY");
vp_addoption("monnifycontractcode","Your Contract Code");
vp_addoption("monnifytestmode","false");



vp_addoption("airtime1_response_format_text","JSON");
vp_addoption("airtime1_response_format","json");
vp_addoption("airtime2_response_format_text","JSON");
vp_addoption("airtime2_response_format","json");
vp_addoption("airtime3_response_format_text","JSON");
vp_addoption("airtime3_response_format","json");
vp_addoption("data1_response_format_text","JSON");
vp_addoption("data1_response_format","json");
vp_addoption("data2_response_format_text","JSON");
vp_addoption("data2_response_format","json");
vp_addoption("data3_response_format_text","JSON");
vp_addoption("data3_response_format","json");
vp_addoption("cable_response_format_text","JSON");
vp_addoption("cable_response_format","json");
vp_addoption("bill_response_format_text","JSON");
vp_addoption("bill_response_format","json");


vp_addoption("airtime_head","not_concatenated");
vp_addoption("airtime_head2","not_concatenated");
vp_addoption("airtime_head3","not_concatenated");
vp_addoption("data_head","not_concatenated");
vp_addoption("data_head2","not_concatenated");
vp_addoption("data_head3","not_concatenated");
vp_addoption("cable_head","not_concatenated");
vp_addoption("bill_head","not_concatenated");




//SME
vp_updateoption("api0", 1);
vp_updateoption("api1", 2);
vp_updateoption("api2", 3);
vp_updateoption("api3", 4);
vp_updateoption("api4", 5);
vp_updateoption("api5", 6);
vp_updateoption("api6", 7);
vp_updateoption("api7", 8);
vp_updateoption("api8", 9);
vp_updateoption("api9", 10);
vp_updateoption("api10", 11);

vp_updateoption("aapi0", 12);
vp_updateoption("aapi1", 13);
vp_updateoption("aapi2", 14);
vp_updateoption("aapi3", 15);
vp_updateoption("aapi4", 16);
vp_updateoption("aapi5", 17);
vp_updateoption("aapi6", 18);
vp_updateoption("aapi7", 19);
vp_updateoption("aapi8", 20);
vp_updateoption("aapi9", 21);
vp_updateoption("aapi10", 22);

vp_updateoption("9api0", 23);
vp_updateoption("9api1", 24);
vp_updateoption("9api2", 25);
vp_updateoption("9api3", 26);
vp_updateoption("9api4", 27);
vp_updateoption("9api5", 28);
vp_updateoption("9api6", 29);
vp_updateoption("9api7", 30);
vp_updateoption("9api8", 31);
vp_updateoption("9api9", 32);
vp_updateoption("9api10", 33);

vp_updateoption("gapi0", 34);
vp_updateoption("gapi1", 35);
vp_updateoption("gapi2", 36);
vp_updateoption("gapi3", 37);
vp_updateoption("gapi4", 38);
vp_updateoption("gapi5", 39);
vp_updateoption("gapi6", 40);
vp_updateoption("gapi7", 41);
vp_updateoption("gapi8", 42);
vp_updateoption("gapi9", 43);
vp_updateoption("gapi10", 44);
//END SME


//CORPORATE
vp_updateoption("api20", 45);
vp_updateoption("api21", 46);
vp_updateoption("api22", 47);
vp_updateoption("api23", 48);
vp_updateoption("api24", 49);
vp_updateoption("api25", 50);
vp_updateoption("api26", 51);
vp_updateoption("api27", 52);
vp_updateoption("api28", 53);
vp_updateoption("api29", 54);
vp_updateoption("api210", 55);

vp_updateoption("aapi20", 56);
vp_updateoption("aapi21", 57);
vp_updateoption("aapi22", 58);
vp_updateoption("aapi23", 59);
vp_updateoption("aapi24", 60);
vp_updateoption("aapi25", 61);
vp_updateoption("aapi26", 62);
vp_updateoption("aapi27", 63);
vp_updateoption("aapi28", 64);
vp_updateoption("aapi29", 65);
vp_updateoption("aapi210", 66);

vp_updateoption("9api20", 67);
vp_updateoption("9api21", 68);
vp_updateoption("9api22", 69);
vp_updateoption("9api23", 70);
vp_updateoption("9api24", 71);
vp_updateoption("9api25", 72);
vp_updateoption("9api26", 73);
vp_updateoption("9api27", 74);
vp_updateoption("9api28", 75);
vp_updateoption("9api29", 76);
vp_updateoption("9api210", 77);

vp_updateoption("gapi20", 78);
vp_updateoption("gapi21", 79);
vp_updateoption("gapi22", 80);
vp_updateoption("gapi23", 81);
vp_updateoption("gapi24", 82);
vp_updateoption("gapi25", 83);
vp_updateoption("gapi26", 84);
vp_updateoption("gapi27", 85);
vp_updateoption("gapi28", 86);
vp_updateoption("gapi29", 87);
vp_updateoption("gapi210", 88);
//END CORPORATE


//GIFTING
vp_updateoption("api30", 89);
vp_updateoption("api31", 90);
vp_updateoption("api32", 91);
vp_updateoption("api33", 92);
vp_updateoption("api34", 93);
vp_updateoption("api35", 94);
vp_updateoption("api36", 95);
vp_updateoption("api37", 96);
vp_updateoption("api38", 97);
vp_updateoption("api39", 98);
vp_updateoption("api310", 99);

vp_updateoption("aapi30", 100);
vp_updateoption("aapi31", 101);
vp_updateoption("aapi32", 102);
vp_updateoption("aapi33", 103);
vp_updateoption("aapi34", 104);
vp_updateoption("aapi35", 105);
vp_updateoption("aapi36", 106);
vp_updateoption("aapi37", 107);
vp_updateoption("aapi38", 108);
vp_updateoption("aapi39", 109);
vp_updateoption("aapi310", 110);

vp_updateoption("9api30", 111);
vp_updateoption("9api31", 112);
vp_updateoption("9api32", 113);
vp_updateoption("9api33", 114);
vp_updateoption("9api34", 115);
vp_updateoption("9api35", 116);
vp_updateoption("9api36", 117);
vp_updateoption("9api37", 118);
vp_updateoption("9api38", 119);
vp_updateoption("9api39", 120);
vp_updateoption("9api310", 121);

vp_updateoption("gloapi30", 122);
vp_updateoption("gloapi31", 123);
vp_updateoption("gloapi32", 124);
vp_updateoption("gloapi33", 125);
vp_updateoption("gloapi34", 126);
vp_updateoption("gloapi35", 127);
vp_updateoption("gloapi36", 128);
vp_updateoption("gloapi37", 129);
vp_updateoption("gloapi38", 130);
vp_updateoption("gloapi39", 131);
vp_updateoption("gloapi310", 132);
vp_addoption("vpdebug","no");
vp_addoption("checkbal","yes");
vp_addoption('actkey','vtu');
vp_addoption("formwidth",100);
vp_addoption('frmad','block');
vp_addoption('vpid','00');
vp_addoption('vprun','block');
vp_addoption('vpfback','#7FDBFF');
vp_addoption('vptxt','#85144b');
vp_addoption('vpsub','#2ECC40');
vp_addoption('fr', '#AAAAAA');
vp_addoption('see','#DDDDDD');
vp_addoption('seea','hidden');
vp_addoption('suc','/successful');
vp_addoption('fail','/failed');
vp_addoption('resell','no');
vp_updateoption('suc','/successful');

/*
update_option("vtupress_options2","1");
}
*/
$option_array = json_decode(get_option("vp_options"),true);

vtupress_js_css_user_plain_admin();

echo'
<style>
.swal-button.swal-button--confirm {
    width: fit-content;
    padding: 10px !important;
}
 #cover-spin {
        position:fixed;
        width:100%;
        left:0;right:0;top:0;bottom:0;
        background-color: rgba(255,255,255,0.7);
        z-index:9999;
        /*display:none;*/
    }
#cover-spin::after {
        content:"";
        display:block;
        position:absolute;
        left:48%;top:40%;
        width:40px;height:40px;
        border-style:solid;
        border-color:black;
        border-top-color:transparent;
        border-width: 4px;
        border-radius:50%;
        -webkit-animation: spin .8s linear infinite;
        animation: spin .8s linear infinite;
    }
	
';
do_action('gateway_style');



echo'
</style>
<div id="cover-spin" >
	  
</div>

<div class="container-fluid">

<div class="btn-group btn-nav-head" role="group" aria-label="styles" style="max-width:100%; overflow:scroll;">
<div class="bg-primary">
<input type="checkbox" id="setairtime" class="btn scontrols" '.vp_option_array($option_array,"setairtime").'>
<a href="#airtime" role="button" id="airdi" class="btn btn-primary gateway-button">SET AIRTIME</a>
</div> 
<div class="bg-primary">
<input type="checkbox" id="setdata" class="btn scontrols" '.vp_option_array($option_array,"setdata").'>
<a href="#data" role="button" class="btn btn-primary gateway-button" id="datadi" >SET DATA</a>
</div>
';
if(is_plugin_active("bcmv/bcmv.php")){
	echo'
<div class="bg-primary">
<input type="checkbox" id="setcable" class="btn scontrols" '.vp_option_array($option_array,"setcable").'>
<a href="#cable" role="button" class="btn btn-primary gateway-button" id="cabledi" >SET CABLE</a>
</div> 
<div class="bg-primary">
<input type="checkbox" id="setbill" class="btn scontrols" '.vp_option_array($option_array,"setbill").'>
<a href="#bill" role="button" id="billdi" class="btn btn-primary gateway-button" >SET BILL</a>
</div>
';
}


do_action("gateway_button");

if(current_user_can("vtupress_access_importer")){
	echo'
<a href="#import" role="button" id="importdi" class="btn btn-primary gateway-button" >IMPORTER</a>
';
}

echo'
</div>


<script>

jQuery(".scontrols").change(function(){
	jQuery("#cover-spin").show();
	if(jQuery("#setairtime").is(":checked")){
		var airtime = "checked";
	}
	else{
		var airtime = "unchecked";
	}
	
	if(jQuery("#setdata").is(":checked")){
		var data = "checked";
	}
	else{
		var data = "unchecked";
	}

	if(jQuery("#setcable").is(":checked")){
		var cable = "checked";
	}
	else{
		var cable = "unchecked";
	}
	
	if(jQuery("#setbill").is(":checked")){
		var bill = "checked";
	}
	else{
		var bill = "unchecked";
	}
	
var obj  = {};
obj["set_control"] = "setcontrol";
obj["setairtime"] = airtime;
obj["setdata"] = data;
obj["setcable"] = cable;
obj["setbill"] = bill;

';
do_action("set_control");
echo'
jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/vend.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){

	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error",
  text: "Update Wasn\"t Successful",
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: "POST"
});


	
});


</script>

<br>
<br>
';


echo'
<easy class="container-fluid gateway_form" style="height:auto;">
<form method="post" class="form-control" >
<div id="easyaccess">

<div id="airtimeeasyaccess">

<div class="alert alert-primary mb-2" role="alert">
<b>AIRTIME NOTE:</b><br>
<ol>
<li>To Make A Data Type such as VTU become visible on frontend, kindly check the checkbox --- <input type="checkbox"> behind SET AIRTIME and [VTU] / [SHARE AND SELL] / [AWUF] or uncheck to make it disappear on frontend</li>
<li>To Set Discount, Scroll down to find the <span style="color:blue;">blue</span> bordered field --- <input type="checkbox" style="border: 3px solid blue;" >. Each field is next to a Network so set your discount as 2 for 2% in respect to the network</li>
<li>Always change credentials such as ApiKey whenever your import new vendor api configuration.</li>
</ol>
</div>

<div class="btn-group btn-nav-head mb-3" role="group" aria-label="styles" style="max-width:100%; overflow:scroll;">
<div class="bg-secondary">
<input type="checkbox" id="vtucontrol" class="btn controls" '.vp_option_array($option_array,"vtucontrol").'>
<input type="button" id="vtuairtime" value="VTU" class="btn btn-secondary">
</div>
<div class="bg-info">
<input type="checkbox" id="sharecontrol" class="btn controls" '.vp_option_array($option_array,"sharecontrol").'>
<input type="button" id="sharedairtime" value="SHARE AND SELL" class="btn btn-info">
</div>
<div class="bg-secondary">
<input type="checkbox" id="awufcontrol" class="btn controls" '.vp_option_array($option_array,"awufcontrol").'>
<input type="button" id="awufairtime" value="AWUF" class="btn btn-secondary">
</div>
</div>

<script>
jQuery(".controls").change(function(){
	jQuery("#cover-spin").show();
	if(jQuery("#vtucontrol").is(":checked")){
		var vtu = "checked";
	}
	else{
		var vtu = "unchecked";
	}
	
	if(jQuery("#sharecontrol").is(":checked")){
		var share = "checked";
	}
	else{
		var share = "unchecked";
	}

	if(jQuery("#awufcontrol").is(":checked")){
		var awuf = "checked";
	}
	else{
		var awuf = "unchecked";
	}
	
var obj  = {};
obj["airtime_control"] = "airtime";
obj["vtuvalue"] = vtu;
obj["sharevalue"] = share;
obj["awufvalue"] = awuf;


jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/vend.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){

	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error",
  text: "Update Wasn\"t Successful",
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: "POST"
});


	
});


</script>

<div id="vtuairtime">


<h3>VTU</h3>
<br>
<div class="alert alert-primary mb-2" role="alert">
'.vp_option_array($option_array,"vtu_info").'
</div>

<div class="input-group md-3">
<span class="input-group-text">Airtime BaseUrl</span>
<input type="text" id="airtimebaseurl" placeholder="" value="'.vp_option_array($option_array,"airtimebaseurl").'" name="airtimebaseurl" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Airtime EndPoint</span>
<input type="text" id="airtimeendpoint" placeholder="" value="'.vp_option_array($option_array,"airtimeendpoint").'" name="airtimeendpoint" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Airtime Request Method</span>
<input type="text" id="airtimerequesttext" name="airtimerequesttext" value="'.vp_option_array($option_array,"airtimerequesttext").'" readonly class="form-control">
<select name="airtimerequest" id="airtimerequest" class="input-group-text">
<option value="'.vp_option_array($option_array,"airtimerequest").'">Select</option>
<option value="get">GET 1</option>
<option value="post">GET 2</option>
<option value="post">POST</option>
</select>
</div>

<div class="input-group md-3">
<span class="input-group-text">Airtime Response Method</span>
<input type="text" id="airtimeresponsetext" name="airtimeresponsetext" value="'.vp_option_array($option_array,"airtime1_response_format_text").'" readonly class="form-control">
<select name="airtimeresponse" id="airtimeresponse" class="input-group-text">
<option value="'.vp_option_array($option_array,"airtime1_response_format").'">'.vp_option_array($option_array,"airtime1_response_format").'</option>
<option value="json">JSON</option>
<option value="plain">PLAIN</option>
</select>
<script>
jQuery("#airtimeresponse").on("change",function(){
	jQuery("#airtimeresponsetext").val(jQuery("#airtimeresponse option:selected").text());
});
</script>
</div>



<div class="input-group md-4">
<span class="input-group-text">Add Post Datas to Airtime Service?</span> 
<input type="text" value="'.vp_option_array($option_array,"airtimeaddpost").'" class="input-group-text airtimeaddpost2" readonly class="form-control">
<select name="airtimeaddpost" class="input-group-text airtimeaddpost">
<option value="'.vp_option_array($option_array,"airtimeaddpost").'">Select</option>
<option value="yes">YES</option>
<option value="no">No</option>
</select>
<script>
jQuery(".airtimeaddpost").on("change",function(){
	jQuery(".airtimeaddpost2").val(jQuery(".airtimeaddpost").val());
});
</script>
</div>
<br>
<label class="form-label">Header Authorization</label>
<br>
';
for($airtimeheaders=1; $airtimeheaders<=1; $airtimeheaders++){
	echo'
<div class="input-group md-3">
<select class="airtime-head" name="airtimehead">
<option value="'.vp_option_array($option_array,"airtime_head").'">'.vp_option_array($option_array,"airtime_head").'</option>
<option value="not_concatenated">Not Concatenated</option>
<option value="concatenated">Concatenated</option>
</select>
<span class="input-group-text">Key</span> 	
<input type="text" name="airtimehead'.$airtimeheaders.'" value="'.vp_option_array($option_array,"airtimehead".$airtimeheaders).'"  placeholder="Key" class="form-control">
<span class="input-group-text">Value</span> 
<input placeholder="Value" type="text" name="airtimevalue'.$airtimeheaders.'" value="'.vp_option_array($option_array,"airtimevalue".$airtimeheaders).'" class="form-control vtupostkey">
</div>
';
}
echo'
<br>
<label class="form-label">Other Headers</label>
<br>
';
for($vtuaddheaders=1; $vtuaddheaders<=4; $vtuaddheaders++){
	echo'
<div class="input-group md-3">
<span class="input-group-text">Key</span> 	
<input type="text" name="vtuaddheaders'.$vtuaddheaders.'" value="'.vp_option_array($option_array,"vtuaddheaders".$vtuaddheaders).'"  placeholder="Key" class="form-control">
<span class="input-group-text">Value</span> 
<input placeholder="Value" type="text" name="vtuaddvalue'.$vtuaddheaders.'" value="'.vp_option_array($option_array,"vtuaddvalue".$vtuaddheaders).'" class="form-control vtuaddvalue'.$vtuaddheaders.'">
</div>
';
}

echo'
<br>
<label class="form-label">AIRTIME POST DATAS</label>
<br>';

for($airtimepost=1; $airtimepost<=5; $airtimepost++){
echo'
<div class="input-group md-3">
<span class="input-group-text">Post Data '.$airtimepost.'</span> 
<input type="text" placeholder="Data" value="'.vp_option_array($option_array,"airtimepostdata".$airtimepost).'" name="airtimepostdata'.$airtimepost.'" class="form-control">
<span class="input-group-text">Post Value '.$airtimepost.'</span> 
<input type="text" placeholder="Value" value="'.vp_option_array($option_array,"airtimepostvalue".$airtimepost).'" name="airtimepostvalue'.$airtimepost.'" class="form-control airtimepostvalue'.$airtimepost.'">
</div>
';
}

echo'
<br>
<label class="form-label">Service Parameters</label>
<br>
<div class="input-group md-3">
<span class="input-group-text">Amount Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"airtimeamountattribute").'" name="airtimeamountattribute"  id="airtimeamountattribute" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Phone Number Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"airtimephoneattribute").'" name="airtimephoneattribute"  id="airtimephoneattribute" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Network Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"airtimenetworkattribute").'" name="airtimenetworkattribute"  id="airtimenetworkattribute" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Request Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"arequest_id").'" name="arequest_id" class="form-control">
</div>

<br>
<label class="form-label">Success/Status Attribute</label><br>
<div class="input-group md-3">
<span class="input-group-text">Key</span>
<input type="text" value="'.vp_option_array($option_array,"airtimesuccesscode").'" name="airtimesuccesscode" placeholder="success value e.g success or status" class="form-control">
<span class="input-group-text">Value</span>
<input type="text" value="'.vp_option_array($option_array,"airtimesuccessvalue").'" name="airtimesuccessvalue" placeholder="success value" class="form-control"> 
<span class="input-group-text">Alternative Value</span>
<input type="text" value="'.vp_option_array($option_array,"airtimesuccessvalue2").'" name="airtimesuccessvalue2" placeholder="alternative success value" class="form-control">
</div>

<br>
<label class="form-label">Service IDs</label>
<br>
<div class="input-group md-3">
<span class="input-group-text">MTN</span>
<input type="text" value="'.vp_option_array($option_array,"airtimemtn").'" name="airtimemtn" id="airtimemtn" class="form-control">

</div>

<div class="input-group md-3">
<span class="input-group-text">GLO</span>
<input type="text" value="'.vp_option_array($option_array,"airtimeglo").'" name="airtimeglo" id="airtimeglo" class="form-control">

</div>

<div class="input-group md-3">
<span class="input-group-text">9MOBILE</span>
<input type="text" value="'.vp_option_array($option_array,"airtime9mobile").'" name="airtime9mobile"  id="airtime9mobile" class="form-control">

</div>

<div class="input-group md-3">
<span class="input-group-text">AIRTEL</span>
<input type="text" value="'.vp_option_array($option_array,"airtimeairtel").'" name="airtimeairtel"  id="airtimeairtel" class="form-control">

</div>

</div>



<div id="sharedairtime">

<h3>SHARED</h3>
<br>
<div class="alert alert-secondary mb-2" role="alert">
'.vp_option_array($option_array,"shared_info").'
</div>

<div class="input-group md-3">
<span class="input-group-text">Airtime BaseUrl</span>
<input type="text" id="sairtimebaseurl" placeholder="" value="'.vp_option_array($option_array,"sairtimebaseurl").'" name="sairtimebaseurl" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Airtime EndPoint</span>
<input type="text" id="sairtimeendpoint" placeholder="" value="'.vp_option_array($option_array,"sairtimeendpoint").'" name="sairtimeendpoint" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Airtime Request Method</span>
<input type="text" id="sairtimerequesttext" name="sairtimerequesttext" value="'.vp_option_array($option_array,"sairtimerequesttext").'" readonly class="form-control">
<select name="sairtimerequest" id="sairtimerequest" class="input-group-text sairtimerequest">
<option value="'.vp_option_array($option_array,"sairtimerequest").'">Select</option>
<option value="get">GET 1</option>
<option value="post">GET 2</option>
<option value="post">POST</option>
</select>
<script>
jQuery(".sairtimerequest").on("change",function(){
	jQuery("#sairtimerequesttext").val(jQuery(".sairtimerequest option:selected").text());
});
</script>
</div>

<div class="input-group md-3">
<span class="input-group-text">Airtime Response Method</span>
<input type="text" id="airtimeresponsetext2" name="airtimeresponsetext2" value="'.vp_option_array($option_array,"airtime2_response_format_text").'" readonly class="form-control">
<select name="airtimeresponse2" id="airtimeresponse2" class="input-group-text">
<option value="'.vp_option_array($option_array,"airtime2_response_format").'">'.vp_option_array($option_array,"airtime2_response_format").'</option>
<option value="json">JSON</option>
<option value="plain">PLAIN</option>
</select>
<script>
jQuery("#airtimeresponse2").on("change",function(){
	jQuery("#airtimeresponsetext2").val(jQuery("#airtimeresponse2 option:selected").text());
});
</script>
</div>

<div class="input-group md-4">
<span class="input-group-text">Add Post Datas to Airtime Service?</span> 
<input type="text" value="'.vp_option_array($option_array,"sairtimeaddpost").'" class="input-group-text sairtimeaddpost2" readonly class="form-control">
<select name="sairtimeaddpost" class="input-group-text sairtimeaddpost">
<option value="'.vp_option_array($option_array,"sairtimeaddpost").'">Select</option>
<option value="yes">YES</option>
<option value="no">No</option>
</select>
<script>
jQuery(".sairtimeaddpost").on("change",function(){
	jQuery(".sairtimeaddpost2").val(jQuery(".sairtimeaddpost").val());
});
</script>
</div>
<br>
<label class="form-label">Header Authorization</label>
<br>
';
for($airtimeheaders=1; $airtimeheaders<=1; $airtimeheaders++){
	echo'
<div class="input-group md-3">
<select class="airtime-head2" name="airtimehead2">
<option value="'.vp_option_array($option_array,"airtime_head2").'">'.vp_option_array($option_array,"airtime_head2").'</option>
<option value="not_concatenated">Not Concatenated</option>
<option value="concatenated">Concatenated</option>
</select>
<span class="input-group-text">Key</span> 	
<input type="text" name="sairtimehead'.$airtimeheaders.'" value="'.vp_option_array($option_array,"sairtimehead".$airtimeheaders).'"  placeholder="Key" class="form-control">
<span class="input-group-text">Value</span> 
<input placeholder="Value" type="text" name="sairtimevalue'.$airtimeheaders.'" value="'.vp_option_array($option_array,"sairtimevalue".$airtimeheaders).'" class="form-control sharedpostkey">
</div>
';
}

echo'
<br>
<label class="form-label">Other Headers</label>
<br>
';
for($shareaddheaders=1; $shareaddheaders<=4; $shareaddheaders++){
	echo'
<div class="input-group md-3">
<span class="input-group-text">Key</span> 	
<input type="text" name="shareaddheaders'.$shareaddheaders.'" value="'.vp_option_array($option_array,"shareaddheaders".$shareaddheaders).'"  placeholder="Key" class="form-control">
<span class="input-group-text">Value</span> 
<input placeholder="Value" type="text" name="shareaddvalue'.$shareaddheaders.'" value="'.vp_option_array($option_array,"shareaddvalue".$shareaddheaders).'" class="form-control shareaddvalue'.$shareaddheaders.'">
</div>
';
}

echo'
<br>
<label class="form-label">AIRTIME POST DATAS</label>
<br>';

for($airtimepost=1; $airtimepost<=5; $airtimepost++){
echo'
<div class="input-group md-3">
<span class="input-group-text">Post Data '.$airtimepost.'</span> 
<input type="text" placeholder="Data" value="'.vp_option_array($option_array,"sairtimepostdata".$airtimepost).'" name="sairtimepostdata'.$airtimepost.'" class="form-control">
<span class="input-group-text">Post Value '.$airtimepost.'</span> 
<input type="text" placeholder="Value" value="'.vp_option_array($option_array,"sairtimepostvalue".$airtimepost).'" name="sairtimepostvalue'.$airtimepost.'" class="form-control sairtimepostvalue'.$airtimepost.'">
</div>
';
}

echo'
<br>
<label class="form-label">Service Parameters</label>
<br>
<div class="input-group md-3">
<span class="input-group-text">Amount Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"sairtimeamountattribute").'" name="sairtimeamountattribute"  id="sairtimeamountattribute" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Phone Number Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"sairtimephoneattribute").'" name="sairtimephoneattribute"  id="sairtimephoneattribute" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Network Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"sairtimenetworkattribute").'" name="sairtimenetworkattribute"  id="sairtimenetworkattribute" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Request Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"sarequest_id").'" name="sarequest_id" class="form-control">
</div>

<br>
<label class="form-label">Success/Status Attribute</label><br>
<div class="input-group md-3">
<span class="input-group-text">Key</span>
<input type="text" value="'.vp_option_array($option_array,"sairtimesuccesscode").'" name="sairtimesuccesscode" placeholder="success value e.g success or status" class="form-control">
<span class="input-group-text">Value</span>
<input type="text" value="'.vp_option_array($option_array,"sairtimesuccessvalue").'" name="sairtimesuccessvalue" placeholder="success value" class="form-control"> 
<span class="input-group-text">Alternative Value</span>
<input type="text" value="'.vp_option_array($option_array,"sairtimesuccessvalue2").'" name="sairtimesuccessvalue2" placeholder="alternative success value" class="form-control">
</div>

<br>
<label class="form-label">Service IDs</label>
<br>
<div class="input-group md-3">
<span class="input-group-text">MTN</span>
<input type="text" value="'.vp_option_array($option_array,"sairtimemtn").'" name="sairtimemtn" id="sairtimemtn" class="form-control">

</div>

<div class="input-group md-3">
<span class="input-group-text">GLO</span>
<input type="text" value="'.vp_option_array($option_array,"sairtimeglo").'" name="sairtimeglo" id="sairtimeglo" class="form-control">

</div>

<div class="input-group md-3">
<span class="input-group-text">9MOBILE</span>
<input type="text" value="'.vp_option_array($option_array,"sairtime9mobile").'" name="sairtime9mobile"  id="sairtime9mobile" class="form-control">

</div>

<div class="input-group md-3">
<span class="input-group-text">AIRTEL</span>
<input type="text" value="'.vp_option_array($option_array,"sairtimeairtel").'" name="sairtimeairtel"  id="sairtimeairtel" class="form-control">

</div>

</div>



<div id="awufairtime">

<h3>AWUF</h3><br>
<div class="alert alert-success mb-2" role="alert">
'.vp_option_array($option_array,"awuf_info").'
</div>

<div class="input-group md-3">
<span class="input-group-text">Airtime BaseUrl</span>
<input type="text" id="wairtimebaseurl" placeholder="" value="'.vp_option_array($option_array,"wairtimebaseurl").'" name="wairtimebaseurl" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Airtime EndPoint</span>
<input type="text" id="wairtimeendpoint" placeholder="" value="'.vp_option_array($option_array,"wairtimeendpoint").'" name="wairtimeendpoint" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Airtime Request Method</span>
<input type="text" id="wairtimerequesttext" name="wairtimerequesttext" value="'.vp_option_array($option_array,"wairtimerequesttext").'" readonly class="form-control">
<select name="wairtimerequest" id="wairtimerequest" class="input-group-text wairtimerequest">
<option value="'.vp_option_array($option_array,"wairtimerequest").'">Select</option>
<option value="get">GET 1</option>
<option value="post">GET 2</option>
<option value="post">POST</option>
</select>
<script>
jQuery(".wairtimerequest").on("change",function(){
	jQuery("#wairtimerequesttext").val(jQuery(".wairtimerequest option:selected").text());
});
</script>
</div>

<div class="input-group md-3">
<span class="input-group-text">Airtime Response Method</span>
<input type="text" id="airtimeresponsetext3" name="airtimeresponsetext3" value="'.vp_option_array($option_array,"airtime3_response_format_text").'" readonly class="form-control">
<select name="airtimeresponse3" id="airtimeresponse3" class="input-group-text">
<option value="'.vp_option_array($option_array,"airtime3_response_format").'">'.vp_option_array($option_array,"airtime3_response_format").'</option>
<option value="json">JSON</option>
<option value="plain">PLAIN</option>
</select>
<script>
jQuery("#airtimeresponse3").on("change",function(){
	jQuery("#airtimeresponsetext3").val(jQuery("#airtimeresponse3 option:selected").text());
});
</script>
</div>


<div class="input-group md-4">
<span class="input-group-text">Add Post Datas to Airtime Service?</span> 
<input type="text" value="'.vp_option_array($option_array,"wairtimeaddpost").'" class="input-group-text wairtimeaddpost2" readonly class="form-control">
<select name="wairtimeaddpost" class="input-group-text wairtimeaddpost">
<option value="'.vp_option_array($option_array,"wairtimeaddpost").'">Select</option>
<option value="yes">YES</option>
<option value="no">No</option>
</select>
<script>
jQuery(".wairtimeaddpost").on("change",function(){
	jQuery(".wairtimeaddpost2").val(jQuery(".wairtimeaddpost").val());
});
</script>
</div>
<br>
<label class="form-label">Header Authorization</label>
<br>
';
for($airtimeheaders=1; $airtimeheaders<=1; $airtimeheaders++){
	echo'
<div class="input-group md-3">
<select class="airtime-head3" name="airtimehead3">
<option value="'.vp_option_array($option_array,"airtime_head3").'">'.vp_option_array($option_array,"airtime_head3").'</option>
<option value="not_concatenated">Not Concatenated</option>
<option value="concatenated">Concatenated</option>
</select>
<span class="input-group-text">Key</span> 	
<input type="text" name="wairtimehead'.$airtimeheaders.'" value="'.vp_option_array($option_array,"wairtimehead".$airtimeheaders).'"  placeholder="Key" class="form-control">
<span class="input-group-text">Value</span> 
<input placeholder="Value" type="text" name="wairtimevalue'.$airtimeheaders.'" value="'.vp_option_array($option_array,"wairtimevalue".$airtimeheaders).'" class="form-control awufpostkey">
</div>
';
}
echo'
<br>
<label class="form-label">Other Headers</label>
<br>
';
for($awufaddheaders=1; $awufaddheaders<=4; $awufaddheaders++){
	echo'
<div class="input-group md-3">
<span class="input-group-text">Key</span> 	
<input type="text" name="awufaddheaders'.$awufaddheaders.'" value="'.vp_option_array($option_array,"awufaddheaders".$awufaddheaders).'"  placeholder="Key" class="form-control">
<span class="input-group-text">Value</span> 
<input placeholder="Value" type="text" name="awufaddvalue'.$awufaddheaders.'" value="'.vp_option_array($option_array,"awufaddvalue".$awufaddheaders).'" class="form-control awufaddvalue'.$awufaddheaders.'">
</div>
';
}

echo'
<br>
<label class="form-label">AIRTIME POST DATAS</label>
<br>';

for($airtimepost=1; $airtimepost<=5; $airtimepost++){
echo'
<div class="input-group md-3">
<span class="input-group-text">Post Data '.$airtimepost.'</span> 
<input type="text" placeholder="Data" value="'.vp_option_array($option_array,"wairtimepostdata".$airtimepost).'" name="wairtimepostdata'.$airtimepost.'" class="form-control">
<span class="input-group-text">Post Value '.$airtimepost.'</span> 
<input type="text" placeholder="Value" value="'.vp_option_array($option_array,"wairtimepostvalue".$airtimepost).'" name="wairtimepostvalue'.$airtimepost.'" class="form-control wairtimepostvalue'.$airtimepost.'">
</div>
';
}

echo'
<br>
<label class="form-label">Service Parameters</label>
<br>
<div class="input-group md-3">
<span class="input-group-text">Amount Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"wairtimeamountattribute").'" name="wairtimeamountattribute"  id="wairtimeamountattribute" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Phone Number Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"wairtimephoneattribute").'" name="wairtimephoneattribute"  id="wairtimephoneattribute" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Network Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"wairtimenetworkattribute").'" name="wairtimenetworkattribute"  id="wairtimenetworkattribute" class="form-control">
</div>

<div class="input-group md-3">
<span class="input-group-text">Request Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"warequest_id").'" name="warequest_id" class="form-control">
</div>

<br>
<label class="form-label">Success/Status Attribute</label><br>
<div class="input-group md-3">
<span class="input-group-text">Key</span>
<input type="text" value="'.vp_option_array($option_array,"wairtimesuccesscode").'" name="wairtimesuccesscode" placeholder="success value e.g success or status" class="form-control">
<span class="input-group-text">Value</span>
<input type="text" value="'.vp_option_array($option_array,"wairtimesuccessvalue").'" name="wairtimesuccessvalue" placeholder="success value" class="form-control"> 
<span class="input-group-text">Alternative Value</span>
<input type="text" value="'.vp_option_array($option_array,"wairtimesuccessvalue2").'" name="wairtimesuccessvalue2" placeholder="alternative success value" class="form-control">
</div>

<br>
<label class="form-label">Service IDs</label>
<br>
<div class="input-group md-3">
<span class="input-group-text">MTN</span>
<input type="text" value="'.vp_option_array($option_array,"wairtimemtn").'" name="wairtimemtn" id="wairtimemtn" class="form-control">

</div>

<div class="input-group md-3">
<span class="input-group-text">GLO</span>
<input type="text" value="'.vp_option_array($option_array,"wairtimeglo").'" name="wairtimeglo" id="wairtimeglo" class="form-control">

</div>

<div class="input-group md-3">
<span class="input-group-text">9MOBILE</span>
<input type="text" value="'.vp_option_array($option_array,"wairtime9mobile").'" name="wairtime9mobile"  id="wairtime9mobile" class="form-control">

</div>

<div class="input-group md-3">
<span class="input-group-text">AIRTEL</span>
<input type="text" value="'.vp_option_array($option_array,"wairtimeairtel").'" name="wairtimeairtel"  id="wairtimeairtel" class="form-control">

</div>

</div>
<!--                        END OF  EASY ACCESS                 -->
</div>
';






echo'

<div id="dataeasyaccess">
 <div class="alert alert-primary mb-2" role="alert">
<b>DATA NOTE:</b><br>
<ol>
<li>To Make A Data Type such as SME become visible on frontend, kindly check the checkbox --- <input type="checkbox"> behind SET DATA and [SME] / [DIRECT/GIFTING] / [CORPORATE] or uncheck to make it disappear on frontend</li>
<li>To Set Data Prices, Scroll down to find the <span style="color:green;">green</span> bordered field --- <input type="checkbox" style="border: 3px solid green;" >. Each field is next to a data plan so set the price in respect of the data plan it is next to</li>
<li>To Set Discount, Scroll down to find the <span style="color:blue;">blue</span> bordered field --- <input type="checkbox" style="border: 3px solid blue;" >. Each field is next to a Network so set your discount as 2 for 2% in respect to the network</li>
<li>To set Data Network USSD Code, fill the <span style="color:pink;">pink</span> bordered field --- <input type="checkbox" style="border: 3px solid pink;" >. Please SME USSD network code field is different from that of Direct and corporate (vice versa).</li>
<li>Always change credentials such as ApiKey whenever your import new vendor api configuration.</li>
</ol>
</div>
<!--///////////////////////////////////////////////////////////////////VTU DATA/////////////////////-->
<div class="btn-group btn-nav-head" role="group" aria-label="styles" style="max-width:100%; overflow:scroll;">
<div class="bg-secondary">
<input type="checkbox" id="smecontrol" class="btn dcontrols" '.vp_option_array($option_array,"smecontrol").' class="form-control">
<input type="button" id="shareddata" value="SHARED/VTU" class="btn btn-secondary" class="form-control">
</div>
<div class="bg-info">
<input type="checkbox" id="directcontrol" class="btn dcontrols" '.vp_option_array($option_array,"directcontrol").' class="form-control">
<input type="button" id="directdata" value="DIRECT/GIFTING" class="btn btn-info" class="form-control">
</div>
<div class="bg-secondary">
<input type="checkbox" id="corporatecontrol" class="btn dcontrols" '.vp_option_array($option_array,"corporatecontrol").' class="form-control">
<input type="button" id="corporatedata" value="CORPORATE GIFTING" class="btn btn-secondary" class="form-control">
</div>
</div>

<script>
jQuery(".dcontrols").change(function(){
	jQuery("#cover-spin").show();
	if(jQuery("#smecontrol").is(":checked")){
		var sme = "checked";
	}
	else{
		var sme = "unchecked";
	}
	
	if(jQuery("#directcontrol").is(":checked")){
		var direct = "checked";
	}
	else{
		var direct = "unchecked";
	}

	if(jQuery("#corporatecontrol").is(":checked")){
		var corporate = "checked";
	}
	else{
		var corporate = "unchecked";
	}
	
var obj  = {};
obj["data_control"] = "data";
obj["smevalue"] = sme;
obj["directvalue"] = direct;
obj["corporatevalue"] = corporate;


jQuery.ajax({
  url: "'.esc_url(plugins_url('vtupress/vend.php')).'",
  data: obj,
  dataType: "json",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data.status == "100" ){

	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	 swal({
  title: "Error",
  text: "Update Wasn\"t Successful",
  icon: "error",
  button: "Okay",
});
	  }
  },
  type: "POST"
});


	
});


</script>



<div id="shareddata">


<h3>SME</h3><br>
 <div class="alert alert-danger mb-2" role="alert">
'.vp_option_array($option_array,"sme_info").'
</div>

<div class="input-group mb-3">
<span class="input-group-text">DATA BaseUrl</span>
<input type="text" id="databaseurl" placeholder="" value="'.vp_option_array($option_array,"databaseurl").'" name="databaseurl" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">DATA EndPoint</span>
<input type="text" id="dataendpoint" placeholder="" value="'.vp_option_array($option_array,"dataendpoint").'" name="dataendpoint" class="form-control">
</div>


<div class="input-group mb-3">
<span class="input-group-text">DATA Request Method</span>
<input type="text" id="datarequesttext" name="datarequesttext" value="'.vp_option_array($option_array,"datarequesttext").'" readonly class="form-control"><br>
<select name="datarequest" id="datarequest" >
<option value="'.vp_option_array($option_array,"datarequest").'">Select</option>
<option value="get">GET 1</option>
<option value="post">GET 2</option>
<option value="post">POST</option>
</select>
</div>


<div class="input-group md-3">
<span class="input-group-text">Data Response Method</span>
<input type="text" id="dataresponsetext" name="dataresponsetext" value="'.vp_option_array($option_array,"data1_response_format_text").'" readonly class="form-control">
<select name="dataresponse" id="dataresponse" class="input-group-text">
<option value="'.vp_option_array($option_array,"data1_response_format").'">'.vp_option_array($option_array,"data1_response_format").'</option>
<option value="json">JSON</option>
<option value="plain">PLAIN</option>
</select>
<script>
jQuery("#dataresponse").on("change",function(){
	jQuery("#dataresponsetext").val(jQuery("#dataresponse option:selected").text());
});
</script>
</div>

<div class="input-group mb-3">
<span class="input-group-text">Add Post Data To Service?</span>
<input type="text" value="'.vp_option_array($option_array,"dataaddpost").'" class="dataaddpost2" readonly class="form-control"><br>
<select name="dataaddpost" class="dataaddpost">
<option value="'.vp_option_array($option_array,"dataaddpost").'">Select</option>
<option value="yes">YES</option>
<option value="no">No</option>
<script>
jQuery(".dataaddpost").on("change",function(){
	jQuery(".dataaddpost2").val(jQuery(".dataaddpost option:selected").val());
});
</script>
</select>
</div>
<div class="input-group mb-3">
<span class="input-group-text">Avaialable Networks</span>
<input type="text" class="form-control" name="sme_visible_networks" value="'.vp_option_array($option_array,"sme_visible_networks").'">
</div>
<br>

<label class="form-label">Header Authorization</label>
<br>
';
for($dataheaders=1; $dataheaders<=1; $dataheaders++){
	echo'
<div class="input-group mb-3">
<select class="data-head" name="datahead">
<option value="'.vp_option_array($option_array,"data_head").'">'.vp_option_array($option_array,"data_head").'</option>
<option value="not_concatenated">Not Concatenated</option>
<option value="concatenated">Concatenated</option>
</select>
<span class="input-group-text">Key</span>
<input type="text" name="datahead'.$dataheaders.'" value="'.vp_option_array($option_array,"datahead".$dataheaders).'"  placeholder="Key" class="form-control"> 
<span class="input-group-text">Value</span>
<input placeholder="Value" type="text" name="datavalue'.$dataheaders.'" value="'.vp_option_array($option_array,"datavalue".$dataheaders).'" class="form-control smepostkey">
</div>
<br>
';
}
echo'
<br>
<label class="form-label">Other Headers</label>
<br>
';
for($smeaddheaders=1; $smeaddheaders<=4; $smeaddheaders++){
	echo'
<div class="input-group md-3">
<span class="input-group-text">Key</span> 	
<input type="text" name="smeaddheaders'.$smeaddheaders.'" value="'.vp_option_array($option_array,"smeaddheaders".$smeaddheaders).'"  placeholder="Key" class="form-control">
<span class="input-group-text">Value</span> 
<input placeholder="Value" type="text" name="smeaddvalue'.$smeaddheaders.'" value="'.vp_option_array($option_array,"smeaddvalue".$smeaddheaders).'" class="form-control smeaddvalue'.$smeaddheaders.'">
</div>
';
}

echo'
<label class="form-label">DATA POST DATAS</label>
<br>';

for($datapost=1; $datapost<=5; $datapost++){
echo'
<div class="input-group mb-3">
<span class="input-group-text">Post Data '.$datapost.'</span>
<input type="text" placeholder="Data" value="'.vp_option_array($option_array,"datapostdata".$datapost).'" name="datapostdata'.$datapost.'" class="form-control">
<span class="input-group-text">Post Value '.$datapost.'</span>
<input type="text" placeholder="Value" value="'.vp_option_array($option_array,"datapostvalue".$datapost).'" name="datapostvalue'.$datapost.'" class="form-control datapostvalue'.$datapost.'"><br>
</div>
';
}
echo'
<br>
<div class="input-group mb-3">
<span class="input-group-text">Phone Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"dataphoneattribute").'" name="dataphoneattribute"  id="dataphoneattribute" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Network Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"datanetworkattribute").'" name="datanetworkattribute"  id="datanetworkattribute" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Amount Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"dataamountattribute").'" name="dataamountattribute"  id="dataamountattribute" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Data Variation Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"cvariationattr").'" name="cvariationattr" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Request Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"request_id").'" name="request_id" class="form-control">
</div>


<div class="input-group mb-3">
<span class="input-group-text">MTN BALANCE USSD</span>
<input type="text" value="'.vp_option_array($option_array,"sme_mtn_balance").'" name="sme_mtn_balance" class="form-control" style="border: 3px solid pink;">
</div>

<div class="input-group mb-3">
<span class="input-group-text">GLO BALANCE USSD</span>
<input type="text" value="'.vp_option_array($option_array,"sme_glo_balance").'" name="sme_glo_balance" class="form-control" style="border: 3px solid pink;">
</div>

<div class="input-group mb-3">
<span class="input-group-text">9MOBILE BALANCE USSD</span>
<input type="text" value="'.vp_option_array($option_array,"sme_9mobile_balance").'" name="sme_9mobile_balance" class="form-control" style="border: 3px solid pink;">
</div>

<div class="input-group mb-3">
<span class="input-group-text">AIRTEL BALANCE USSD</span>
<input type="text" value="'.vp_option_array($option_array,"sme_airtel_balance").'" name="sme_airtel_balance" class="form-control" style="border: 3px solid pink;">
</div>


<br>
<br>
<label class="form-label">Service IDs</label>
<div class="input-group mb-3">
<span class="input-group-text">MTN Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"datamtn").'" name="datamtn" id="datamtn" class="form-control">

</div>
<div class="input-group mb-3">
<span class="input-group-text">GLO Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"dataglo").'" name="dataglo" id="dataglo" class="form-control">

</div>
<div class="input-group mb-3">
<span class="input-group-text">9MOBILE Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"data9mobile").'" name="data9mobile"  id="data9mobile" class="form-control">

</div>
<div class="input-group mb-3">
<span class="input-group-text">AIRTEL Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"dataairtel").'" name="dataairtel"  id="dataairtel" class="form-control">

</div>
<br>



<label class="form-label">Success/Status Attribute</label><br>
<div class="input-group mb-3">
<span class="input-group-text">Key</span>
<input type="text" value="'.vp_option_array($option_array,"datasuccesscode").'" name="datasuccesscode" placeholder="success key e.g success or status or 200" class="form-control">
<span class="input-group-text">Value</span>
<input type="text" value="'.vp_option_array($option_array,"datasuccessvalue").'" name="datasuccessvalue" placeholder="success value" class="form-control">
<span class="input-group-text">Alternative Value</span>
<input type="text" value="'.vp_option_array($option_array,"datasuccessvalue2").'" name="datasuccessvalue2" placeholder="Alternative success value" class="form-control">
</div>
<br>


<label class="form-label">MTN DATA PLAN</label><br>

';
for($i=0; $i<=10; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"cdata".$i).'"  name="cdata'.$i.'" class="form-control"> 
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"cdatan".$i).'"  name="cdatan'.$i.'" class="form-control">
<span class="input-group-text">PRICE</span>
<input type="number" value="'.vp_option_array($option_array,"cdatap".$i).'"  name="cdatap'.$i.'" class="form-control" style="border: 3px solid green;">
</div>
';
}
echo '
<label>Airtel DATA PLAN</label><br>

';

for($i=0; $i<=10; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"acdata".$i).'"  name="acdata'.$i.'" class="form-control">
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"acdatan".$i).'"  name="acdatan'.$i.'" class="form-control">
<span class="input-group-text">PRICE</span>
<input type="number" value="'.vp_option_array($option_array,"acdatap".$i).'"  name="acdatap'.$i.'" class="form-control" style="border: 3px solid green;">

</div>
';
}
echo '
<label>9Mobile DATA PLAN</label><br>

';

for($i=0; $i<=10; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"9cdata".$i).'"  name="9cdata'.$i.'" class="form-control">
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"9cdatan".$i).'"  name="9cdatan'.$i.'" class="form-control">
<span class="input-group-text">PRICE</span>
<input type="number" value="'.vp_option_array($option_array,"9cdatap".$i).'"  name="9cdatap'.$i.'" class="form-control" style="border: 3px solid green;">

</div>
';
}

echo'
<label>Glo DATA PLAN</label><br>

';

for($i=0; $i<=10; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"gcdata".$i).'"  name="gcdata'.$i.'" class="form-control">
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"gcdatan".$i).'"  name="gcdatan'.$i.'" class="form-control">
<span class="input-group-text">PRICE</span>
<input type="number" value="'.vp_option_array($option_array,"gcdatap".$i).'"  name="gcdatap'.$i.'" class="form-control" style="border: 3px solid green;">

</div>
';
}
echo '

</div>

<!--///////////////////////////////////////////////////DIRECT DATA/////////////////////////////////////////////-->
<div id="directdata">

<h3>DIRECT</h3><br>
<div class="alert alert-warning mb-2" role="alert">
'.vp_option_array($option_array,"direct_info").'
</div>

<div class="input-group mb-3">
<span class="input-group-text">DATA BaseUrl</span>
<input type="text" id="rdatabaseurl" placeholder="" value="'.vp_option_array($option_array,"rdatabaseurl").'" name="rdatabaseurl" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">DATA EndPoint</span>
<input type="text" id="rdataendpoint" placeholder="" value="'.vp_option_array($option_array,"rdataendpoint").'" name="rdataendpoint" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">DATA Request Method</span>
<input type="text" id="rdatarequesttext" name="rdatarequesttext" value="'.vp_option_array($option_array,"rdatarequesttext").'" readonly class="form-control">
<select name="rdatarequest" id="rdatarequest" >
<option value="'.vp_option_array($option_array,"rdatarequest").'">Select</option>
<option value="get">GET 1</option>
<option value="post">GET 2</option>
<option value="post">POST</option>
</select>
</div>

<div class="input-group md-3">
<span class="input-group-text">Data Response Method</span>
<input type="text" id="dataresponsetext2" name="dataresponsetext2" value="'.vp_option_array($option_array,"data2_response_format_text").'" readonly class="form-control">
<select name="dataresponse2" id="dataresponse2" class="input-group-text">
<option value="'.vp_option_array($option_array,"data2_response_format").'">'.vp_option_array($option_array,"data2_response_format").'</option>
<option value="json">JSON</option>
<option value="plain">PLAIN</option>
</select>
<script>
jQuery("#dataresponse2").on("change",function(){
	jQuery("#dataresponsetext2").val(jQuery("#dataresponse2 option:selected").text());
});
</script>
</div>

<div class="input-group mb-3">
<span class="input-group-text">Add Post Data To Service?</span>
<input type="text" value="'.vp_option_array($option_array,"rdataaddpost").'" class="rdataaddpost2" readOnly class="form-control"><br>
<select name="rdataaddpost" class="rdataaddpost">
<option value="'.vp_option_array($option_array,"rdataaddpost").'">Select</option>
<option value="yes">YES</option>
<option value="no">No</option>
</select>
<script>
jQuery(".rdataaddpost").on("change",function(){
	jQuery(".rdataaddpost2").val(jQuery(".rdataaddpost option:selected").val());
});
</script>
</div>
<div class="input-group mb-3">
<span class="input-group-text">Avaialable Networks</span>
<input type="text" class="form-control" name="direct_visible_networks" value="'.vp_option_array($option_array,"direct_visible_networks").'">
</div>
<br>

<label class="form-label">Header Authorization</label>
<br>
';
for($dataheaders=1; $dataheaders<=1; $dataheaders++){
	echo'
<div class="input-group mb-3">
<select class="data-head2" name="datahead2">
<option value="'.vp_option_array($option_array,"data_head2").'">'.vp_option_array($option_array,"data_head2").'</option>
<option value="not_concatenated">Not Concatenated</option>
<option value="concatenated">Concatenated</option>
</select>
<span class="input-group-text">Key</span>
<input type="text" name="rdatahead'.$dataheaders.'" value="'.vp_option_array($option_array,"rdatahead".$dataheaders).'"  placeholder="Key" class="form-control"> 
<span class="input-group-text">Value</span>
<input placeholder="Value" type="text" name="rdatavalue'.$dataheaders.'" value="'.vp_option_array($option_array,"rdatavalue".$dataheaders).'" class="form-control directpostkey">
</div>
<br>
';
}

echo'
<br>
<label class="form-label">Other Headers</label>
<br>
';
for($corporateaddheaders=1; $corporateaddheaders<=4; $corporateaddheaders++){
	echo'
<div class="input-group md-3">
<span class="input-group-text">Key</span> 	
<input type="text" name="corporateaddheaders'.$corporateaddheaders.'" value="'.vp_option_array($option_array,"corporateaddheaders".$corporateaddheaders).'"  placeholder="Key" class="form-control corporateaddheaders'.$corporateaddheaders.'">
<span class="input-group-text">Value</span> 
<input placeholder="Value" type="text" name="corporateaddvalue'.$corporateaddheaders.'" value="'.vp_option_array($option_array,"corporateaddvalue".$corporateaddheaders).'" class="form-control corporateaddvalue'.$corporateaddheaders.'">
</div>
';
}
echo'
<label class="form-label">DATA POST DATAS</label>
<br>';

for($datapost=1; $datapost<=5; $datapost++){
echo'
<div class="input-group mb-3">
<span class="input-group-text">Post Data '.$datapost.'</span>
<input type="text" placeholder="Data" value="'.vp_option_array($option_array,"rdatapostdata".$datapost).'" name="rdatapostdata'.$datapost.'" class="form-control">
<span class="input-group-text">Post Value '.$datapost.'</span>
<input type="text" placeholder="Value" value="'.vp_option_array($option_array,"rdatapostvalue".$datapost).'" name="rdatapostvalue'.$datapost.'" class="form-control rdatapostvalue'.$datapost.'">
</div>
';
}
echo'
<br>
<div class="input-group mb-3">
<span class="input-group-text">Phone Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"rdataphoneattribute").'" name="rdataphoneattribute"  id="rdataphoneattribute" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Network Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"rdatanetworkattribute").'" name="rdatanetworkattribute"  id="rdatanetworkattribute" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Amount Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"rdataamountattribute").'" name="rdataamountattribute"  id="rdataamountattribute" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Data Variation Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"rcvariationattr").'" name="rcvariationattr" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Request Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"rrequest_id").'" name="rrequest_id" class="form-control">
</div>

<div class="input-group mb-3">
<span class="input-group-text">MTN BALANCE USSD</span>
<input type="text" value="'.vp_option_array($option_array,"direct_mtn_balance").'" name="direct_mtn_balance" class="form-control" style="border: 3px solid pink;">
</div>

<div class="input-group mb-3">
<span class="input-group-text">GLO BALANCE USSD</span>
<input type="text" value="'.vp_option_array($option_array,"direct_glo_balance").'" name="direct_glo_balance" class="form-control" style="border: 3px solid pink;">
</div>

<div class="input-group mb-3">
<span class="input-group-text">9MOBILE BALANCE USSD</span>
<input type="text" value="'.vp_option_array($option_array,"direct_9mobile_balance").'" name="direct_9mobile_balance" class="form-control" style="border: 3px solid pink;">
</div>

<div class="input-group mb-3">
<span class="input-group-text">AIRTEL BALANCE USSD</span>
<input type="text" value="'.vp_option_array($option_array,"direct_airtel_balance").'" name="direct_airtel_balance" class="form-control" style="border: 3px solid pink;">
</div>

<br>
<br>
<label class="form-label">Service IDs</label>
<div class="input-group mb-3">
<span class="input-group-text">MTN Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"rdatamtn").'" name="rdatamtn" id="rdatamtn" class="form-control">

</div>
<div class="input-group mb-3">
<span class="input-group-text">GLO Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"rdataglo").'" name="rdataglo" id="rdataglo" class="form-control">

</div>
<div class="input-group mb-3">
<span class="input-group-text">9MOBILE Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"rdata9mobile").'" name="rdata9mobile"  id="rdata9mobile" class="form-control">

</div>
<div class="input-group mb-3">
<span class="input-group-text">AIRTEL Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"rdataairtel").'" name="rdataairtel"  id="rdataairtel" class="form-control">

</div>
<br>



<label class="form-label">Success/Status Attribute</label><br>
<div class="input-group mb-3">
<span class="input-group-text">Key</span>
<input type="text" value="'.vp_option_array($option_array,"rdatasuccesscode").'" name="rdatasuccesscode" placeholder="success key e.g success or status or 200" class="form-control">
<span class="input-group-text">Value</span>
<input type="text" value="'.vp_option_array($option_array,"rdatasuccessvalue").'" name="rdatasuccessvalue" placeholder="success value" class="form-control">
<span class="input-group-text">Alternative Value</span>
<input type="text" value="'.vp_option_array($option_array,"rdatasuccessvalue2").'" name="rdatasuccessvalue2" placeholder="Alternative success value" class="form-control">
</div>
<br>


<label class="form-label">MTN DATA PLAN</label><br>

';
for($i=0; $i<=10; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"rcdata".$i).'"  name="rcdata'.$i.'" class="form-control"> 
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"rcdatan".$i).'"  name="rcdatan'.$i.'" class="form-control">
<span class="input-group-text">PRICE</span>
<input type="number" value="'.vp_option_array($option_array,"rcdatap".$i).'"  name="rcdatap'.$i.'" class="form-control" style="border: 3px solid green;">

</div>
';
}
echo '
<label>Airtel DATA PLAN</label><br>

';

for($i=0; $i<=10; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"racdata".$i).'"  name="racdata'.$i.'" class="form-control">
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"racdatan".$i).'"  name="racdatan'.$i.'" class="form-control">
<span class="input-group-text">PRICE</span>
<input type="number" value="'.vp_option_array($option_array,"racdatap".$i).'"  name="racdatap'.$i.'" class="form-control" style="border: 3px solid green;">

</div>
';
}
echo '
<label>9Mobile DATA PLAN</label><br>

';

for($i=0; $i<=10; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"r9cdata".$i).'"  name="r9cdata'.$i.'" class="form-control">
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"r9cdatan".$i).'"  name="r9cdatan'.$i.'" class="form-control">
<span class="input-group-text">PRICE</span>
<input type="number" value="'.vp_option_array($option_array,"r9cdatap".$i).'"  name="r9cdatap'.$i.'" class="form-control" style="border: 3px solid green;">

</div>
';
}

echo'
<label>Glo DATA PLAN</label><br>

';

for($i=0; $i<=10; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"rgcdata".$i).'"  name="rgcdata'.$i.'" class="form-control">
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"rgcdatan".$i).'"  name="rgcdatan'.$i.'" class="form-control">
<span class="input-group-text">PRICE</span>
<input type="number" value="'.vp_option_array($option_array,"rgcdatap".$i).'"  name="rgcdatap'.$i.'" class="form-control" style="border: 3px solid green;">

</div>
';
}
echo '

</div>

<!--//////////////////////////////////////////////CORPORATE/////////////////////////////////////-->


<div id="corporatedata">


<h3>CORPORATE</h3><br>
<div class="alert alert-info mb-2" role="alert">
'.vp_option_array($option_array,"corporate_info").'
</div>

<div class="input-group mb-3">
<span class="input-group-text">DATA BaseUrl</span>
<input type="text" id="r2databaseurl" placeholder="" value="'.vp_option_array($option_array,"r2databaseurl").'" name="r2databaseurl" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">DATA EndPoint</span>
<input type="text" id="r2dataendpoint" placeholder="" value="'.vp_option_array($option_array,"r2dataendpoint").'" name="r2dataendpoint" class="form-control">
</div>


<div class="input-group mb-3">
<span class="input-group-text">DATA Request Method</span>
<input type="text" id="r2datarequesttext" name="r2datarequesttext" value="'.vp_option_array($option_array,"r2datarequesttext").'" readonly class="form-control">
<select name="r2datarequest" id="r2datarequest" >
<option value="'.vp_option_array($option_array,"r2datarequest").'">Select</option>
<option value="get">GET 1</option>
<option value="post">GET 2</option>
<option value="post">POST</option>
</select>
</div>

<div class="input-group md-3">
<span class="input-group-text">Data Response Method</span>
<input type="text" id="dataresponsetext3" name="dataresponsetext3" value="'.vp_option_array($option_array,"data3_response_format_text").'" readonly class="form-control">
<select name="dataresponse3" id="dataresponse3" class="input-group-text">
<option value="'.vp_option_array($option_array,"data3_response_format").'">'.vp_option_array($option_array,"data3_response_format").'</option>
<option value="json">JSON</option>
<option value="plain">PLAIN</option>
</select>
<script>
jQuery("#dataresponse3").on("change",function(){
	jQuery("#dataresponsetext3").val(jQuery("#dataresponse3 option:selected").text());
});
</script>
</div>


<div class="input-group mb-3">
<span class="input-group-text">Add Post Data To Service?</span>
<input type="text" value="'.vp_option_array($option_array,"r2dataaddpost").'" class="r2dataaddpost2" readOnly class="form-control"><br>
<select name="r2dataaddpost" class="r2dataaddpost">
<option value="'.vp_option_array($option_array,"r2dataaddpost").'">Select</option>
<option value="yes">YES</option>
<option value="no">No</option>
</select>
<script>
jQuery(".r2dataaddpost").on("change",function(){
	jQuery(".r2dataaddpost2").val(jQuery(".r2dataaddpost option:selected").val());
});
</script>
</div>
<div class="input-group mb-3">
<span class="input-group-text">Avaialable Networks</span>
<input type="text" class="form-control" name="corporate_visible_networks" value="'.vp_option_array($option_array,"corporate_visible_networks").'">
</div>
<br>

<label class="form-label">Header Authorization</label>
<br>
';
for($dataheaders=1; $dataheaders<=1; $dataheaders++){
	echo'
<div class="input-group mb-3">
<select class="data-head3" name="datahead3">
<option value="'.vp_option_array($option_array,"data_head3").'">'.vp_option_array($option_array,"data_head3").'</option>
<option value="not_concatenated">Not Concatenated</option>
<option value="concatenated">Concatenated</option>
</select>
<span class="input-group-text">Key</span>
<input type="text" name="r2datahead'.$dataheaders.'" value="'.vp_option_array($option_array,"r2datahead".$dataheaders).'"  placeholder="Key" class="form-control"> 
<span class="input-group-text">Value</span>
<input placeholder="Value" type="text" name="r2datavalue'.$dataheaders.'" value="'.vp_option_array($option_array,"r2datavalue".$dataheaders).'" class="form-control corporatepostkey">
</div>
<br>
';
}
echo'
<br>
<label class="form-label">Other Headers</label>
<br>
';
for($directaddheaders=1; $directaddheaders<=4; $directaddheaders++){
	echo'
<div class="input-group md-3">
<span class="input-group-text">Key</span> 	
<input type="text" name="directaddheaders'.$directaddheaders.'" value="'.vp_option_array($option_array,"directaddheaders".$directaddheaders).'"  placeholder="Key" class="form-control">
<span class="input-group-text">Value</span> 
<input placeholder="Value" type="text" name="directaddvalue'.$directaddheaders.'" value="'.vp_option_array($option_array,"directaddvalue".$directaddheaders).'" class="form-control directaddvalue'.$directaddheaders.'">
</div>
';
}

echo'
<label class="form-label">DATA POST DATAS</label>
<br>';

for($datapost=1; $datapost<=5; $datapost++){
echo'
<div class="input-group mb-3">
<span class="input-group-text">Post Data '.$datapost.'</span>
<input type="text" placeholder="Data" value="'.vp_option_array($option_array,"r2datapostdata".$datapost).'" name="r2datapostdata'.$datapost.'" class="form-control">
<span class="input-group-text">Post Value '.$datapost.'</span>
<input type="text" placeholder="Value" value="'.vp_option_array($option_array,"r2datapostvalue".$datapost).'" name="r2datapostvalue'.$datapost.'" class="form-control r2datapostvalue'.$datapost.'">
</div>
';
}
echo'
<br>
<div class="input-group mb-3">
<span class="input-group-text">Phone Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"r2dataphoneattribute").'" name="r2dataphoneattribute"  id="r2dataphoneattribute" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Network Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"r2datanetworkattribute").'" name="r2datanetworkattribute"  id="r2datanetworkattribute" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Amount Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"r2dataamountattribute").'" name="r2dataamountattribute"  id="r2dataamountattribute" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Data Variation Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"r2cvariationattr").'" name="r2cvariationattr" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Request Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"r2request_id").'" name="r2request_id" class="form-control">
</div>


<div class="input-group mb-3">
<span class="input-group-text">MTN BALANCE USSD</span>
<input type="text" value="'.vp_option_array($option_array,"corporate_mtn_balance").'" name="corporate_mtn_balance" class="form-control" style="border: 3px solid pink;">
</div>

<div class="input-group mb-3">
<span class="input-group-text">GLO BALANCE USSD</span>
<input type="text" value="'.vp_option_array($option_array,"corporate_glo_balance").'" name="corporate_glo_balance" class="form-control" style="border: 3px solid pink;">
</div>

<div class="input-group mb-3">
<span class="input-group-text">9MOBILE BALANCE USSD</span>
<input type="text" value="'.vp_option_array($option_array,"corporate_9mobile_balance").'" name="corporate_9mobile_balance" class="form-control" style="border: 3px solid pink;">
</div>

<div class="input-group mb-3">
<span class="input-group-text">AIRTEL BALANCE USSD</span>
<input type="text" value="'.vp_option_array($option_array,"corporate_airtel_balance").'" name="corporate_airtel_balance" class="form-control" style="border: 3px solid pink;">
</div>



<br>
<br>
<label class="form-label">Service IDs</label>
<div class="input-group mb-3">
<span class="input-group-text">MTN Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"r2datamtn").'" name="r2datamtn" id="r2datamtn" class="form-control">

</div>
<div class="input-group mb-3">
<span class="input-group-text">GLO Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"r2dataglo").'" name="r2dataglo" id="r2dataglo" class="form-control">

</div>
<div class="input-group mb-3">
<span class="input-group-text">9MOBILE Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"r2data9mobile").'" name="r2data9mobile"  id="r2data9mobile" class="form-control">

</div>
<div class="input-group mb-3">
<span class="input-group-text">AIRTEL Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"r2dataairtel").'" name="r2dataairtel"  id="r2dataairtel" class="form-control">

</div>
<br>



<label class="form-label">Success/Status Attribute</label><br>
<div class="input-group mb-3">
<span class="input-group-text">Key</span>
<input type="text" value="'.vp_option_array($option_array,"r2datasuccesscode").'" name="r2datasuccesscode" placeholder="success key e.g success or status or 200" class="form-control">
<span class="input-group-text">Value</span>
<input type="text" value="'.vp_option_array($option_array,"r2datasuccessvalue").'" name="r2datasuccessvalue" placeholder="success value" class="form-control">
<span class="input-group-text">Alternative Value</span>
<input type="text" value="'.vp_option_array($option_array,"r2datasuccessvalue2").'" name="r2datasuccessvalue2" placeholder="Alternative success value" class="form-control">
</div>
<br>


<label class="form-label">MTN DATA PLAN</label><br>

';
for($i=0; $i<=10; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"r2cdata".$i).'"  name="r2cdata'.$i.'" class="form-control"> 
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"r2cdatan".$i).'"  name="r2cdatan'.$i.'" class="form-control">
<span class="input-group-text">PRICE</span>
<input type="number" value="'.vp_option_array($option_array,"r2cdatap".$i).'"  name="r2cdatap'.$i.'" class="form-control" style="border: 3px solid green;">

</div>
';
}
echo '
<label>Airtel DATA PLAN</label><br>

';

for($i=0; $i<=10; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"r2acdata".$i).'"  name="r2acdata'.$i.'" class="form-control">
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"r2acdatan".$i).'"  name="r2acdatan'.$i.'" class="form-control">
<span class="input-group-text">PRICE</span>
<input type="number" value="'.vp_option_array($option_array,"r2acdatap".$i).'"  name="r2acdatap'.$i.'" class="form-control" style="border: 3px solid green;">

</div>
';
}
echo '
<label>9Mobile DATA PLAN</label><br>

';

for($i=0; $i<=10; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"r29cdata".$i).'"  name="r29cdata'.$i.'" class="form-control">
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"r29cdatan".$i).'"  name="r29cdatan'.$i.'" class="form-control">
<span class="input-group-text">PRICE</span>
<input type="number" value="'.vp_option_array($option_array,"r29cdatap".$i).'"  name="r29cdatap'.$i.'" class="form-control" style="border: 3px solid green;">

</div>
';
}

echo'
<label>Glo DATA PLAN</label><br>

';

for($i=0; $i<=10; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"r2gcdata".$i).'"  name="r2gcdata'.$i.'" class="form-control">
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"r2gcdatan".$i).'"  name="r2gcdatan'.$i.'" class="form-control">
<span class="input-group-text">PRICE</span>
<input type="number" value="'.vp_option_array($option_array,"r2gcdatap".$i).'"  name="r2gcdatap'.$i.'" class="form-control" style="border: 3px solid green;">

</div>
';
}
echo '

</div>



</div>

';








echo'

<div id="cableeasyaccess">
<div class="alert alert-primary mb-2" role="alert">
<b>CABLE NOTE:</b><br>
<ol>
<li>To Make cable service visible on frontend, kindly check the checkbox --- <input type="checkbox"> behind SET CABLE or uncheck to make it disappear on frontend</li>
<li>To Set Price, Scroll down to find the <span style="color:green;">green</span> bordered field --- <input type="checkbox" style="border: 3px solid green;" > next to each cable plan</li>
<li>To Set Discount, Scroll down to find the <span style="color:blue;">blue</span> bordered field --- <input type="checkbox" style="border: 3px solid blue;" > as 2 for 2%</li>
<li>Always change credentials such as ApiKey whenever your import new vendor api configuration.</li>
</ol>
</div>
WELCOME TO EASY ACCESS cable</br>
<div class="alert alert-light mb-2 border border-dark" role="alert">
'.vp_option_array($option_array,"cable_info").'
</div>

<div class="input-group mb-3">
<span class="input-group-text">Cable BaseUrl</span>
<input type="text" id="cablebaseurl" placeholder="" value="'.vp_option_array($option_array,"cablebaseurl").'" name="cablebaseurl" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Cable EndPoint</span>
<input type="text" id="cableendpoint" placeholder="" value="'.vp_option_array($option_array,"cableendpoint").'" name="cableendpoint" class="form-control">
</div>


<div class="input-group mb-3">
<span class="input-group-text">Cable Request Method</span>
<input type="text" id="cablerequesttext" name="cablerequesttext" value="'.vp_option_array($option_array,"cablerequesttext").'" readonly class="form-control">
<select name="cablerequest" id="cablerequest">
<option value="'.vp_option_array($option_array,"cablerequest").'">Select</option>
<option value="get">GET 1</option>
<option value="post">GET 2</option>
<option value="post">POST</option>
</select>
</div>

<div class="input-group md-3">
<span class="input-group-text">Cable Response Method</span>
<input type="text" id="cableresponsetext" name="cableresponsetext" value="'.vp_option_array($option_array,"cable_response_format_text").'" readonly class="form-control">
<select name="cableresponse" id="cableresponse" class="input-group-text">
<option value="'.vp_option_array($option_array,"cable_response_format").'">'.vp_option_array($option_array,"cable_response_format").'</option>
<option value="json">JSON</option>
<option value="plain">PLAIN</option>
</select>
<script>
jQuery("#cableresponse").on("change",function(){
	jQuery("#cableresponsetext").val(jQuery("#cableresponse option:selected").text());
});
</script>
</div>

<div class="input-group mb-3">
<span class="input-group-text">Add Post Datas To Cable Service?</span>
<input type="text" value="'.vp_option_array($option_array,"cableaddpost").'" class="cableaddpost2" readOnly class="form-control">
<select name="cableaddpost" class="cableaddpost">
<option value="'.vp_option_array($option_array,"cableaddpost").'">Select</option>
<option value="yes">YES</option>
<option value="no">No</option>
</select>
<script>
jQuery(".cableaddpost").on("change",function(){
	jQuery(".cableaddpost2").val(jQuery(".cableaddpost option:selected").val());
});
</script>
</div>
<br>

<label>Cable POST Datas</label>
<br>';

for($cablepost=1; $cablepost<=5; $cablepost++){
echo'
<div class="input-group mb-3">
<span class="input-group-text">Post Data</span>
<input type="text" placeholder="Data" value="'.vp_option_array($option_array,"cablepostdata".$cablepost).'" name="cablepostdata'.$cablepost.'" class="form-control">
<span class="input-group-text">Post Value</span>
<input type="text" placeholder="Value" value="'.vp_option_array($option_array,"cablepostvalue".$cablepost).'" name="cablepostvalue'.$cablepost.'" class="form-control cablepostvalue'.$cablepost.'">
</div>
';
}

echo'
<label class="form-label">Header Authorization</label>
<br>
';
for($cableheaders=1; $cableheaders<=1; $cableheaders++){
	echo'
<div class="input-group mb-3">
<select class="cable-head" name="cablehead">
<option value="'.vp_option_array($option_array,"cable_head").'">'.vp_option_array($option_array,"cable_head").'</option>
<option value="not_concatenated">Not Concatenated</option>
<option value="concatenated">Concatenated</option>
</select>
<span class="input-group-text">Key</span>
<input type="text" name="cablehead'.$cableheaders.'" value="'.vp_option_array($option_array,"cablehead".$cableheaders).'"  placeholder="cable" class="form-control">
<span class="input-group-text">Value</span>
<input placeholder="Value" type="text" name="cablevalue'.$cableheaders.'" value="'.vp_option_array($option_array,"cablevalue".$cableheaders).'" class="form-control cablepostkey">
</div>';
}
echo'
<br>
<label class="form-label">Other Headers</label>
<br>
';
for($cableaddheaders=1; $cableaddheaders<=4; $cableaddheaders++){
	echo'
<div class="input-group md-3">
<span class="input-group-text">Key</span> 	
<input type="text" name="cableaddheaders'.$cableaddheaders.'" value="'.vp_option_array($option_array,"cableaddheaders".$cableaddheaders).'"  placeholder="Key" class="form-control">
<span class="input-group-text">Value</span> 
<input placeholder="Value" type="text" name="cableaddvalue'.$cableaddheaders.'" value="'.vp_option_array($option_array,"cableaddvalue".$cableaddheaders).'" class="form-control cableaddvalue'.$cableaddheaders.'">
</div>
';
}
echo'
<div class="input-group mb-3">
<span class="input-group-text">REQUEST ID</span>
<input type="text" value="'.vp_option_array($option_array,"crequest_id").'" name="crequest_id" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">CABLE VARIATION ATTRIBUTE</span>
<input type="text" value="'.vp_option_array($option_array,"ccvariationattr").'" name="ccvariationattr" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">CABLE TYPE ATTRIBUTE</span>
<input type="text" value="'.vp_option_array($option_array,"ctypeattr").'" name="ctypeattr" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">IUC NUMBER ATTRIBUTE</span>
<input type="text" value="'.vp_option_array($option_array,"ciucattr").'" name="ciucattr" class="form-control">
</div>


<label>Success/Status Attribute</label>
<br>
<div class="input-group mb-3">
<span class="input-group-text">Key</span>
<input type="text" value="'.vp_option_array($option_array,"cablesuccesscode").'" name="cablesuccesscode" placeholder="success value e.g success or status" class="form-control">
<span class="input-group-text">Value</span>
<input type="text" value="'.vp_option_array($option_array,"cablesuccessvalue").'" name="cablesuccessvalue" placeholder="success value" class="form-control"> 
<span class="input-group-text">Alternative Value</span>
<input type="text" value="'.vp_option_array($option_array,"cablesuccessvalue2").'" name="cablesuccessvalue2" placeholder="Alternative success value" class="form-control"> 
</div>
<div class="input-group mb-3 visually-hidden">
<span class="input-group-text">AMOUNT ATTRIBUTE</span>
<input type="text" value="'.vp_option_array($option_array,"cableamountattribute").'" name="cableamountattribute" placeholder="enter your amount attribute" class="form-control">
</div>
<br>
';

for($j=0; $j<=3; $j++){
echo'
<div class="input-group mb-3">
<span class="input-group-text">Cable Name</span>
<input type="text" value="'.vp_option_array($option_array,"cablename".$j).'" name="cablename'.$j.'" readOnly class="form-control">
<span class="input-group-text">Cable Attribute/Id</span>
<input type="text" value="'.vp_option_array($option_array,"cableid".$j).'" name="cableid'.$j.'" placeholder="e.g gotv" class="form-control"><br>
</div>
';
}

for($i=0; $i<=35; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"ccable".$i).'"  name="ccable'.$i.'" class="form-control">
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"ccablen".$i).'"  name="ccablen'.$i.'" class="form-control">
<span class="input-group-text">PRICE</span>
<input type="number" value="'.vp_option_array($option_array,"ccablep".$i).'"  name="ccablep'.$i.'" class="form-control" style="border: 3px solid green;">
</div>
';
}
echo '
<div class="input-group mb-2">
<span class="input-group-text" id="basic-addon1">Cable Charge ₦</span>
<input type="text" name="cable_charge" class="form-control" value="'.vp_option_array($option_array,"cable_charge").'" class="form-control" style="border: 3px solid green;">
</div>

</div>
';

echo'

<div id="billeasyaccess">
<div class="alert alert-primary mb-2" role="alert">
<b>BILL NOTE:</b><br>
<ol>
<li>To Make bill service visible on frontend, kindly check the checkbox --- <input type="checkbox"> behind SET 8BILL or uncheck to make it disappear on frontend</li>
<li>To Set Discount, Scroll down to find the <span style="color:blue;">blue</span> bordered field --- <input type="checkbox" style="border: 3px solid blue;" > as 2 for 2%</li>
<li>Always change credentials such as ApiKey whenever your import new vendor api configuration.</li>
</ol>
</div>
WELCOME TO EASY ACCESS BILL</br>
<div class="alert alert-dark mb-2" role="alert">
'.vp_option_array($option_array,"bill_info").'
</div>
<div class="input-group mb-3">
<span class="input-group-text">Bill BaseUrl</span>
<input type="text" id="billbaseurl" placeholder="" value="'.vp_option_array($option_array,"billbaseurl").'" name="billbaseurl" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Bill EndPoint</span>
<input type="text" id="billendpoint" placeholder="" value="'.vp_option_array($option_array,"billendpoint").'" name="billendpoint" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">Request Method</span>
<input type="text" id="billrequesttext" name="billrequesttext" value="'.vp_option_array($option_array,"billrequesttext").'" readonly class="form-control">
<select name="billrequest" id="billrequest">
<option value="'.vp_option_array($option_array,"billrequest").'">Select</option>
<option value="get">GET 1</option>
<option value="post">GET 2</option>
<option value="post">POST</option>
</select>
</div>

<div class="input-group md-3">
<span class="input-group-text">Bill Response Method</span>
<input type="text" id="billresponsetext" name="billresponsetext" value="'.vp_option_array($option_array,"bill_response_format_text").'" readonly class="form-control">
<select name="billresponse" id="billresponse" class="input-group-text">
<option value="'.vp_option_array($option_array,"bill_response_format").'">'.vp_option_array($option_array,"bill_response_format").'</option>
<option value="json">JSON</option>
<option value="plain">PLAIN</option>
</select>
<script>
jQuery("#billresponse").on("change",function(){
	jQuery("#billresponsetext").val(jQuery("#billresponse option:selected").text());
});
</script>
</div>


<br>
<div class="input-group mb-3">
<span class="input-group-text">Add Post Datas To Bill Service?</span>
<input type="text"  value="'.vp_option_array($option_array,"billaddpost").'" readOnly class="form-control">
<select name="billaddpost">
<option value="'.vp_option_array($option_array,"billaddpost").'">Select</option>
<option value="yes">YES</option>
<option value="no">No</option>
</select>
</div>
<br>
<label>Bill POST datas</label>
<br>';

for($billpost=1; $billpost<=5; $billpost++){
echo'
<div class="input-group mb-3">
<span class="input-group-text">Post Data</span>
<input type="text" placeholder="bill" value="'.vp_option_array($option_array,"billpostdata".$billpost).'" name="billpostdata'.$billpost.'" class="form-control">
<span class="input-group-text">Post Value</span>
<input type="text" placeholder="Value" value="'.vp_option_array($option_array,"billpostvalue".$billpost).'" name="billpostvalue'.$billpost.'" class="form-control billpostvalue'.$billpost.'">
</div>
';
}
echo'
<label>Header Authorization</label>
<br>
';
for($billheaders=1; $billheaders<=1; $billheaders++){
	echo'
<div class="input-group mb-3">
<select class="bill-head" name="billhead">
<option value="'.vp_option_array($option_array,"bill_head").'">'.vp_option_array($option_array,"bill_head").'</option>
<option value="not_concatenated">Not Concatenated</option>
<option value="concatenated">Concatenated</option>
</select>
<span class="input-group-text">Key</span>
<input type="text" name="billhead'.$billheaders.'" value="'.vp_option_array($option_array,"billhead".$billheaders).'"  placeholder="bill" class="form-control">
<span class="input-group-text">Value</span>
<input placeholder="Value" type="text" name="billvalue'.$billheaders.'" value="'.vp_option_array($option_array,"billvalue".$billheaders).'" class="form-control billpostkey">
</div>
';
}

echo'
<br>
<label class="form-label">Other Headers</label>
<br>
';
for($billaddheaders=1; $billaddheaders<=4; $billaddheaders++){
	echo'
<div class="input-group md-3">
<span class="input-group-text">Key</span> 	
<input type="text" name="billaddheaders'.$billaddheaders.'" value="'.vp_option_array($option_array,"billaddheaders".$billaddheaders).'"  placeholder="Key" class="form-control">
<span class="input-group-text">Value</span> 
<input placeholder="Value" type="text" name="billaddvalue'.$billaddheaders.'" value="'.vp_option_array($option_array,"billaddvalue".$billaddheaders).'" class="form-control billaddvalue'.$billaddheaders.'">
</div>
';
}

echo'
<div class="input-group mb-3">
<span class="input-group-text">REQUEST ID</span>
<input type="text" value="'.vp_option_array($option_array,"brequest_id").'" name="brequest_id" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">BILL VARIATION ATTRIBUTE/ID</span>
<input type="text" value="'.vp_option_array($option_array,"cbvariationattr").'" name="cbvariationattr" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">BILL TYPE ATTRIBUTE/ID</span>
<input type="text" value="'.vp_option_array($option_array,"btypeattr").'" name="btypeattr" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">METER NUMBER ATTRIBUTE/ID</span>
<input type="text" value="'.vp_option_array($option_array,"cmeterattr").'" name="cmeterattr" class="form-control">
</div>
<div class="input-group mb-3">
<span class="input-group-text">AMOUNT ATTRIBUTE</span>
<input type="text" value="'.vp_option_array($option_array,"billamountattribute").'" name="billamountattribute" placeholder="enter your amount attribute" class="form-control">
</div>

<div class="input-group mb-3">
<span class="input-group-text">Meter Token ATTRIBUTE</span>
<input type="text" value="'.vp_option_array($option_array,"metertoken").'" name="metertoken" placeholder="enter your meter token key attribute" class="form-control">
</div>


<label>Success/Status Attribute</label><br>
<div class="input-group mb-3">
<span class="input-group-text">Key</span>
<input type="text" value="'.vp_option_array($option_array,"billsuccesscode").'" name="billsuccesscode" placeholder="success value e.g success or status" class="form-control">
<span class="input-group-text">Value</span>
<input type="text" value="'.vp_option_array($option_array,"billsuccessvalue").'" name="billsuccessvalue" placeholder="success value" class="form-control">
<span class="input-group-text">Alternative Value</span>
<input type="text" value="'.vp_option_array($option_array,"billsuccessvalue2").'" name="billsuccessvalue2" placeholder="Alternative success value" class="form-control"> 
</div>
<br>

<div class="input-group mb-3 visually-hidden">
<span class="input-group-text">PHONE ATTRIBUTE</span>
<input type="text" value="'.vp_option_array($option_array,"billphoneattribute").'" name="billphoneattribute" placeholder="enter your phone attribute" class="form-control">
</div>


';

for($j=0; $j<=3; $j++){
echo'
<div class="input-group mb-3">
<span class="input-group-text">DISCO TYPE NAME</span>
<input type="text" value="'.vp_option_array($option_array,"billname".$j).'" name="billname'.$j.'" placeholder="e.g Prepaid" class="form-control">
<span class="input-group-text">DISCO TYPE ID</span>
<input type="text" value="'.vp_option_array($option_array,"billid".$j).'" name="billid'.$j.'" placeholder="e.g prepaid" class="form-control">
</div>

';
}

for($i=0; $i<=35; $i++){
echo '
<div class="input-group mb-3">
<span class="input-group-text">ID</span>
<input type="text" value="'.vp_option_array($option_array,"cbill".$i).'"  name="cbill'.$i.'" class="form-control">
<span class="input-group-text">NAME</span>
<input type="text" value="'.vp_option_array($option_array,"cbilln".$i).'"  name="cbilln'.$i.'" class="form-control">
</div>
<br>
';
}

echo '
<div class="input-group mb-2">
<span class="input-group-text" id="basic-addon1">Bill Charge ₦</span>
<input type="text" name="bill_charge" class="form-control" value="'.vp_option_array($option_array,"bill_charge").'" class="form-control" style="border: 3px solid green;">
</div>

</div>
';



echo'

<!--FOR BILL 4RM BEGINING TO END -->
';
do_action("gateway_tab");
do_action("gateway_tab1");
do_action("gateway_tab2");
do_action("gateway_tab3");
echo'
</div>


';

echo'
<br>
<input type="button" value="Save Settings" name="saveauth" class="saveauth">
</form>
</easy>
<div id="importdiv">

';

vtupress_importvp();

echo'


</div>

<script>

jQuery(".smspostkey, .vtupostkey, .sharedpostkey, .awufpostkey, .smepostkey, .directpostkey, .corporatepostkey, .cablepostkey, .billpostkey").css({"background-color":"#0dcaf0","color":"white"});

jQuery(".vtuaddvalue1, .shareaddvalue1, .awufaddvalue1, .smeaddvalue1, .directaddvalue1, .corporateaddvalue1, .cableaddvalue1, .billaddvalue1").css({"background-color":"pink","color":"white"});

jQuery(".vtuaddvalue2, .shareaddvalue2, .awufaddvalue2, .smeaddvalue2, .directaddvalue2, .corporateaddvalue2, .cableaddvalue2, .billaddvalue2").css({"background-color":"purple","color":"white"});

jQuery(".smspostvalue1, .airtimepostvalue1, .sairtimepostvalue1, .wairtimepostvalue1, .datapostvalue1, .rdatapostvalue1, .r2datapostvalue1, .cablepostvalue1, .billpostvalue1").css({"background-color":"#ffc107","color":"white"});

jQuery(".smspostvalue2, .airtimepostvalue2, .sairtimepostvalue2, .wairtimepostvalue2, .datapostvalue2, .rdatapostvalue2, .r2datapostvalue2, .cablepostvalue2, .billpostvalue2").css({"background-color":"#198754","color":"white"});



jQuery("#wpfooter").hide();

jQuery(".saveauth").click(function(){

jQuery("#cover-spin").show();
	
var obj = {};
var toatl_input = jQuery(".gateway_form input,.gateway_form select").length;
var run_obj;

for(run_obj = 0; run_obj <= toatl_input; run_obj++){
var current_input = jQuery(".gateway_form input,.gateway_form select").eq(run_obj);


var obj_name = current_input.attr("name");
var obj_value = current_input.val();

if(typeof obj_name !== typeof undefined && obj_name !== false){
obj[obj_name] = obj_value;
}


	
}

jQuery.ajax({
  url: "'.esc_url(plugins_url("vtupress/saveauth.php")).'",
  data: obj,
  dataType: "text",
  "cache": false,
  "async": true,
  error: function (jqXHR, exception) {
	  jQuery("#cover-spin").hide();
        var msg = "";
        if (jqXHR.status === 0) {
            msg = "No Connection.\n Verify Network.";
     swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
  
        } else if (jqXHR.status == 404) {
            msg = "Requested page not found. [404]";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (jqXHR.status == 500) {
            msg = "Internal Server Error [500].";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "parsererror") {
            msg = "Requested JSON parse failed.";
			   swal({
  title: msg,
  text: jqXHR.responseText,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "timeout") {
            msg = "Time out error.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else if (exception === "abort") {
            msg = "Ajax request aborted.";
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        } else {
            msg = "Uncaught Error.\n" + jqXHR.responseText;
			 swal({
  title: "Error!",
  text: msg,
  icon: "error",
  button: "Okay",
});
        }
    },
  success: function(data) {
	jQuery("#cover-spin").hide();
        if(data == "100" ){
	
		  swal({
  title: "SAVED",
  text: "Update Completed",
  icon: "success",
  button: "Okay",
}).then((value) => {
	location.reload();
});
	  }
	  else{
		  
	jQuery("#cover-spin").hide();
	swal({
  buttons: {
    cancel: "Why?",
    defeat: "Okay",
  },
  title: "Update Wasn\'t Successful",
  text: "Click \'Why\' To See reason",
  icon: "error",
})
.then((value) => {
  switch (value) {
 
    case "defeat":
      break;
    default:
      swal({
		title: "Details",
		text: data,
      icon: "info",
    });
  }
}); 

  }
  },
  type: "POST"
});






});


jQuery(document).ready(function($){
	jQuery("#cover-spin").hide();
		$("div#airtimeeasyaccess").show();
		$("div#dataeasyaccess").hide();
		$("div#cableeasyaccess").hide();
		$("div#billeasyaccess").hide();
		$("div#importdiv").hide();
		
	
	
	$("#airdi").click(function(){
		$("div#airtimeeasyaccess").show();
		$("div#dataeasyaccess").hide();
		$("div#cableeasyaccess").hide();
		$("div#billeasyaccess").hide();
		$("div#importdiv").hide();
		
	});
	$("#datadi").click(function(){
		$("div#airtimeeasyaccess").hide();
		$("div#dataeasyaccess").show();
		$("div#cableeasyaccess").hide();
		$("div#billeasyaccess").hide();
		$("div#importdiv").hide();
		
		$("div#directdata").hide();
		$("div#corporatedata").hide();
		
	$("input#directdata").on({
		click: function(){
		$("div#shareddata").hide();
		$("div#corporatedata").hide();
		$("div#directdata").show();
		}
		
	});
		
	$("input#shareddata").on({
		click: function(){
		$("div#shareddata").show();
		$("div#corporatedata").hide();
		$("div#directdata").hide();
		}
		});
		
	$("input#corporatedata").on({
		click: function(){
		$("div#shareddata").hide();
		$("div#corporatedata").show();
		$("div#directdata").hide();
		}
	});
		
	});
	
	$("#cabledi").click(function(){
		$("div#airtimeeasyaccess").hide();
		$("div#dataeasyaccess").hide();
		$("div#cableeasyaccess").show();
		$("div#billeasyaccess").hide();
		$("div#importdiv").hide();
		
		
	});
	$("#billdi").click(function(){
		$("div#airtimeeasyaccess").hide();
		$("div#dataeasyaccess").hide();
		$("div#cableeasyaccess").hide();
		$("div#billeasyaccess").show();
		$("div#importdiv").hide();
		
	});
	
	$("#importdi").click(function(){
		$("div#airtimeeasyaccess").hide();
		$("div#dataeasyaccess").hide();
		$("div#cableeasyaccess").hide();
		$("div#billeasyaccess").hide();
		$("div#importdiv").show();
		$("input.saveauth, button.saveauth").hide();
	});
	
	//////////////////////////////////////////////////// AIRTIME CHOICE /////////////////////////////
	$("div#vtuairtime").show();
		$("div#sharedairtime").hide();
		$("div#awufairtime").hide();
		
	$("input#vtuairtime").click(function(){
		$("div#vtuairtime").show();
		$("div#sharedairtime").hide();
		$("div#awufairtime").hide();
		
	});
	
	$("input#sharedairtime").click(function(){
		$("div#vtuairtime").hide();
		$("div#sharedairtime").show();
		$("div#awufairtime").hide();
		
	});
	
	
	$("input#awufairtime").click(function(){
		$("div#vtuairtime").hide();
		$("div#sharedairtime").hide();
		$("div#awufairtime").show();
		
	});
	
	
	


$("select#airtimerequest").on({
	change: function(){
	$("input#airtimerequesttext").val($("select#airtimerequest option:selected").text());
}


});

$("select#datarequest").on({
	change: function(){
	$("input#datarequesttext").val($("select#datarequest option:selected").text());
}


});


$("select#rdatarequest").on({
	change: function(){
	$("input#rdatarequesttext").val($("select#rdatarequest option:selected").text());
}


});


$("select#r2datarequest").on({
	change: function(){
	$("input#r2datarequesttext").val($("select#r2datarequest option:selected").text());
}


});






$("select#cablerequest").on({
	change: function(){
	$("input#cablerequesttext").val($("select#cablerequest option:selected").text());
}


});

$("select#billrequest").on({
	change: function(){
	$("input#billrequesttext").val($("select#billrequest option:selected").text());
}


});










});




';
do_action("gateway_script");

echo'

</script>

';


}

?>